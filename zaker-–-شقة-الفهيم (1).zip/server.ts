import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import { generateEducationalPdf, SAMPLE_PDF_DEFINITIONS } from './server/samplePdfs.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Support base64 PDF uploads up to 30MB
app.use(express.json({ limit: '30mb' }));

// Health and Diagnostics Check
app.get('/api/health', (_req: Request, res: Response) => {
  const hasKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0);
  res.json({
    status: 'ok',
    hasGeminiKey: hasKey,
    nodeEnv: process.env.NODE_ENV || 'development',
    time: new Date().toISOString(),
  });
});

// Serve real PDF base64 for sample curriculum books
app.get('/api/sample-pdf/:id', (req: Request, res: Response) => {
  const sampleId = req.params.id;
  const def = SAMPLE_PDF_DEFINITIONS[sampleId];

  if (!def) {
    res.status(404).json({ error: 'عينة الكتاب غير موجودة' });
    return;
  }

  try {
    const pdfBuffer = generateEducationalPdf(def.title, def.sections);
    const base64 = pdfBuffer.toString('base64');
    res.json({
      id: sampleId,
      title: def.title,
      base64,
      sizeBytes: pdfBuffer.length,
      sizeStr: `${(pdfBuffer.length / (1024 * 1024)).toFixed(2)} ميجابايت`,
    });
  } catch (err: any) {
    res.status(500).json({ error: `فشل توليد ملف PDF للعينة: ${err?.message || 'خطأ غير معروف'}` });
  }
});

// JSON Schema definition for Grounded Lesson & Synchronized Chalkboard Timeline
const lessonResponseSchema = {
  type: Type.OBJECT,
  properties: {
    bookTitle: {
      type: Type.STRING,
      description: 'The real title or primary topic of the uploaded document in Arabic.',
    },
    subjectTitle: {
      type: Type.STRING,
      description: 'The subject matter or scientific discipline of the document (e.g. فيزياء، لغة عربية، تاريخ، كيمياء).',
    },
    language: {
      type: Type.STRING,
      description: 'Language of the document (e.g. ar, en).',
    },
    mainTopics: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: '3 to 5 key topics identified in the actual document.',
    },
    sections: {
      type: Type.ARRAY,
      description: 'Comprehensive, ordered lesson sections directly extracted and synthesized from the document content.',
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          title: { type: Type.STRING, description: 'Numbered section heading in Arabic.' },
          chalkNotes: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: 'Bullet points suitable for writing on a chalkboard, containing verified definitions, formulas, dates, names, laws, and examples directly from the text.',
          },
          keyConcept: {
            type: Type.STRING,
            description: 'Core scientific or conceptual takeaway verified by the document.',
          },
          egyptianKicker: {
            type: Type.STRING,
            description: 'A witty, memorable Egyptian study-room study tip (كبسولة الزتونة) clarifying the trick or exam importance of this concept.',
          },
          pageReferences: {
            type: Type.STRING,
            description: 'Page numbers or locations where this information appears if identifiable from the document, e.g. "ص. 3-4" or "الصفحة الأولى".',
          },
          audioNarrationText: {
            type: Type.STRING,
            description: 'Spoken teacher script explaining this section in natural, engaging Egyptian Arabic according to the chosen teacher persona.',
          },
          recapText: {
            type: Type.STRING,
            description: 'Short concluding recap sentence summarizing this section.',
          },
          timelineSteps: {
            type: Type.ARRAY,
            description: 'Sequential presentation timeline synchronizing narration chunks with visual chalkboard actions.',
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                narrationChunk: {
                  type: Type.STRING,
                  description: 'A single spoken sentence or phrase (10-25 words) matching the teacher voice.',
                },
                actionType: {
                  type: Type.STRING,
                  description: "'write_text' | 'highlight_keyword' | 'draw_box' | 'draw_circle' | 'draw_arrow' | 'draw_diagram' | 'comparison_table'",
                },
                chalkText: {
                  type: Type.STRING,
                  description: 'The exact chalkboard text, law, bullet, or diagram label shown during this step.',
                },
                keyword: {
                  type: Type.STRING,
                  description: 'Key word or phrase to highlight on the board in yellow/purple.',
                },
                diagramData: {
                  type: Type.OBJECT,
                  description: 'Optional structured diagram, timeline, or comparison table data.',
                  properties: {
                    type: { type: Type.STRING, description: "'analogy' | 'timeline' | 'table' | 'formula_box' | 'cause_effect'" },
                    title: { type: Type.STRING },
                    items: { type: Type.ARRAY, items: { type: Type.STRING } },
                    columns: { type: Type.ARRAY, items: { type: Type.STRING } },
                    rows: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                      },
                    },
                  },
                },
                pageRef: { type: Type.STRING },
                isPausePoint: { type: Type.BOOLEAN },
              },
              required: ['id', 'narrationChunk', 'actionType', 'chalkText'],
            },
          },
        },
        required: ['id', 'title', 'chalkNotes', 'keyConcept', 'egyptianKicker', 'audioNarrationText', 'timelineSteps'],
      },
    },
    summaryCard: {
      type: Type.OBJECT,
      properties: {
        title: { type: Type.STRING, description: 'Summary header title (e.g. خلاصة الزتونة للمستند)' },
        points: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: '4 to 6 decisive summary bullet points grounded in the document.',
        },
      },
      required: ['title', 'points'],
    },
    examQuestions: {
      type: Type.ARRAY,
      description: 'Comprehensive grounded exam questions (default 15 questions, unless requested otherwise).',
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          type: { type: Type.STRING, description: "'mcq' | 'true_false' | 'short_answer' | 'oral'" },
          category: {
            type: Type.STRING,
            description: "'concept' | 'application' | 'comparison' | 'error_detection' | 'synthesis'",
          },
          difficulty: { type: Type.STRING, description: "'easy' | 'medium' | 'hard' | 'challenge'" },
          prompt: { type: Type.STRING, description: 'The question text in Arabic grounded in the document' },
          options: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '4 plausible options for multiple-choice questions (randomize correct answer positions)',
          },
          correctOptionIndex: {
            type: Type.INTEGER,
            description: '0-based index of the correct answer for multiple-choice questions',
          },
          correctBoolean: {
            type: Type.BOOLEAN,
            description: 'For true/false questions: true or false',
          },
          modelAnswer: {
            type: Type.STRING,
            description: 'Model answer grounded strictly in the document text',
          },
          explanation: {
            type: Type.STRING,
            description: 'Clear reasoning why this answer is correct according to the document text and common student pitfall',
          },
          pageReference: {
            type: Type.STRING,
            description: 'Page number or location from the PDF if identifiable',
          },
          topicTag: {
            type: Type.STRING,
            description: 'Topic tag related to one of the mainTopics',
          },
          sectionIndex: {
            type: Type.INTEGER,
            description: '0-based index of the section in the sections array',
          },
        },
        required: ['id', 'type', 'category', 'difficulty', 'prompt', 'modelAnswer', 'explanation', 'topicTag', 'sectionIndex'],
      },
    },
  },
  required: ['bookTitle', 'subjectTitle', 'mainTopics', 'sections', 'summaryCard', 'examQuestions'],
};

// Teacher-specific persona instructions
function getTeacherSystemInstructions(
  teacherId: string,
  studentName: string,
  speed: string,
  reason: string,
  customInfo?: { name?: string; specialty?: string; catchphrase?: string; description?: string }
): string {
  if (teacherId === 'hakkaway') {
    return `أنت "الحكّاي": راوي التاريخ والوقائع والملاحم الإنسانية في شقة الفهيم.
- النبرة: سردي مشوق متزن، يربط كل حدث بزمانه ومكانه وأبطاله الحقيقيين، مع حبكة درامية تربط الأسباب بالنتائج (Cause and Effect).
- ابدأ كل قسم بمشهد تاريخي درامي أو تساؤل يحبس الأنفاس: "في تلك اللحظة الفارقة ووراء الأبواب المغلقة..." أو "ماذا لو لم يصدر ذلك القرار؟".
- لا تختلق أي أحداث تاريخية، بل التزم بما ورد في الوثيقة بنسبة 100%. ميّز بين الوقائع المؤكدة والتحليلات.
- على السبورة: ارسم خطوطًا زمنية (Timelines) بالتواريخ، خرائط سياقية، وتوصيلات بالأسهم توضح كيف قاد السبب (أ) إلى النتيجة (ب).
- في timelineSteps: استخدم actionType='draw_diagram' مع type='timeline' أو 'cause_effect' لإبراز التسلسل الزمني.
- الإيقاع: هادئ، حكواتي وثائقي، وقفات درامية محسوبة.
- خاطب الطالب (${studentName}) كأنه رفيق رحلتك عبر صفحات المخطوطة.`;
  }

  if (teacherId === 'mokhtasar') {
    return `أنت "المختصر": منظم المنهج والمبسط المباشر بدون لف ودوران في شقة الفهيم.
- النبرة: علمية منظمة، حاسمة، تدخل فورًا في صلب الموضوع دون نكات جانبية أو مقدمات طويلة.
- ركّز بدقة على ما يجب على الطالب حفظه وفهمه للامتحان، وعرّف المصطلحات والقوانين مباشرة.
- قسّم الدرس إلى نقاط مرقمة محددة، ومقارنات حاسمة بين المفاهيم المتشابهة.
- على السبورة: استخدم جداول مقارنة واضحة (actionType='comparison_table' أو 'draw_box') مع أعمدة وصفوف دقيقة، ومربعات بيضاء للقوانين الأساسية وتنبيهات الأخطاء الشائعة (Common Mistakes).
- في timelineSteps: رتّب الخطوات بشكل منطقي سريع ومباشر.
- اختم كل قسم بملخص امتحاني مضغوط (recapText): "الزتونة هنا في نقطتين محددتين...".
- خاطب الطالب (${studentName}) بأسلوب توجيهي امتحاني مركز.`;
  }

  if (teacherId.startsWith('custom_') && customInfo) {
    return `أنت المعلم "${customInfo.name || 'المعلم الخبير'}": متخصص في (${customInfo.specialty || 'المادة الدراسية'}).
- شعارك وأسلوبك: "${customInfo.catchphrase || 'افهم وركز وقفل الامتحان'}".
- وصف طريقتك: ${customInfo.description || 'شرح مبسط ومرتب يعتمد على التوضيح الدقيق والأمثلة'}.
- التزم بنسبة 100% بمحتوى وثيقة الـ PDF المرفوعة بدون اختلاق أي وقائع.
- خاطب الطالب (${studentName}) بأسلوبك المميز الداعم.`;
  }

  // Default: faheem
  return `أنت "الفهيم": حكواتي العلوم والفيزياء والطاقة الإيجابية في شقة الفهيم.
- النبرة: حماسية، سريعة الإيقاع، ذكية، مليئة بالتشبيهات الشعبية المصرية المبتكرة والمفاجئة التي تحول المفاهيم المجردة إلى مشهد حي.
- ابنِ قصة متصلة تشرح كيف تتحرك المفاهيم وتتفاعل، مع وقفات تعجبية وقفشات ذكية تخدم الفهم دون تشتيت.
- استخدم عباراتك الانتقالية الشهيرة: "طب استنى، فيه حاجة مهمة هنا!"، "تخيل معايا المشهد ده: ..."، "ليه ده بيحصل أصلاً؟".
- اشرح الفكرة المعقدة أولاً بتشبيه بصري دارج، ثم انتقل للقانون العلمي أو الصيغة الرياضية.
- على السبورة: ارسم تشبيهات حركية (actionType='draw_diagram' مع type='analogy')، ضع دوائر صفراء حول التريكات، ونقاط طاقة مضيئة.
- اختم كل قسم بكبسولة "الزتونة" وعبارة تعلق بالذاكرة.
- خاطب الطالب (${studentName}) بحماس وشجعه دايمًا: "ركز يا بطل عشان دي التريكة اللي هتقفل بيها المادة!".`;
}

// Real PDF Analysis via Gemini API with Teacher Personality & Structured Chalkboard Timeline
app.post('/api/analyze-pdf', async (req: Request, res: Response) => {
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey || apiKey.trim() === '' || apiKey === 'MY_GEMINI_API_KEY') {
    res.status(500).json({
      error: 'مفتاح Gemini API (GEMINI_API_KEY) غير مضبوط في متغيرات البيئة. يرجى إضافته في إعدادات المشروع (Settings > Secrets) للتمكن من تحليل المستندات الحقيقية.',
    });
    return;
  }

    const {
    pdfBase64,
    fileName,
    studentName,
    gradeLevel,
    speed,
    reason,
    teacherId = 'faheem',
    teacherName,
    teacherSpecialty,
    teacherPersona,
    teacherDescription,
    examLength = 15,
    difficulty = 'medium',
  } = req.body;

  if (!pdfBase64 || typeof pdfBase64 !== 'string') {
    res.status(400).json({
      error: 'لم يتم استلام ملف PDF صالح للتحليل أو الملف فارغ. يرجى اختيار ملف PDF صالح.',
    });
    return;
  }

  const cleanBase64 = pdfBase64.replace(/^data:application\/pdf;base64,/, '').trim();

  if (cleanBase64.length === 0) {
    res.status(400).json({
      error: 'محتوى ملف الـ PDF المرفوع فارغ تمامًا.',
    });
    return;
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const teacherPersonaPrompt = getTeacherSystemInstructions(
      teacherId,
      studentName || 'البطل',
      speed || 'slow',
      reason || 'understand',
      {
        name: teacherName,
        specialty: teacherSpecialty,
        catchphrase: teacherPersona,
        description: teacherDescription,
      }
    );

    const questionCount = Math.max(5, Math.min(Number(examLength) || 15, 20));

    const systemPrompt = `${teacherPersonaPrompt}

مهمتك: قراءة ملف الـ PDF المرفق وتحليله بدقة متناهية، ثم تحويله إلى درس سبورة طباشير تفاعلي حقيقي متزامن، وامتحان ذكي شامل.

تعليمات صارمة للتحليل (Grounded & Accurate):
1. اعتمد كليًا وبشكل حصري على محتوى وثيقة الـ PDF المرفقة. لا تختلق أي وقائع أو قوانين أو تواريخ غير مدعومة بالنص.
2. استخرج العنوان الحقيقي والموضوع العام ولغة المستند وأهم 3 إلى 5 مواضيع رئيسية.
3. قسّم الدرس إلى 3 إلى 5 فصول رئيسية منظمة تغطي كامل أبعاد الوثيقة.
4. في كل قسم، أنشئ خطة زمنية للسبورة (timelineSteps):
   - قسّم الشرح الصوتي إلى جمل قصيرة واضحة (narrationChunk).
   - اربط كل جملة بحركة سبورة دقيقة (actionType): كتابة نص (write_text)، تمييز مصطلح (highlight_keyword)، رسم مستطيل/دائرة (draw_box/draw_circle)، أو رسم توضيحي/جدول مقارنة (draw_diagram/comparison_table).
   - وفر بيانات المخطط (diagramData) بتفاصيل تناسب شخصية المعلم (تشبيهات لـ الفهيم، خطوط زمنية لـ الحكّاي، جداول مقارنة لـ المختصر).
   - حدد أرقام الصفحات (pageReferences / pageRef) من الـ PDF بدقة.
5. أنشئ بالضبط ${questionCount} سؤالاً للامتحان بمستوى صعوبة '${difficulty}':
   - وزع الأسئلة بتنوع تربوي حقيقي:
     * 4 أسئلة مفاهيم واستيعاب (category='concept')
     * 4 أسئلة تطبيق واستدلال (category='application')
     * 3 أسئلة مقارنة وعلاقات وأسباب (category='comparison')
     * 2 سؤال كشف أخطاء ومغالطات شائعة (category='error_detection')
     * 2 سؤال تحليل واستنتاج مركب (category='synthesis')
   - نوّع في أنماط الأسئلة: اختيار من متعدد (mcq)، صواب وخطأ مع التعليل (true_false)، ومسائل إجابة قصيرة (short_answer)، بالإضافة لسؤال شفوي (oral).
   - في أسئلة الاختيار من متعدد: اكتب 4 خيارات واقعية ونوّع في موقع الخيار الصحيح (لا تجعل الإجابة الصحيحة دائمًا في نفس الخيار!).
   - ضع لكل سؤال تفسيرًا وافيًا ومرجع الصفحة (pageReference) من المستند.
6. أرجع النتيجة في كائن JSON يطابق المخطط المطلوب تمامًا.`;

    const candidateModels = ['gemini-3.8-flash', 'gemini-3.1-flash-lite', 'gemini-4-argon'];
    let lastError: any = null;
    let responseText: string | null = null;

    for (const modelName of candidateModels) {
      try {
        console.log(`[ZAKER] Analyzing PDF with ${modelName} for teacher ${teacherId}...`);
        const response = await ai.models.generateContent({
          model: modelName,
          contents: [
            {
              inlineData: {
                mimeType: 'application/pdf',
                data: cleanBase64,
              },
            },
            {
              text: systemPrompt,
            },
          ],
          config: {
            responseMimeType: 'application/json',
            responseSchema: lessonResponseSchema,
          },
        });

        if (response.text) {
          responseText = response.text;
          console.log(`[ZAKER] Successfully generated lesson with ${modelName}`);
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`[ZAKER] Model ${modelName} failed, trying next candidate:`, err?.message || err);
      }
    }

    if (!responseText) {
      throw lastError || new Error('لم يُرجع نموذج الذكاء الاصطناعي أي استجابة نصية.');
    }

    const parsedData = JSON.parse(responseText);

    if (!parsedData.sections || !Array.isArray(parsedData.sections) || parsedData.sections.length === 0) {
      throw new Error('لم يتمكن النموذج من استخراج فصول صالحة من المستند.');
    }

    const finalLesson = {
      id: `lesson_${Date.now()}`,
      bookTitle: parsedData.bookTitle || fileName || 'كتاب دراسي',
      subjectTitle: parsedData.subjectTitle || 'شرح المنهج',
      gradeLevel: gradeLevel || '3 ثانوي',
      teacherId,
      language: parsedData.language || 'ar',
      mainTopics: parsedData.mainTopics || [],
      sections: parsedData.sections.map((s: any, idx: number) => ({
        id: s.id || `sec_${idx + 1}`,
        title: s.title || `القسم ${idx + 1}`,
        chalkNotes: Array.isArray(s.chalkNotes) ? s.chalkNotes : [String(s.chalkNotes)],
        keyConcept: s.keyConcept || '',
        egyptianKicker: s.egyptianKicker || '',
        pageReferences: s.pageReferences || '',
        audioNarrationText: s.audioNarrationText || '',
        recapText: s.recapText || '',
        timelineSteps: Array.isArray(s.timelineSteps) && s.timelineSteps.length > 0
          ? s.timelineSteps.map((step: any, sIdx: number) => ({
              id: step.id || `step_${idx + 1}_${sIdx + 1}`,
              narrationChunk: step.narrationChunk || '',
              actionType: step.actionType || 'write_text',
              chalkText: step.chalkText || '',
              keyword: step.keyword || '',
              diagramData: step.diagramData || undefined,
              pageRef: step.pageRef || s.pageReferences || '',
              isPausePoint: Boolean(step.isPausePoint),
            }))
          : [
              // Fallback timeline from chalkNotes if model returned empty steps
              {
                id: `step_${idx + 1}_1`,
                narrationChunk: s.audioNarrationText || s.title,
                actionType: 'write_text',
                chalkText: s.title,
                pageRef: s.pageReferences,
              },
            ],
      })),
      summaryCard: {
        title: parsedData.summaryCard?.title || 'خلاصة زتونة المستند 🫒',
        points: parsedData.summaryCard?.points || [],
      },
    };

    // Shuffle multiple choice option positions so correct answers are naturally distributed
    const finalQuestions = (parsedData.examQuestions || []).map((q: any, idx: number) => {
      let shuffledOptions = Array.isArray(q.options) ? [...q.options] : ['أ', 'ب', 'ج', 'د'];
      let correctIdx = typeof q.correctOptionIndex === 'number' ? q.correctOptionIndex : 0;

      if (q.type === 'mcq' && shuffledOptions.length > 1) {
        const correctText = shuffledOptions[correctIdx] || shuffledOptions[0];
        // Fisher-Yates shuffle
        for (let i = shuffledOptions.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [shuffledOptions[i], shuffledOptions[j]] = [shuffledOptions[j], shuffledOptions[i]];
        }
        correctIdx = shuffledOptions.indexOf(correctText);
      }

      return {
        id: q.id || `q_${idx + 1}`,
        type: q.type || 'mcq',
        category: q.category || 'concept',
        difficulty: q.difficulty || difficulty || 'medium',
        prompt: q.prompt || `سؤال ${idx + 1}`,
        options: shuffledOptions,
        correctOptionIndex: correctIdx,
        correctBoolean: typeof q.correctBoolean === 'boolean' ? q.correctBoolean : true,
        modelAnswer: q.modelAnswer || '',
        explanation: q.explanation || '',
        pageReference: q.pageReference || '',
        topicTag: q.topicTag || 'مفهوم رئيسي',
        sectionIndex: typeof q.sectionIndex === 'number' ? q.sectionIndex : 0,
      };
    });

    res.json({
      success: true,
      lesson: finalLesson,
      questions: finalQuestions,
      meta: {
        analyzedAt: new Date().toISOString(),
        fileName,
        teacherId,
        difficulty,
      },
    });
  } catch (error: any) {
    console.error('Gemini PDF analysis error:', error);

    const errorMessage = error?.message || '';
    let arabicError = 'حدث خطأ غير متوقع أثناء تحليل ملف الـ PDF بواسطة Gemini.';

    if (errorMessage.includes('503') || errorMessage.includes('UNAVAILABLE') || errorMessage.includes('high demand')) {
      arabicError = 'خوادم Gemini تشهد إقبالاً عاليًا ومؤقتًا في هذه اللحظة (503 High Demand). هذا ضغط مؤقت في الخدمة؛ يرجى الضغط على زر "إعادة المحاولة الآن" بعد ثوانٍ معدودة.';
    } else if (errorMessage.includes('RESOURCE_EXHAUSTED') || errorMessage.includes('429')) {
      arabicError = 'تم تجاوز معدل الطلبات المسموح به مؤقتًا (Rate Limit) في Gemini API. يرجى الانتظار 30 ثانية والمحاولة مرة أخرى.';
    } else if (errorMessage.includes('API_KEY_INVALID') || (errorMessage.includes('400') && errorMessage.includes('API key'))) {
      arabicError = 'مفتاح Gemini API المستخدم غير صالح أو منتهي الصلاحية. يرجى التحقق من إعدادات المفتاح في لوحة الأسرار (Settings > Secrets).';
    } else if (errorMessage.includes('PERMISSION_DENIED') || errorMessage.includes('403')) {
      arabicError = 'تم رفض الطلب لعدم وجود صلاحيات كافية على مفتاح Gemini API.';
    } else if (errorMessage.includes('INVALID_ARGUMENT') || errorMessage.includes('PDF')) {
      arabicError = 'ملف الـ PDF المرفق غير صالح أو تالف أو يحتوي على تشفير غير مدعوم. يرجى تجربة ملف آخر.';
    } else if (errorMessage) {
      arabicError = `تعذر استكمال تحليل المستند: ${errorMessage}`;
    }

    res.status(500).json({
      success: false,
      error: arabicError,
      rawError: process.env.NODE_ENV !== 'production' ? errorMessage : undefined,
    });
  }
});

// Real Oral Exam Evaluation with Gemini
app.post('/api/evaluate-oral', async (req: Request, res: Response) => {
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    res.status(500).json({ error: 'مفتاح Gemini API غير مضبوط لتقييم الإجابة الشفوية.' });
    return;
  }

  const { questionPrompt, modelAnswer, userAnswerText, teacherId = 'faheem', topicTag } = req.body;

  if (!userAnswerText || !userAnswerText.trim()) {
    res.status(400).json({ error: 'لم يتم استلام نص إجابة شفوية للتقييم.' });
    return;
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
    });

    const prompt = `أنت المعلم (${teacherId === 'hakkaway' ? 'الحكّاي' : teacherId === 'mokhtasar' ? 'المختصر' : 'الفهيم'}) في شقة الفهيم.
أنت تمتحن الطالب شفهيًا في موضوع: ${topicTag || 'الموضوع العلمي'}.

سؤال الامتحان الشفوي:
${questionPrompt}

الإجابة النموذجية المعتمدة:
${modelAnswer}

إجابة الطالب الشفوية (كما تحدث بها أو كتبها):
"${userAnswerText}"

المطلوب تقييم إجابة الطالب بذكاء تربوي واقعي:
1. ميّز بين الإجابة الخاطئة علميًا وبين الإجابة الصحيحة التي صاغها الطالب بأسلوبه الخاص دون التقيد بحرفية النص.
2. احسب درجة من 0 إلى 10 (score) ومدى دقة الإجابة (isAccurate).
3. اكتب تعليقًا شفهيًا قصيرًا وداعمًا (feedback) باللهجة المصرية حسب شخصيتك كمعلم.
4. اذكر النقاط الجوهرية الناقصة إن وُجدت (missingPoints).
5. اطرح سؤال متابعة ذكي ومترابط (followUpQuestion) يختبر فهمه لأحد الجوانب الناقصة أو يرفع مستوى التحدي.`;

    const oralEvalSchema = {
      type: Type.OBJECT,
      properties: {
        score: { type: Type.INTEGER, description: 'Score out of 10' },
        isAccurate: { type: Type.BOOLEAN, description: 'True if answer shows fundamental understanding' },
        feedback: { type: Type.STRING, description: 'Constructive teacher verbal response in Egyptian Arabic' },
        missingPoints: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'Key points missed by student' },
        followUpQuestion: { type: Type.STRING, description: 'Thoughtful follow-up question in Arabic' },
      },
      required: ['score', 'isAccurate', 'feedback', 'missingPoints'],
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: oralEvalSchema,
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json({
      success: true,
      evaluation: parsed,
    });
  } catch (error: any) {
    console.error('Oral evaluation error:', error);
    res.status(500).json({
      success: false,
      error: `تعذر تقييم الإجابة الشفوية: ${error?.message || 'خطأ غير معروف'}`,
    });
  }
});

// Real Personalized Revision Generator based on Exam Mistakes
app.post('/api/generate-revision', async (req: Request, res: Response) => {
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    res.status(500).json({ error: 'مفتاح Gemini API غير مضبوط لتوليد خطة المراجعة.' });
    return;
  }

  const { mistakes, teacherId = 'faheem', studentName = 'البطل' } = req.body;

  if (!mistakes || !Array.isArray(mistakes) || mistakes.length === 0) {
    res.status(400).json({ error: 'لا توجد أخطاء مرسلة لتوليد جلسة المراجعة.' });
    return;
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
    });

    const mistakesSummary = mistakes
      .map(
        (m: any, idx: number) =>
          `[خطأ ${idx + 1}] المفهوم: ${m.topicTag}\nالسؤال: ${m.questionPrompt}\nإجابة الطالب الخاطئة: ${m.userAnswer}\nالإجابة الصحيحة: ${m.correctAnswer}\nالتعليل: ${m.explanation}`
      )
      .join('\n\n');

    const prompt = `أنت المعلم (${teacherId === 'hakkaway' ? 'الحكّاي' : teacherId === 'mokhtasar' ? 'المختصر' : 'الفهيم'}) في شقة الفهيم.
أنهى الطالب (${studentName}) امتحانه ووقع في بعض الأخطاء المفاهيمية.
مهمتك: إنشاء جلسة مراجعة ذكية مخصصة (Personalized Revision Session) لعلاج كل خطأ بنموذج ومثال جديد تمامًا.

قائمة الأخطاء التي وقع فيها الطالب:
${mistakesSummary}

تعليمات صارمة للمراجعة:
1. لكل خطأ: استخرج المفهوم الجوهري، وأعد شرحه بطريقتك كمعلم مصري مميز.
2. استخدم تشبيهًا أو مثالاً واقعيًا جديدًا تمامًا يختلف عن المثال المذكور في السؤال الأصلي لتثبيت الفهم من زاوية مختلفة.
3. ضع سؤال متابعة سريع وتفاعلي (followUpCheck) بخيارات متعددة لتتأكد فورًا من أن الطالب تجاوز سوء الفهم.`;

    const revisionSchema = {
      type: Type.OBJECT,
      properties: {
        revisionCards: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              conceptTag: { type: Type.STRING },
              sectionIndex: { type: Type.INTEGER },
              originalQuestionPrompt: { type: Type.STRING },
              teacherExplanation: {
                type: Type.STRING,
                description: 'Personalized re-explanation in the teacher voice focusing on the root confusion',
              },
              newAnalogyExample: {
                type: Type.STRING,
                description: 'A completely new, fresh analogy or everyday scenario demonstrating the rule',
              },
              followUpCheck: {
                type: Type.OBJECT,
                properties: {
                  prompt: { type: Type.STRING },
                  options: { type: Type.ARRAY, items: { type: Type.STRING } },
                  correctOptionIndex: { type: Type.INTEGER },
                  explanation: { type: Type.STRING },
                },
                required: ['prompt', 'options', 'correctOptionIndex', 'explanation'],
              },
            },
            required: ['conceptTag', 'teacherExplanation', 'newAnalogyExample', 'followUpCheck'],
          },
        },
      },
      required: ['revisionCards'],
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: revisionSchema,
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json({
      success: true,
      revisionCards: parsed.revisionCards || [],
    });
  } catch (error: any) {
    console.error('Revision generation error:', error);
    res.status(500).json({
      success: false,
      error: `تعذر توليد جلسة المراجعة: ${error?.message || 'خطأ غير معروف'}`,
    });
  }
});

// Configure Vite middleware in development or static serving in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[ZAKER - شقة الفهيم] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
