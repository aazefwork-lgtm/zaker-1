import React, { useState, useEffect, useRef } from 'react';
import { ChalkTimelineStep, LessonData, OutputSettings, TeacherProfile } from '../types/index.ts';
import { soundManager } from '../utils/audioSynth.ts';
import { speechManager } from '../utils/speechSynth.ts';
import {
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  SkipBack,
  Eye,
  Volume2,
  VolumeX,
  CheckCircle,
  HelpCircle,
  Sparkles,
  ArrowLeft,
  BookOpen,
  Bookmark,
  Layers,
  Table,
  GitCommit,
  Activity,
  AlertTriangle,
  Lightbulb,
  Gauge,
  Flame,
  Clock,
  Compass,
} from 'lucide-react';

interface LessonScreenProps {
  lesson: LessonData;
  teacher: TeacherProfile;
  settings: OutputSettings;
  studentName: string;
  onGoToExam: () => void;
  onBackToSettings: () => void;
  onChangeTeacher?: (teacherId: string) => void;
  onRegenerateWithTeacher?: (teacherId: string) => Promise<void>;
  isRegeneratingTeacher?: boolean;
}

export const LessonScreen: React.FC<LessonScreenProps> = ({
  lesson,
  teacher,
  settings,
  studentName,
  onGoToExam,
  onBackToSettings,
  onChangeTeacher,
  onRegenerateWithTeacher,
  isRegeneratingTeacher = false,
}) => {
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [audioVoiceEnabled, setAudioVoiceEnabled] = useState(settings.autoSpeak ?? true);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(settings.playbackRate || 1.0);
  const [showAllSteps, setShowAllSteps] = useState(false);
  const [highlightKeywordActive, setHighlightKeywordActive] = useState<string | null>(null);

  const section = lesson.sections[currentSectionIndex] || lesson.sections[0];
  const timeline: ChalkTimelineStep[] = section.timelineSteps && section.timelineSteps.length > 0
    ? section.timelineSteps
    : section.chalkNotes.map((note, idx) => ({
        id: `gen_step_${idx}`,
        narrationChunk: note,
        actionType: (idx === 0 ? 'write_text' : idx % 3 === 0 ? 'highlight_keyword' : idx % 2 === 0 ? 'draw_box' : 'write_text') as any,
        chalkText: note,
        keyword: note.split(' ')[0] || '',
        pageRef: section.pageReferences,
        diagramData: undefined,
      }));

  const totalSections = lesson.sections.length;
  const totalSteps = timeline.length;
  const activeStep = timeline[currentStepIndex] || timeline[0];

  const isPlayingRef = useRef(isPlaying);
  isPlayingRef.current = isPlaying;

  const currentStepRef = useRef(currentStepIndex);
  currentStepRef.current = currentStepIndex;

  const currentSectionRef = useRef(currentSectionIndex);
  currentSectionRef.current = currentSectionIndex;

  // Execute step narration and chalkboard sync
  const triggerStep = (stepIdx: number) => {
    if (stepIdx >= totalSteps) {
      setIsPlaying(false);
      return;
    }

    const step = timeline[stepIdx];
    if (!step) return;

    // Trigger chalk sound
    soundManager.playChalkScratch();

    if (step.keyword) {
      setHighlightKeywordActive(step.keyword);
    } else {
      setHighlightKeywordActive(null);
    }

    if (audioVoiceEnabled) {
      speechManager.speak(step.narrationChunk, {
        rate: playbackSpeed,
        gender: settings.voice || 'male',
        onStart: () => {},
        onEnd: () => {
          if (isPlayingRef.current && currentStepRef.current === stepIdx && currentSectionRef.current === currentSectionIndex) {
            if (stepIdx + 1 < totalSteps) {
              setCurrentStepIndex(stepIdx + 1);
            } else {
              setIsPlaying(false);
              soundManager.playChime(true);
            }
          }
        },
      });
    } else {
      // Timer-based fallback when TTS voice is disabled
      const wordCount = step.narrationChunk.split(/\s+/).length;
      const durationMs = Math.max(1600, (wordCount * 450) / playbackSpeed);

      const timer = setTimeout(() => {
        if (isPlayingRef.current && currentStepRef.current === stepIdx && currentSectionRef.current === currentSectionIndex) {
          if (stepIdx + 1 < totalSteps) {
            setCurrentStepIndex(stepIdx + 1);
          } else {
            setIsPlaying(false);
            soundManager.playChime(true);
          }
        }
      }, durationMs);

      return () => clearTimeout(timer);
    }
  };

  // When step changes, trigger if playing
  useEffect(() => {
    if (isPlaying && !showAllSteps) {
      triggerStep(currentStepIndex);
    }
    return () => {
      speechManager.stop();
    };
  }, [currentStepIndex, isPlaying, audioVoiceEnabled, playbackSpeed, currentSectionIndex, showAllSteps]);

  // Section switcher
  const handleSelectSection = (idx: number) => {
    speechManager.stop();
    soundManager.playClick();
    setCurrentSectionIndex(idx);
    setCurrentStepIndex(0);
    setShowAllSteps(false);
    setIsPlaying(true);
  };

  const handleNextSection = () => {
    if (currentSectionIndex < totalSections - 1) {
      handleSelectSection(currentSectionIndex + 1);
    } else {
      speechManager.stop();
      soundManager.playChime(true);
      onGoToExam();
    }
  };

  const handlePrevSection = () => {
    if (currentSectionIndex > 0) {
      handleSelectSection(currentSectionIndex - 1);
    }
  };

  const handleReplaySection = () => {
    speechManager.stop();
    soundManager.playEraserSwipe();
    setShowAllSteps(false);
    setCurrentStepIndex(0);
    setIsPlaying(true);
  };

  const handleTogglePlay = () => {
    soundManager.playClick();
    if (isPlaying) {
      speechManager.pause();
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      if (showAllSteps) {
        setShowAllSteps(false);
      }
    }
  };

  const handleToggleShowAll = () => {
    soundManager.playClick();
    speechManager.stop();
    setShowAllSteps(!showAllSteps);
    setIsPlaying(false);
  };

  const handleStepScrub = (idx: number) => {
    soundManager.playClick();
    speechManager.stop();
    setCurrentStepIndex(idx);
    setShowAllSteps(false);
    setIsPlaying(true);
  };

  const handleCycleSpeed = () => {
    const speeds = [0.75, 1.0, 1.25, 1.5];
    const nextIdx = (speeds.indexOf(playbackSpeed) + 1) % speeds.length;
    const nextSpeed = speeds[nextIdx];
    setPlaybackSpeed(nextSpeed);
    soundManager.playClick();
  };

  // Visible steps on the board
  const visibleSteps = showAllSteps
    ? timeline
    : timeline.slice(0, currentStepIndex + 1);

  return (
    <div className="max-w-6xl mx-auto py-6 px-4 sm:px-6">
      {/* Lesson Header Strip */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white/80 backdrop-blur-xs p-4 rounded-2xl border border-stone-200 shadow-sm">
        <div className="flex items-start gap-3">
          <div
            className={`w-12 h-12 rounded-2xl border-2 flex items-center justify-center text-2xl shadow-sm shrink-0 ${teacher.avatarBg}`}
          >
            {teacher.avatarEmoji}
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <span className="text-xs font-bold text-stone-500 flex items-center gap-1">
                <BookOpen className="w-3.5 h-3.5 text-[#8B5CF6]" />
                {lesson.bookTitle}
              </span>
              <span className="text-xs text-stone-300">·</span>
              <span className="text-xs font-extrabold px-2 py-0.5 rounded-md border bg-amber-50 text-amber-800 border-amber-200">
                المعلم {teacher.name} ({teacher.title})
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-[#1E232A]">
              {lesson.subjectTitle}
            </h2>
          </div>
        </div>

        {/* Section Jump Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {lesson.sections.map((sec, idx) => (
            <button
              key={sec.id}
              onClick={() => handleSelectSection(idx)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                idx === currentSectionIndex
                  ? 'bg-[#1A1F24] text-[#FDE047] shadow-sm ring-1 ring-[#FDE047]/30'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              فصل {idx + 1}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Blackboard (8 cols) + Margins & Narration (4 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Central Blackboard (8 cols) */}
        <div className="lg:col-span-8 flex flex-col space-y-4">
          <div className="relative rounded-3xl chalkboard-surface chalkboard-border p-6 sm:p-8 min-h-[500px] flex flex-col justify-between shadow-2xl text-white overflow-hidden transition-all">
            {/* Top Board Frame Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4 text-xs">
              <div className="flex items-center gap-2 font-mono text-stone-400">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>
                  الفصل {currentSectionIndex + 1} من {totalSections}
                </span>
                <span className="text-stone-600">|</span>
                <span className="text-stone-300">
                  خطوة {showAllSteps ? totalSteps : currentStepIndex + 1} من {totalSteps}
                </span>
              </div>

              {/* Catchphrase in Chalk typography */}
              <div className="flex items-center gap-2">
                <span className="text-[#FDE047] font-chalk text-xs sm:text-sm font-bold">
                  « {teacher.catchphrase} »
                </span>
              </div>
            </div>

            {/* Board Title & Page Reference */}
            <div>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                <h3 className="text-2xl sm:text-3xl font-black chalk-text-yellow font-chalk tracking-wide">
                  {section.title}
                </h3>
                {section.pageReferences && (
                  <span className="text-[11px] font-mono text-[#67E8F9] bg-white/10 border border-white/15 px-3 py-1 rounded-full shadow-xs flex items-center gap-1.5">
                    <Bookmark className="w-3 h-3 text-[#67E8F9]" />
                    مرجع الصفحات بالـ PDF: {section.pageReferences}
                  </span>
                )}
              </div>

              {/* Synchronized Progressive Content Reveal */}
              <div className="space-y-4 my-6 text-sm sm:text-base leading-relaxed">
                {visibleSteps.map((step, idx) => {
                  const isCurrent = !showAllSteps && idx === currentStepIndex;

                  return (
                    <div
                      key={step.id || idx}
                      className={`transition-all duration-300 animate-in fade-in slide-in-from-right-3 ${
                        isCurrent ? 'scale-[1.01]' : 'opacity-90'
                      }`}
                    >
                      {/* Render based on actionType */}
                      {step.actionType === 'write_text' && (
                        <div className="flex items-start gap-2.5">
                          <span className="text-[#67E8F9] select-none font-bold text-lg leading-none">›</span>
                          <span
                            className={`chalk-text-white font-medium ${
                              isCurrent ? 'text-white font-bold bg-white/5 px-2 py-0.5 rounded-lg' : ''
                            }`}
                          >
                            {step.chalkText}
                          </span>
                        </div>
                      )}

                      {step.actionType === 'highlight_keyword' && (
                        <div className="flex items-start gap-2.5">
                          <span className="text-[#FDE047] select-none font-bold text-lg leading-none">★</span>
                          <div className="flex-1">
                            <span className="chalk-text-white font-medium">{step.chalkText}</span>
                            {step.keyword && (
                              <span className="inline-block mr-2 px-2.5 py-0.5 rounded-lg bg-yellow-400/20 text-[#FDE047] border border-yellow-400/40 text-xs font-bold font-mono">
                                مصطلح جوهري: {step.keyword}
                              </span>
                            )}
                          </div>
                        </div>
                      )}

                      {step.actionType === 'draw_box' && (
                        <div className="p-3.5 rounded-2xl bg-white/5 border-2 border-dashed border-[#FDE047]/60 text-xs sm:text-sm my-2">
                          <div className="flex items-center gap-1.5 text-[#FDE047] font-bold mb-1">
                            <Lightbulb className="w-4 h-4" />
                            <span>قاعدة / قانون ذهبي للامتحان:</span>
                          </div>
                          <p className="chalk-text-white font-semibold text-sm">
                            {step.chalkText}
                          </p>
                        </div>
                      )}

                      {/* Specialized Teacher Chalk Diagrams */}
                      {(step.actionType === 'draw_diagram' || step.actionType === 'comparison_table') && (
                        <div className="p-4 rounded-2xl bg-black/40 border border-white/20 text-xs my-3 shadow-inner">
                          {/* Teacher-specific visual rendering */}
                          {teacher.id === 'faheem' ? (
                            /* Al-Faheem: Analogy Flow Schema */
                            <div>
                              <div className="flex items-center gap-2 text-amber-400 font-bold mb-2">
                                <Activity className="w-4 h-4" />
                                <span>تشبيه الفهيم الحركي ⚡: {step.diagramData?.title || step.chalkText}</span>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-center text-xs mt-2">
                                <div className="bg-amber-500/20 border border-amber-400/30 p-2.5 rounded-xl">
                                  <span className="text-amber-300 font-bold block mb-1">المفهوم الفيزيائي</span>
                                  <span className="text-white">{step.keyword || 'القانون المجرد'}</span>
                                </div>
                                <div className="bg-purple-500/20 border border-purple-400/30 p-2.5 rounded-xl flex items-center justify-center">
                                  <span className="text-[#C4B5FD] font-bold">تشبيه شعبي: محطة قطار ومضخة مياه</span>
                                </div>
                                <div className="bg-emerald-500/20 border border-emerald-400/30 p-2.5 rounded-xl">
                                  <span className="text-emerald-300 font-bold block mb-1">النتيجة العملية</span>
                                  <span className="text-white">الفهم الثابت بدون نسيان</span>
                                </div>
                              </div>
                            </div>
                          ) : teacher.id === 'hakkaway' ? (
                            /* Al-Hakkaway: Chronological Timeline / Causes */
                            <div>
                              <div className="flex items-center gap-2 text-[#C4B5FD] font-bold mb-2">
                                <Clock className="w-4 h-4" />
                                <span>تسلسل الأحداث الزمني والوقائع ⏳: {step.diagramData?.title || step.chalkText}</span>
                              </div>
                              <div className="flex items-center justify-between border-t border-purple-400/30 pt-3 mt-2 font-mono text-xs text-stone-300">
                                <div className="flex items-center gap-2">
                                  <span className="w-3 h-3 rounded-full bg-purple-400" />
                                  <span>البداية والشرارة</span>
                                </div>
                                <span className="text-stone-400 font-bold">───►</span>
                                <div className="flex items-center gap-2">
                                  <span className="w-3 h-3 rounded-full bg-amber-400" />
                                  <span>القرار الحاسم</span>
                                </div>
                                <span className="text-stone-400 font-bold">───►</span>
                                <div className="flex items-center gap-2">
                                  <span className="w-3 h-3 rounded-full bg-emerald-400" />
                                  <span>النتيجة التاريخية</span>
                                </div>
                              </div>
                            </div>
                          ) : (
                            /* Al-Mokhtasar: Structured Comparison Table */
                            <div>
                              <div className="flex items-center gap-2 text-emerald-400 font-bold mb-2">
                                <Table className="w-4 h-4" />
                                <span>جدول مقارنة امتحاني حاسم 📐: {step.diagramData?.title || step.chalkText}</span>
                              </div>
                              <div className="grid grid-cols-2 gap-2 text-xs text-right mt-2">
                                <div className="bg-emerald-950/40 border border-emerald-400/30 p-2.5 rounded-xl">
                                  <span className="text-emerald-300 font-bold block mb-1">ما يجب حفظه للامتحان</span>
                                  <span className="text-stone-200">{step.chalkText}</span>
                                </div>
                                <div className="bg-rose-950/40 border border-rose-400/30 p-2.5 rounded-xl">
                                  <span className="text-rose-300 font-bold block mb-1">خطأ شائع يتكرر بالامتحانات ⚠️</span>
                                  <span className="text-stone-200">الخلط بين المفاهيم المتشابهة</span>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}

                {/* Chalk in action cursor */}
                {isPlaying && !showAllSteps && (
                  <div className="flex items-center gap-2 text-stone-400 text-xs font-mono animate-pulse pt-2">
                    <span className="w-2.5 h-4 bg-white/70 inline-block shadow-xs" />
                    <span>{teacher.name} يشرح ويكتب على السبورة بالصوت المتزامن...</span>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Key Concept Box */}
            <div className="mt-4 p-4 rounded-2xl bg-purple-950/50 border border-purple-400/40 text-xs sm:text-sm">
              <span className="text-[#C4B5FD] font-bold block mb-1 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#C4B5FD]" />
                فكرة السؤال الجوهري في المستند:
              </span>
              <p className="text-stone-200 font-medium">
                {section.keyConcept}
              </p>
            </div>

            {/* Chalkboard Wooden Tray */}
            <div className="mt-6 pt-3 border-t border-[#4A2D17] flex items-center justify-between text-xs text-stone-400">
              <span className="text-[11px] font-mono">
                {showAllSteps ? totalSteps : currentStepIndex + 1} من {totalSteps} محطات مشروحة
              </span>
              <div className="flex items-center gap-2">
                <div className="w-7 h-2 bg-white rounded-full opacity-90 shadow-sm" />
                <div className="w-5 h-2 bg-[#FDE047] rounded-full opacity-90 shadow-sm" />
                <div className="w-6 h-2 bg-[#67E8F9] rounded-full opacity-80 shadow-sm" />
              </div>
            </div>
          </div>

          {/* Synchronized Player Control Bar */}
          <div className="bg-white rounded-2xl border border-stone-200 p-4 shadow-sm flex flex-wrap items-center justify-between gap-3">
            {/* Play/Pause & Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleTogglePlay}
                className="px-4 py-2 rounded-xl bg-[#1A1F24] hover:bg-[#2C333D] text-[#FDE047] font-bold text-xs flex items-center gap-2 shadow transition-all cursor-pointer"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{isPlaying ? 'إيقاف مؤقت' : 'متابعة الشرح'}</span>
              </button>

              <button
                onClick={handleReplaySection}
                title="إعادة مسح وكتابة هذا الفصل من البداية"
                className="p-2 rounded-xl border border-stone-200 hover:bg-stone-100 text-stone-700 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              <button
                onClick={handleToggleShowAll}
                title="إظهار كل خطط السبورة دفعة واحدة للقراءة السريعة"
                className={`px-3 py-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  showAllSteps
                    ? 'bg-purple-100 text-[#8B5CF6] border-purple-300 font-bold'
                    : 'border-stone-200 hover:bg-stone-100 text-stone-700'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>{showAllSteps ? 'عرض الخطوات' : 'إظهار الكل فورًا'}</span>
              </button>

              {/* Speed Rate Pill */}
              <button
                onClick={handleCycleSpeed}
                title="سرعة الإلقاء والصوت"
                className="px-2.5 py-1.5 rounded-xl border border-stone-200 hover:bg-stone-100 text-stone-700 text-xs font-mono font-bold flex items-center gap-1 cursor-pointer"
              >
                <Gauge className="w-3.5 h-3.5 text-stone-500" />
                <span>{playbackSpeed}x</span>
              </button>

              {/* Voice Sound Toggle */}
              <button
                onClick={() => {
                  soundManager.playClick();
                  setAudioVoiceEnabled(!audioVoiceEnabled);
                }}
                title={audioVoiceEnabled ? 'كتم الصوت العربي التفاعلي' : 'تشغيل الصوت العربي التفاعلي'}
                className={`p-2 rounded-xl border text-xs transition-colors cursor-pointer ${
                  audioVoiceEnabled
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                    : 'border-stone-200 text-stone-400 hover:bg-stone-100'
                }`}
              >
                {audioVoiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>
            </div>

            {/* Steppers & Exam Trigger */}
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrevSection}
                disabled={currentSectionIndex === 0}
                className="p-2 rounded-xl border border-stone-200 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-stone-100 text-stone-700 transition-colors"
                title="الفصل السابق"
              >
                <SkipForward className="w-4 h-4" />
              </button>

              <span className="text-xs font-mono font-bold text-stone-600 px-2">
                فصل {currentSectionIndex + 1} / {totalSections}
              </span>

              <button
                onClick={handleNextSection}
                className="px-4 py-2 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-bold text-xs flex items-center gap-1.5 shadow transition-all cursor-pointer"
              >
                <span>
                  {currentSectionIndex < totalSections - 1 ? 'الفصل التالي' : 'جاهز للامتحان 🚀'}
                </span>
                <SkipBack className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Timeline Step-by-Step Scrubber Dots */}
          <div className="bg-white/70 backdrop-blur-xs p-3 rounded-2xl border border-stone-200/80 flex items-center gap-1.5 overflow-x-auto">
            <span className="text-[11px] font-bold text-stone-500 shrink-0 ml-2">
              مسار الشرح:
            </span>
            {timeline.map((step, idx) => (
              <button
                key={idx}
                onClick={() => handleStepScrub(idx)}
                title={`انتقل للخطوة ${idx + 1}: ${(step.chalkText || '').substring(0, 30)}...`}
                className={`h-2.5 rounded-full transition-all cursor-pointer ${
                  idx === currentStepIndex && !showAllSteps
                    ? 'w-8 bg-[#8B5CF6]'
                    : idx < currentStepIndex || showAllSteps
                    ? 'w-4 bg-emerald-500'
                    : 'w-2 bg-stone-300 hover:bg-stone-400'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Right Sidebar: Active Narration, Egyptian Kicker, and Teacher Switcher (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          {/* Active Narration Box (Spoken Transcript with Highlight) */}
          <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500 animate-ping" />
                <h4 className="font-extrabold text-sm text-[#1E232A]">
                  ما يقوله المعلم الآن 🎙️
                </h4>
              </div>
              <span className="text-[11px] font-mono text-stone-400">
                {playbackSpeed}x
              </span>
            </div>

            {/* Currently spoken sentence */}
            <div className="bg-[#FAF7F2] p-3.5 rounded-xl border border-[#E6DFD3] text-xs text-stone-800 leading-relaxed font-medium">
              « {activeStep?.narrationChunk || section.audioNarrationText} »
            </div>

            {/* Teacher Personality Badges */}
            <div className="mt-3 flex items-center justify-between text-[11px] text-stone-500 pt-2 border-t border-stone-100">
              <span>أسلوب الإلقاء:</span>
              <span className="font-bold text-purple-700">
                {teacher.id === 'faheem'
                  ? 'حماسي وتشبيهات شعبية ⚡'
                  : teacher.id === 'hakkaway'
                  ? 'سرد تاريخي وقصصي ⏳'
                  : 'مختصر ومقارنات امتحانات 📐'}
              </span>
            </div>
          </div>

          {/* Quick Teacher Switcher: Compare how different teachers explain the same PDF */}
          <div className="bg-gradient-to-br from-purple-50 to-indigo-50/60 rounded-2xl border border-purple-200/80 p-5 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-black text-purple-900 font-chalk flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-[#8B5CF6]" />
                تبديل المعلم وتوليد الشرح بأسلوبه:
              </span>
            </div>
            <p className="text-[11px] text-stone-600 mb-3">
              كل معلم يرى نفس المستند بزاوية مختلفة تمامًا. اختر معلماً لإعادة صياغة السبورة:
            </p>

            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'faheem', name: 'الفهيم ⚡', sub: 'علوم وتشبيهات' },
                { id: 'hakkaway', name: 'الحكّاي ⏳', sub: 'تاريخ وقصص' },
                { id: 'mokhtasar', name: 'المختصر 📐', sub: 'امتحانات وجداول' },
              ].map((t) => (
                <button
                  key={t.id}
                  disabled={isRegeneratingTeacher || teacher.id === t.id}
                  onClick={() => {
                    if (onRegenerateWithTeacher) {
                      onRegenerateWithTeacher(t.id);
                    } else if (onChangeTeacher) {
                      onChangeTeacher(t.id);
                    }
                  }}
                  className={`p-2 rounded-xl text-center border transition-all cursor-pointer ${
                    teacher.id === t.id
                      ? 'bg-[#1A1F24] text-[#FDE047] border-[#1A1F24] font-extrabold shadow-sm'
                      : 'bg-white hover:bg-stone-50 text-stone-800 border-stone-200 text-xs'
                  } disabled:opacity-50`}
                >
                  <span className="block text-xs font-bold">{t.name}</span>
                  <span className="text-[10px] text-stone-400 block mt-0.5">{t.sub}</span>
                </button>
              ))}
            </div>

            {isRegeneratingTeacher && (
              <div className="mt-2 text-center text-xs text-purple-800 font-bold animate-pulse">
                جاري إعادة صياغة السبورة بواسطة الذكاء الاصطناعي...
              </div>
            )}
          </div>

          {/* "الزتونة" (Key Takeaway Pill) */}
          <div className="bg-gradient-to-br from-amber-50 to-amber-100/70 rounded-2xl border-2 border-amber-200 p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-2 text-amber-900">
              <Sparkles className="w-4 h-4 text-amber-600" />
              <h4 className="font-extrabold text-sm font-chalk">
                زتونة {teacher.name} للفصل 🫒
              </h4>
            </div>
            <p className="text-xs font-bold text-amber-950 leading-relaxed bg-white/80 p-3 rounded-xl border border-amber-200/80">
              {section.egyptianKicker}
            </p>
          </div>

          {/* Summary Card of the Document */}
          <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-sm">
            <h4 className="text-xs font-bold text-stone-800 uppercase tracking-wider mb-3">
              {lesson.summaryCard.title}
            </h4>
            <ul className="space-y-2">
              {lesson.summaryCard.points.map((pt, i) => (
                <li
                  key={i}
                  className="text-xs text-stone-600 flex items-start gap-2 leading-relaxed"
                >
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{pt}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* CTA: Go to Exam */}
          <button
            onClick={() => {
              speechManager.stop();
              onGoToExam();
            }}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#1A1F24] to-[#2C333D] text-[#FDE047] font-black text-sm shadow-xl hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer border border-[#5C3A21]"
          >
            <span>جاهز للاختبار؟ افتح الامتحان دلوقتي</span>
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
