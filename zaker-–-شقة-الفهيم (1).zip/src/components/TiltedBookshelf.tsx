import React from 'react';
import { SAMPLE_BOOKS } from '../config.ts';
import { BookOpen } from 'lucide-react';

interface TiltedBookshelfProps {
  onSelectSampleBook: (sampleId: string) => void;
}

export const TiltedBookshelf: React.FC<TiltedBookshelfProps> = ({ onSelectSampleBook }) => {
  const books = [
    {
      id: 'sample_physics',
      title: 'الفيزياء الكهربية',
      color: 'bg-amber-800 text-amber-100 border-amber-900',
      tilt: '-rotate-6',
      height: 'h-36 sm:h-44',
      author: 'الوافي',
    },
    {
      id: 'sample_arabic',
      title: 'النحو والبلاغة',
      color: 'bg-emerald-800 text-emerald-100 border-emerald-900',
      tilt: 'rotate-3',
      height: 'h-32 sm:h-40',
      author: 'الأضواء',
    },
    {
      id: 'sample_history',
      title: 'تاريخ مصر الحديث',
      color: 'bg-purple-900 text-purple-100 border-purple-950',
      tilt: '-rotate-12 translate-y-1',
      height: 'h-34 sm:h-42',
      author: 'سامح سند',
    },
    {
      id: 'sample_dentistry',
      title: 'تشريح الأسنان',
      color: 'bg-cyan-900 text-cyan-100 border-cyan-950',
      tilt: 'rotate-0',
      height: 'h-36 sm:h-44',
      author: 'Netter',
    },
  ];

  return (
    <div className="relative w-full max-w-[280px] select-none">
      {/* Bookshelf Header Tag */}
      <div className="flex items-center justify-between mb-2 px-1">
        <span className="text-[11px] font-bold tracking-wider text-[#64748B] uppercase flex items-center gap-1">
          <BookOpen className="w-3.5 h-3.5 text-[#8B5CF6]" />
          مكتبة الشقة
        </span>
        <span className="text-[10px] text-stone-500 font-medium">اختر نموذجًا للمعاينة</span>
      </div>

      {/* Tilted Shelf Container */}
      <div className="relative p-3 bg-gradient-to-b from-[#3D2513] to-[#2B190B] rounded-xl border-2 border-[#54321A] shadow-xl">
        {/* Books lined up on shelf */}
        <div className="flex items-end justify-around gap-1.5 pt-4 pb-2 px-1 min-h-[180px]">
          {books.map((book) => (
            <button
              key={book.id}
              onClick={() => onSelectSampleBook(book.id)}
              title={`افتح ${book.title}`}
              className={`group relative flex flex-col justify-between p-1.5 w-11 sm:w-13 ${book.height} ${book.color} ${book.tilt} rounded-t border shadow-md hover:scale-105 hover:-translate-y-2 hover:z-20 transition-all cursor-pointer`}
            >
              {/* Gold Embossed Spine Ribbon */}
              <div className="w-full h-1 bg-[#D97706]/70 rounded-full" />

              {/* Vertical Title (Book Spine) */}
              <span className="text-[10px] sm:text-xs font-bold [writing-mode:vertical-rl] rotate-180 truncate mx-auto tracking-tight">
                {book.title}
              </span>

              {/* Author / Publisher */}
              <span className="text-[8px] font-mono opacity-70 text-center truncate">
                {book.author}
              </span>

              {/* Hover indicator tag */}
              <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-8 right-1/2 translate-x-1/2 bg-[#1E232A] text-[#FAF7F2] text-[10px] px-2 py-0.5 rounded shadow pointer-events-none whitespace-nowrap z-30">
                مذاكرة الكتاب
              </div>
            </button>
          ))}
        </div>

        {/* Heavy Wooden Shelf Plank */}
        <div className="w-full h-4 bg-gradient-to-r from-[#4A2E19] via-[#633E22] to-[#4A2E19] rounded-b-md border-t-2 border-[#7C4E2C] shadow-lg flex items-center justify-between px-3">
          <div className="w-2 h-1 bg-[#23150B] rounded-full" />
          <div className="w-2 h-1 bg-[#23150B] rounded-full" />
        </div>
      </div>
    </div>
  );
};
