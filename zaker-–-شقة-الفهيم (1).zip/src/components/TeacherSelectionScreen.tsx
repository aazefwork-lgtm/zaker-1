import React, { useState } from 'react';
import { TeacherProfile } from '../types/index.ts';
import { soundManager } from '../utils/audioSynth.ts';
import { Check, Plus, Sparkles, Volume2, ArrowLeft, ArrowRight, X, Loader2, RefreshCw, Zap, Clock, Table } from 'lucide-react';

interface TeacherSelectionScreenProps {
  teachers: TeacherProfile[];
  selectedTeacherId: string;
  onSelectTeacher: (teacherId: string) => void;
  onAddTeacher: (newTeacher: TeacherProfile) => void;
  onContinue: () => void;
  onBack: () => void;
  studentName: string;
  hasAnalyzedLesson?: boolean;
  isRegeneratingTeacher?: boolean;
  onRegenerateWithTeacher?: (teacherId: string) => Promise<void>;
}

export const TeacherSelectionScreen: React.FC<TeacherSelectionScreenProps> = ({
  teachers,
  selectedTeacherId,
  onSelectTeacher,
  onAddTeacher,
  onContinue,
  onBack,
  studentName,
  hasAnalyzedLesson = false,
  isRegeneratingTeacher = false,
  onRegenerateWithTeacher,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [playingPreviewId, setPlayingPreviewId] = useState<string | null>(null);

  // New teacher form state
  const [newName, setNewName] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newSpecialty, setNewSpecialty] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newCatchphrase, setNewCatchphrase] = useState('');
  const [newEmoji, setNewEmoji] = useState('🎓');

  const handlePreviewAudio = (teacher: TeacherProfile) => {
    soundManager.playClick();
    setPlayingPreviewId(teacher.id);
    setTimeout(() => {
      setPlayingPreviewId(null);
    }, 2000);
  };

  const handleCreateTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const newTeacher: TeacherProfile = {
      id: `custom_${Date.now()}`,
      name: newName.trim(),
      title: newTitle.trim() || 'معلم خبير ومبسط للمنهج',
      specialty: newSpecialty.trim() || 'مواد عامة',
      avatarEmoji: newEmoji,
      avatarBg: 'bg-indigo-500/10 text-indigo-600 border-indigo-300',
      accentColor: '#6366F1',
      description: newDescription.trim() || 'أسلوب تفاعلي مشوق يعتمد على الأمثلة العملية.',
      catchphrase: newCatchphrase.trim() || 'كل مسألة ولها حل بالصبر والتركيز!',
      audioSampleDescription: 'أسلوب شرح هادئ ومنظم كرتوني افتراضي.',
      chalkboardStyle: 'مربعات مفاهيم وتعداد نقطي مرتب.',
      pacing: 'concise_structured',
      sampleTransition: 'ركز في النقطة دي كويس:',
      isCustom: true,
    };

    onAddTeacher(newTeacher);
    onSelectTeacher(newTeacher.id);
    setShowAddModal(false);
    setNewName('');
    setNewTitle('');
    setNewSpecialty('');
    setNewDescription('');
    setNewCatchphrase('');
  };

  const selectedTeacher = teachers.find((t) => t.id === selectedTeacherId) || teachers[0];

  return (
    <div className="max-w-6xl mx-auto py-6 px-4 sm:px-6">
      {/* Header */}
      <div className="mb-6 text-center sm:text-right">
        <span className="text-xs font-bold text-[#8B5CF6] tracking-wider uppercase block mb-1">
          طاقم التدريس الأصلي بشقة الفهيم
        </span>
        <h2 className="text-3xl font-black text-[#1E232A] font-chalk">
          {studentName ? `يا ${studentName}، اختر المعلم لشرح كتابك` : 'اختر المعلم لشرح كتابك'}
        </h2>
        <p className="text-sm text-stone-500 mt-1 max-w-3xl leading-relaxed">
          3 شخصيات أصلية متميزة تمامًا في أسلوب الشرح، وسرعة الإلقاء، والمفردات، وتصميم سبورة الطباشير:
        </p>
      </div>

      {/* Teachers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-8">
        {teachers.map((teacher) => {
          const isSelected = selectedTeacherId === teacher.id;

          return (
            <div
              key={teacher.id}
              onClick={() => {
                soundManager.playClick();
                onSelectTeacher(teacher.id);
              }}
              className={`group relative rounded-3xl p-6 border-2 transition-all cursor-pointer flex flex-col justify-between ${
                isSelected
                  ? 'bg-white border-[#1A1F24] ring-2 ring-[#FDE047] shadow-xl scale-[1.01]'
                  : 'bg-white/80 hover:bg-white border-[#E6DFD3] hover:border-stone-400 shadow-sm hover:shadow-md'
              }`}
            >
              {/* Selected Badge */}
              {isSelected && (
                <div className="absolute top-4 left-4 w-7 h-7 rounded-full bg-[#1A1F24] text-[#FDE047] flex items-center justify-center shadow">
                  <Check className="w-4 h-4 stroke-[3]" />
                </div>
              )}

              {/* Teacher Avatar & Header */}
              <div>
                <div className="flex items-center gap-3.5 mb-3">
                  <div
                    className={`w-14 h-14 rounded-2xl border-2 flex items-center justify-center text-3xl shadow-sm ${teacher.avatarBg}`}
                  >
                    {teacher.avatarEmoji}
                  </div>
                  <div>
                    <h3 className="font-black text-lg text-[#1E232A]">
                      {teacher.name}
                    </h3>
                    <span className="text-xs font-bold text-[#8B5CF6] block">
                      {teacher.title}
                    </span>
                  </div>
                </div>

                {/* Catchphrase */}
                <div className="bg-[#FAF7F2] rounded-xl p-3 border border-[#E6DFD3] mb-3 text-right">
                  <span className="text-xs font-bold text-stone-800 italic block font-chalk">
                    « {teacher.catchphrase} »
                  </span>
                </div>

                {/* Description */}
                <p className="text-xs text-stone-600 leading-relaxed mb-4">
                  {teacher.description}
                </p>

                {/* Trait Tags */}
                <div className="space-y-1.5 text-[11px] font-medium border-t border-stone-100 pt-3 mb-4">
                  <div className="flex items-center justify-between text-stone-600">
                    <span className="text-stone-400">أسلوب السبورة:</span>
                    <span className="font-bold text-stone-800 text-right truncate max-w-[200px]">
                      {teacher.chalkboardStyle}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-stone-600">
                    <span className="text-stone-400">إيقاع الشرح:</span>
                    <span className="font-bold text-purple-700">
                      {teacher.pacing === 'energetic'
                        ? 'حماسي وتشبيهات شعبية ⚡'
                        : teacher.pacing === 'narrative_story'
                        ? 'سرد تاريخي درامي ⏳'
                        : 'منظم ومباشر للامتحان 📐'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Card Footer: Voice preview simulator & select button */}
              <div className="pt-3 border-t border-stone-100 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handlePreviewAudio(teacher);
                  }}
                  className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border flex items-center gap-1 transition-colors ${
                    playingPreviewId === teacher.id
                      ? 'bg-amber-100 text-amber-800 border-amber-300 animate-pulse'
                      : 'bg-stone-100 text-stone-600 border-stone-200 hover:bg-stone-200'
                  }`}
                  title="استمع لنبرة الشرح"
                >
                  <Volume2 className="w-3.5 h-3.5 text-[#8B5CF6]" />
                  <span>{playingPreviewId === teacher.id ? 'يتم الاستماع...' : 'عينة أسلوب'}</span>
                </button>

                <span
                  className={`text-xs font-black ${
                    isSelected ? 'text-[#1A1F24]' : 'text-stone-400 group-hover:text-stone-700'
                  }`}
                >
                  {isSelected ? 'المعلم المختار ✓' : 'اختر هذا المعلم'}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Plus Card to add custom teacher */}
      <div className="mb-8">
        <button
          onClick={() => setShowAddModal(true)}
          className="w-full py-4 px-6 rounded-2xl border-2 border-dashed border-[#D1C7B7] hover:border-[#8B5CF6] bg-stone-50/50 hover:bg-purple-50/30 transition-all flex items-center justify-center gap-3 cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-white border border-stone-300 group-hover:border-[#8B5CF6] group-hover:bg-[#8B5CF6] group-hover:text-white text-stone-600 flex items-center justify-center transition-all shadow-xs">
            <Plus className="w-4 h-4" />
          </div>
          <span className="font-extrabold text-xs text-stone-700 group-hover:text-[#8B5CF6]">
            إضافة معلم مخصص بشخصية وإفيه خاص بك
          </span>
        </button>
      </div>

      {/* Navigation and Re-Generate Option */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-stone-200">
        <button
          onClick={onBack}
          className="px-4 py-2 rounded-xl text-stone-600 hover:text-stone-900 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <ArrowRight className="w-4 h-4" />
          <span>الرجوع للاستمارة</span>
        </button>

        <div className="flex items-center gap-3">
          {hasAnalyzedLesson && onRegenerateWithTeacher && (
            <button
              disabled={isRegeneratingTeacher}
              onClick={() => onRegenerateWithTeacher(selectedTeacherId)}
              className="px-5 py-2.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-300 font-extrabold text-xs flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              {isRegeneratingTeacher ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-purple-700" />
                  <span>جاري إعادة صياغة الدرس مع {selectedTeacher.name}...</span>
                </>
              ) : (
                <>
                  <RefreshCw className="w-3.5 h-3.5 text-[#8B5CF6]" />
                  <span>توليد الدرس بأسلوب {selectedTeacher.name} 🚀</span>
                </>
              )}
            </button>
          )}

          <button
            onClick={onContinue}
            className="px-6 py-2.5 rounded-xl bg-[#1A1F24] hover:bg-[#2C333D] text-[#FDE047] font-black text-sm shadow-md active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
          >
            <span>المتابعة إلى الدرس</span>
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Modal: Add Custom Teacher */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-stone-300 max-w-md w-full p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-4 left-4 p-1 rounded-lg text-stone-400 hover:text-stone-700"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-4">
              <span className="text-xs font-bold text-[#8B5CF6] tracking-wider uppercase block mb-1">
                تخصيص المعلم
              </span>
              <h3 className="text-xl font-black text-stone-900 font-chalk">
                إضافة معلم جديد لشقة الفهيم
              </h3>
            </div>

            <form onSubmit={handleCreateTeacher} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  اسم المعلم:
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: د. حسام، مس سارة، الأستاذ عادل..."
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-[#8B5CF6] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    المادة / التخصص:
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: كيمياء عضوية، لغة فرنسية..."
                    value={newSpecialty}
                    onChange={(e) => setNewSpecialty(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-[#8B5CF6] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    الرمز التعبيري:
                  </label>
                  <select
                    value={newEmoji}
                    onChange={(e) => setNewEmoji(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-[#8B5CF6] focus:outline-none"
                  >
                    <option value="🎓">🎓 قبعة التخرج</option>
                    <option value="🧪">🧪 كيمياء ومعمل</option>
                    <option value="📐">📐 هندسة ورياضيات</option>
                    <option value="🌍">🌍 جغرافيا وفضاء</option>
                    <option value="🩺">🩺 طب وصحة</option>
                    <option value="🎨">🎨 فنون وأدب</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  الإفيه أو المقولة الشهيرة:
                </label>
                <input
                  type="text"
                  placeholder="مثال: متخافش من المعادلة، الكيمياء فهم!"
                  value={newCatchphrase}
                  onChange={(e) => setNewCatchphrase(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-[#8B5CF6] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  أسلوب الشرح:
                </label>
                <textarea
                  rows={2}
                  placeholder="وصف مختصر لطريقة الشرح والتفاعل مع الطالب..."
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-[#8B5CF6] focus:outline-none"
                />
              </div>

              <div className="pt-3 border-t border-stone-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-stone-600 hover:text-stone-900 text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#1A1F24] hover:bg-[#2C333D] text-[#FDE047] text-xs font-bold shadow transition-all cursor-pointer"
                >
                  حفظ واختيار المعلم
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
