import React, { useState } from 'react';
import { soundManager } from '../utils/audioSynth.ts';

export const BrainModel: React.FC = () => {
  const [clicked, setClicked] = useState(false);
  const [trivia, setTrivia] = useState('');

  const brainFacts = [
    'المخ البشري يستهلك 20% من طاقة الجسم وقت المذاكرة المكثفة!',
    'المذاكرة بفترات راحة (Pomodoro) تزيد تثبيت المعلومات بنسبة 60%.',
    'الفص الصدغي مسؤول عن تذكر قوانين الفيزياء وشواهد النحو.',
    'النوم العميق بعد المذاكرة هو الوقت اللي بينقل فيه المخ المعلومات للذاكرة طويلة المدى.',
  ];

  const handleClick = () => {
    soundManager.playChime(true);
    setClicked(true);
    const randomFact = brainFacts[Math.floor(Math.random() * brainFacts.length)];
    setTrivia(randomFact);
    setTimeout(() => setClicked(false), 3800);
  };

  return (
    <div className="relative inline-block cursor-pointer group" onClick={handleClick}>
      {/* Trivia Popup */}
      {clicked && (
        <div className="absolute -top-16 right-1/2 translate-x-1/2 z-30 bg-[#1A1F24] text-[#FAF7F2] text-xs font-semibold px-3 py-1.5 rounded-lg whitespace-nowrap shadow-xl border border-purple-500/40 animate-in fade-in zoom-in-95 duration-200">
          <span className="text-[#FDE047] font-bold ml-1">معلومة الفهيم:</span> {trivia}
          <div className="absolute -bottom-1 right-1/2 translate-x-1/2 w-2 h-2 bg-[#1A1F24] rotate-45 border-r border-b border-purple-500/40" />
        </div>
      )}

      {/* Stand Base */}
      <div className="w-16 h-20 flex flex-col items-center justify-end relative">
        {/* Anatomical Brain Graphic (Styled SVG) */}
        <div className="relative z-10 w-14 h-12 animate-brain-pulse group-hover:scale-110 transition-transform">
          <svg viewBox="0 0 64 54" fill="none" className="w-full h-full drop-shadow-md">
            {/* Brain Left & Right Hemispheres */}
            <path
              d="M12 28C8 28 4 23 6 16C8 9 17 6 24 8C27 4 37 4 40 8C47 6 56 9 58 16C60 23 56 28 52 28C54 34 50 42 44 43C40 44 36 41 32 41C28 41 24 44 20 43C14 42 10 34 12 28Z"
              fill="url(#brainGradient)"
              stroke="#8B5CF6"
              strokeWidth="2"
            />
            {/* Synaptic Sulci / Gyri folds */}
            <path
              d="M18 18C22 19 23 25 19 28M25 14C30 15 30 23 27 28M39 14C34 15 34 23 37 28M46 18C42 19 41 25 45 28M32 10V38"
              stroke="#FAF7F2"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeOpacity="0.8"
            />
            {/* Synaptic firing glow dots */}
            <circle cx="22" cy="22" r="2" fill="#FDE047" className="animate-ping" style={{ animationDuration: '3s' }} />
            <circle cx="42" cy="24" r="1.8" fill="#67E8F9" className="animate-ping" style={{ animationDuration: '2.5s' }} />

            <defs>
              <linearGradient id="brainGradient" x1="6" y1="6" x2="58" y2="44" gradientUnits="userSpaceOnUse">
                <stop stopColor="#DDD6FE" />
                <stop offset="0.6" stopColor="#C4B5FD" />
                <stop offset="1" stopColor="#A78BFA" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* Anatomical Metal Rod Support */}
        <div className="w-1.5 h-6 bg-stone-500 rounded-sm" />

        {/* Heavy Wooden Base */}
        <div className="w-14 h-3 bg-[#4A2D17] rounded-sm border-t border-[#6B4226] shadow" />
      </div>
    </div>
  );
};
