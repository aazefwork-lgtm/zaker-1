import React, { useState } from 'react';
import { ExamResult, RevisionCard, TeacherProfile } from '../types/index.ts';
import { soundManager } from '../utils/audioSynth.ts';
import {
  Trophy,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RotateCcw,
  BookOpen,
  ArrowRight,
  Sparkles,
  Home,
  Brain,
  Check,
  Loader2,
  Bookmark,
  Target,
  ArrowLeft,
  Flame,
} from 'lucide-react';

interface ResultsScreenProps {
  result: ExamResult;
  teacher: TeacherProfile;
  studentName: string;
  onRetakeExam: () => void;
  onJumpToSection: (sectionIndex: number) => void;
  onReturnToRoom: () => void;
}

export const ResultsScreen: React.FC<ResultsScreenProps> = ({
  result,
  teacher,
  studentName,
  onRetakeExam,
  onJumpToSection,
  onReturnToRoom,
}) => {
  const [revisionCards, setRevisionCards] = useState<RevisionCard[]>(result.revisionCards || []);
  const [loadingRevision, setLoadingRevision] = useState(false);
  const [revisionError, setRevisionError] = useState<string | null>(null);
  const [selectedCheckAnswers, setSelectedCheckAnswers] = useState<Record<number, number>>({});
  const [masteredCards, setMasteredCards] = useState<Record<number, boolean>>({});

  const mistakes = result.details.filter((d) => !d.isCorrect);

  const handleStartPersonalizedRevision = async () => {
    if (mistakes.length === 0) return;

    setLoadingRevision(true);
    setRevisionError(null);
    soundManager.playClick();

    try {
      const response = await fetch('/api/generate-revision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mistakes: mistakes.map((m) => ({
            topicTag: m.topicTag,
            questionPrompt: m.questionPrompt,
            userAnswer: m.userAnswer,
            correctAnswer: m.correctAnswer,
            explanation: m.explanation,
          })),
          teacherId: teacher.id,
          studentName: studentName || 'البطل',
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'تعذر توليد خطة المراجعة المخصصة.');
      }

      setRevisionCards(data.revisionCards || []);
      soundManager.playChime(true);
    } catch (err: any) {
      console.error('Revision generator error:', err);
      setRevisionError(err?.message || 'حدث خطأ أثناء التواصل مع خادم الذكاء الاصطناعي لتوليد المراجعة.');
    } finally {
      setLoadingRevision(false);
    }
  };

  const handleSelectCheckOption = (cardIdx: number, optIdx: number, correctIdx: number) => {
    soundManager.playClick();
    setSelectedCheckAnswers((prev) => ({
      ...prev,
      [cardIdx]: optIdx,
    }));

    if (optIdx === correctIdx) {
      soundManager.playChime(true);
      setMasteredCards((prev) => ({
        ...prev,
        [cardIdx]: true,
      }));
    } else {
      soundManager.playChime(false);
    }
  };

  const masteredCount = Object.values(masteredCards).filter(Boolean).length;
  const allMastered = revisionCards.length > 0 && masteredCount === revisionCards.length;

  return (
    <div className="max-w-5xl mx-auto py-6 px-4 sm:px-6">
      {/* Score Hero Card */}
      <div className="relative rounded-3xl chalkboard-surface chalkboard-border p-6 sm:p-10 shadow-2xl text-white text-center mb-8 overflow-hidden">
        <div className="absolute top-4 left-6 text-xs font-handwriting text-white/20">
          ZAKER AI Evaluation · {teacher.name}
        </div>

        <div className="max-w-xl mx-auto">
          {/* Trophy Icon */}
          <div className="w-16 h-16 rounded-2xl bg-amber-500/20 text-[#FDE047] border border-amber-400/40 flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Trophy className="w-8 h-8" />
          </div>

          <span className="text-xs font-bold text-[#8B5CF6] uppercase tracking-wider block mb-1">
            تقرير نتيجة الاختبار الشامل
          </span>

          <h2 className="text-3xl sm:text-4xl font-black text-[#FDE047] font-chalk mb-2">
            {result.gradeMessage}
          </h2>

          <p className="text-sm text-stone-300 font-medium mb-6">
            يا {studentName || 'بطل'}، إليك تقييم المعلم {teacher.name} وملاحظات تثبيت كل مفهوم قبل الامتحان الحقيقي.
          </p>

          {/* KPI Strip */}
          <div className="grid grid-cols-3 gap-3 max-w-md mx-auto bg-black/40 rounded-2xl p-4 border border-white/10">
            <div>
              <span className="text-[11px] text-stone-400 block mb-0.5">الدرجة</span>
              <span className="text-2xl sm:text-3xl font-black text-white font-mono">
                {result.score} / {result.totalQuestions}
              </span>
            </div>
            <div>
              <span className="text-[11px] text-stone-400 block mb-0.5">النسبة</span>
              <span className="text-2xl sm:text-3xl font-black text-[#FDE047] font-mono">
                {result.percentage}%
              </span>
            </div>
            <div>
              <span className="text-[11px] text-stone-400 block mb-0.5">التقييم</span>
              <span
                className={`text-lg sm:text-xl font-black ${
                  result.passed ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {result.passed ? 'ناجح جدًا 🌟' : 'يحتاج مراجعة 📚'}
              </span>
            </div>
          </div>
        </div>

        {/* Chalk bottom wooden tray */}
        <div className="absolute bottom-0 inset-x-0 h-3 bg-[#4A2D17]" />
      </div>

      {/* PART 4: PERSONALIZED REVISION EXPERIENCE (علاج الأخطاء بالذكاء الاصطناعي) */}
      {mistakes.length > 0 && (
        <div className="mb-8 rounded-3xl bg-gradient-to-br from-purple-50 via-indigo-50/50 to-amber-50/40 border-2 border-purple-200/80 p-6 sm:p-8 shadow-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <div>
              <span className="text-xs font-bold text-[#8B5CF6] uppercase tracking-wider block mb-1">
                البرنامج الذكي لعلاج الفجوات المعرفية
              </span>
              <h3 className="text-2xl font-black text-[#1E232A] font-chalk flex items-center gap-2">
                <Brain className="w-6 h-6 text-[#8B5CF6]" />
                جلسة المراجعة وتثبيت المفاهيم مع {teacher.name} 🧠
              </h3>
            </div>

            {revisionCards.length === 0 && (
              <button
                disabled={loadingRevision}
                onClick={handleStartPersonalizedRevision}
                className="px-6 py-3 rounded-2xl bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:opacity-50 text-white font-extrabold text-xs shadow-lg flex items-center gap-2 cursor-pointer transition-all active:scale-95 shrink-0"
              >
                {loadingRevision ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    <span>Gemini يولد أمثلة وتشبيهات جديدة...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>ابدأ جلسة علاج الأخطاء ({mistakes.length} مفاهيم)</span>
                  </>
                )}
              </button>
            )}
          </div>

          <p className="text-xs text-stone-600 leading-relaxed max-w-3xl mb-6">
            بدلاً من مجرد عرض الخطأ، يقوم نموذج Gemini بصياغة شرح مخصص بأسلوب المعلم {teacher.name}، مع تشبيه مصري جديد تمامًا وسؤال متابعة تفاعلي لضمان أن الفكرة ثبتت في عقلك بنسبة 100%.
          </p>

          {revisionError && (
            <div className="mb-4 p-3 rounded-xl bg-rose-100 border border-rose-300 text-rose-800 text-xs">
              {revisionError}
            </div>
          )}

          {/* Mastered Progress Tracker */}
          {revisionCards.length > 0 && (
            <div className="mb-6 p-4 rounded-2xl bg-white border border-purple-200 shadow-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-purple-600" />
                <span className="text-xs font-bold text-stone-800">
                  تقدم تثبيت المفاهيم: {masteredCount} من {revisionCards.length}
                </span>
              </div>
              <div className="flex-1 max-w-xs bg-stone-100 rounded-full h-2.5 overflow-hidden">
                <div
                  className="bg-emerald-500 h-full transition-all duration-500"
                  style={{ width: `${(masteredCount / revisionCards.length) * 100}%` }}
                />
              </div>
              {allMastered && (
                <span className="text-xs font-extrabold text-emerald-600 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  تم تثبيت كل المفاهيم بنجاح! 🎉
                </span>
              )}
            </div>
          )}

          {/* Revision Cards Grid */}
          {revisionCards.length > 0 && (
            <div className="space-y-6">
              {revisionCards.map((card, cIdx) => {
                const isMastered = Boolean(masteredCards[cIdx]);
                const userSelectedOption = selectedCheckAnswers[cIdx];

                return (
                  <div
                    key={cIdx}
                    className={`rounded-2xl border-2 p-5 sm:p-6 transition-all bg-white ${
                      isMastered
                        ? 'border-emerald-300 shadow-md ring-1 ring-emerald-300'
                        : 'border-purple-200 shadow-sm'
                    }`}
                  >
                    {/* Header */}
                    <div className="flex items-center justify-between gap-2 mb-3 pb-2 border-b border-stone-100">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-purple-100 text-purple-700 text-xs font-bold flex items-center justify-center">
                          {cIdx + 1}
                        </span>
                        <h4 className="font-extrabold text-sm text-stone-900">
                          علاج مفهوم: {card.conceptTag}
                        </h4>
                      </div>

                      <div className="flex items-center gap-2">
                        {isMastered && (
                          <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                            <Check className="w-3 h-3 stroke-[3]" />
                            تم التثبيت 🎯
                          </span>
                        )}
                        <button
                          onClick={() => {
                            soundManager.playClick();
                            onJumpToSection(card.sectionIndex || 0);
                          }}
                          className="px-3 py-1 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <BookOpen className="w-3 h-3 text-[#8B5CF6]" />
                          <span>فتح سبورة الفصل</span>
                        </button>
                      </div>
                    </div>

                    {/* Teacher Explanation in persona */}
                    <div className="bg-[#FAF7F2] p-4 rounded-xl border border-[#E6DFD3] text-xs text-stone-800 leading-relaxed mb-3">
                      <span className="font-bold text-[#8B5CF6] block mb-1">
                        توضيح المعلم {teacher.name}:
                      </span>
                      {card.teacherExplanation}
                    </div>

                    {/* Fresh Egyptian Analogy Card */}
                    <div className="bg-amber-50/70 p-3.5 rounded-xl border border-amber-200 text-xs text-amber-950 leading-relaxed mb-4">
                      <span className="font-bold text-amber-800 flex items-center gap-1 mb-1">
                        <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                        تشبيه ومثال واقعي جديد:
                      </span>
                      {card.newAnalogyExample}
                    </div>

                    {/* Follow-up Interactive Check */}
                    {card.followUpCheck && (
                      <div className="bg-stone-50 rounded-xl p-4 border border-stone-200">
                        <span className="text-xs font-bold text-stone-700 block mb-2">
                          اختبار سريع لتأكيد التثبيت: {card.followUpCheck.prompt}
                        </span>

                        <div className="space-y-2">
                          {card.followUpCheck.options.map((opt, optIdx) => {
                            const isChosen = userSelectedOption === optIdx;
                            const isCorrectOpt = optIdx === card.followUpCheck.correctOptionIndex;

                            return (
                              <button
                                key={optIdx}
                                onClick={() =>
                                  handleSelectCheckOption(
                                    cIdx,
                                    optIdx,
                                    card.followUpCheck.correctOptionIndex
                                  )
                                }
                                className={`w-full p-2.5 rounded-xl border text-right text-xs font-semibold transition-all flex items-center justify-between cursor-pointer ${
                                  isChosen
                                    ? isCorrectOpt
                                      ? 'bg-emerald-100 border-emerald-400 text-emerald-900 font-bold'
                                      : 'bg-rose-100 border-rose-400 text-rose-900'
                                    : 'bg-white hover:bg-stone-100 text-stone-800 border-stone-200'
                                }`}
                              >
                                <span>{opt}</span>
                                {isChosen && (
                                  <span className="text-xs">
                                    {isCorrectOpt ? '✓ صحيح' : '✗ غير دقيق'}
                                  </span>
                                )}
                              </button>
                            );
                          })}
                        </div>

                        {userSelectedOption !== undefined && (
                          <div className="mt-2 text-[11px] text-stone-600 pt-2 border-t border-stone-200">
                            <span className="font-bold">التفسير: </span>
                            {card.followUpCheck.explanation}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Suggested Review Topics Strip */}
      {result.suggestedTopics.length > 0 && (
        <div className="mb-8 bg-amber-50 rounded-2xl border-2 border-amber-200 p-6 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-5 h-5 text-amber-600" />
            <h3 className="font-extrabold text-base text-amber-950 font-chalk">
              فصول وموضوعات سبورة المنهج الموصى بها:
            </h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {result.suggestedTopics.map((topic, idx) => (
              <div
                key={idx}
                className="bg-white rounded-xl p-3.5 border border-amber-200/80 flex items-center justify-between gap-3 shadow-xs"
              >
                <div>
                  <span className="font-bold text-xs text-stone-900 block">
                    {topic.title}
                  </span>
                  <span className="text-[11px] text-stone-500 block mt-0.5">
                    {topic.reason}
                  </span>
                  {topic.pageReference && (
                    <span className="text-[10px] text-purple-700 font-mono block mt-1">
                      صفحات الـ PDF: {topic.pageReference}
                    </span>
                  )}
                </div>
                <button
                  onClick={() => {
                    soundManager.playClick();
                    onJumpToSection(topic.sectionIndex);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-[#1A1F24] hover:bg-[#2C333D] text-[#FDE047] text-xs font-bold transition-all shrink-0 cursor-pointer"
                >
                  افتح الفصل ←
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Detailed Mistakes & Explanations Breakdown */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 shadow-sm mb-8">
        <h3 className="text-xl font-black text-[#1E232A] font-chalk mb-4">
          تحليل جميع أسئلة الامتحان والإجابات النموذجية:
        </h3>

        <div className="space-y-4">
          {result.details.map((item, idx) => (
            <div
              key={item.questionId}
              className={`p-4 rounded-xl border transition-all ${
                item.isCorrect
                  ? 'bg-emerald-50/40 border-emerald-200'
                  : 'bg-rose-50/40 border-rose-200'
              }`}
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="flex items-center gap-2">
                  {item.isCorrect ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
                  )}
                  <h4 className="font-bold text-sm text-stone-900">
                    س {idx + 1}: {item.questionPrompt}
                  </h4>
                </div>
                <span
                  className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                    item.isCorrect
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {item.isCorrect ? 'إجابة صحيحة' : 'خطأ في الحل'}
                </span>
              </div>

              {/* Answers Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 my-2 text-xs">
                <div className="bg-white/80 p-2.5 rounded-lg border border-stone-200">
                  <span className="text-stone-500 block mb-0.5 font-semibold">إجابتك:</span>
                  <span
                    className={`font-bold ${
                      item.isCorrect ? 'text-emerald-700' : 'text-rose-700'
                    }`}
                  >
                    {item.userAnswer}
                  </span>
                </div>

                <div className="bg-white/80 p-2.5 rounded-lg border border-stone-200">
                  <span className="text-stone-500 block mb-0.5 font-semibold">الإجابة النموذجية:</span>
                  <span className="font-bold text-emerald-700">
                    {item.correctAnswer}
                  </span>
                </div>
              </div>

              {/* Explanation Note */}
              <div className="mt-2 pt-2 border-t border-stone-200/60 text-xs text-stone-700 flex items-start gap-1.5 leading-relaxed">
                <span className="text-[#8B5CF6] font-bold shrink-0">التفسير والسر:</span>
                <span>{item.explanation}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Actions Strip */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <button
          onClick={onReturnToRoom}
          className="px-5 py-2.5 rounded-xl border border-stone-300 hover:bg-stone-100 font-bold text-xs text-stone-700 flex items-center gap-2 transition-colors cursor-pointer"
        >
          <Home className="w-4 h-4" />
          <span>العودة لشقة الفهيم (كتاب جديد)</span>
        </button>

        <button
          onClick={onRetakeExam}
          className="px-6 py-2.5 rounded-xl bg-[#1A1F24] hover:bg-[#2C333D] text-[#FDE047] font-extrabold text-xs flex items-center gap-2 shadow-md transition-all cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>إعادة الاختبار وتحسين الدرجة</span>
        </button>
      </div>
    </div>
  );
};
