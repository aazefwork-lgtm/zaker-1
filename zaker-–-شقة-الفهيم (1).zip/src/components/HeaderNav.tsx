import React from 'react';
import { ScreenType } from '../types/index.ts';
import { Sliders, Volume2, VolumeX, Lightbulb, Home, RotateCcw } from 'lucide-react';

interface HeaderNavProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
  onOpenSettings: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  lampOn: boolean;
  onToggleLamp: () => void;
  onReplayIntro: () => void;
  hasLoadedBook: boolean;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  currentScreen,
  onNavigate,
  onOpenSettings,
  soundEnabled,
  onToggleSound,
  lampOn,
  onToggleLamp,
  onReplayIntro,
  hasLoadedBook,
}) => {
  const steps: { id: ScreenType; label: string; minReqBook?: boolean }[] = [
    { id: 'room', label: 'شقة الفهيم' },
    { id: 'analysis', label: 'التحليل', minReqBook: true },
    { id: 'teachers', label: 'المعلم', minReqBook: true },
    { id: 'output_settings', label: 'العرض', minReqBook: true },
    { id: 'lesson', label: 'السبورة', minReqBook: true },
    { id: 'exam', label: 'الامتحان', minReqBook: true },
    { id: 'results', label: 'النتيجة', minReqBook: true },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#FAF7F2]/90 backdrop-blur-md border-b border-[#E6DFD3] px-4 lg:px-8 py-3 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Zone 1: Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onNavigate('room')}
            className="flex items-center gap-2 group text-right focus:outline-none"
            title="العودة لشقة الفهيم"
          >
            <span className="w-8 h-8 rounded-lg bg-[#1A1F24] border border-[#5C3A21] flex items-center justify-center text-[#FDE047] font-bold text-sm shadow-sm group-hover:scale-105 transition-transform">
              Z
            </span>
            <div className="flex flex-col">
              <span className="font-extrabold text-lg tracking-tight text-[#1E232A] group-hover:text-[#5C3A21] transition-colors leading-none">
                ZAKER
              </span>
              <span className="text-[11px] font-semibold text-[#8B5CF6] tracking-wide">
                شقة الفهيم
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Steps */}
        <nav className="hidden md:flex items-center gap-1 overflow-x-auto py-1 px-2 scrollbar-none">
          {steps.map((step, idx) => {
            const isActive = currentScreen === step.id;
            const isDisabled = step.minReqBook && !hasLoadedBook;
            return (
              <React.Fragment key={step.id}>
                {idx > 0 && (
                  <span className="text-xs text-[#D1C7B7] select-none px-1">/</span>
                )}
                <button
                  onClick={() => !isDisabled && onNavigate(step.id)}
                  disabled={isDisabled}
                  className={`text-xs font-semibold px-2.5 py-1 rounded-md transition-all whitespace-nowrap ${
                    isActive
                      ? 'bg-[#1A1F24] text-[#FDE047] shadow-sm'
                      : isDisabled
                      ? 'text-[#C5BBAA] cursor-not-allowed'
                      : 'text-[#5A6372] hover:text-[#1E232A] hover:bg-[#EFE9DF]'
                  }`}
                >
                  {step.label}
                </button>
              </React.Fragment>
            );
          })}
        </nav>

        {/* Zone 3: Quick Room Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <button
            onClick={onToggleLamp}
            title={lampOn ? 'إطفاء لمبة المكتب' : 'تشغيل لمبة المكتب'}
            className={`p-2 rounded-lg text-xs font-medium border transition-colors ${
              lampOn
                ? 'bg-amber-100/80 text-amber-900 border-amber-300'
                : 'bg-stone-100 text-stone-500 border-stone-200'
            }`}
          >
            <Lightbulb className={`w-4 h-4 ${lampOn ? 'text-amber-500 fill-amber-400' : ''}`} />
          </button>

          <button
            onClick={onToggleSound}
            title={soundEnabled ? 'كتم مؤثرات الطباشير' : 'تشغيل مؤثرات الطباشير'}
            className={`p-2 rounded-lg text-xs font-medium border transition-colors ${
              soundEnabled
                ? 'bg-purple-100/80 text-purple-900 border-purple-300'
                : 'bg-stone-100 text-stone-500 border-stone-200'
            }`}
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-purple-600" />
            ) : (
              <VolumeX className="w-4 h-4 text-stone-400" />
            )}
          </button>

          <button
            onClick={onReplayIntro}
            title="إعادة تشغيل مقدمة السبورة"
            className="p-2 rounded-lg text-xs font-medium border border-stone-200 bg-[#FAF7F2] text-stone-700 hover:bg-[#F2ECE1] transition-colors"
          >
            <RotateCcw className="w-4 h-4 text-stone-600" />
          </button>

          <button
            onClick={onOpenSettings}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-[#1A1F24] text-white hover:bg-[#2C333D] transition-colors shadow-sm"
          >
            <Sliders className="w-3.5 h-3.5 text-[#FDE047]" />
            <span className="hidden sm:inline">لوحة الإعدادات</span>
          </button>
        </div>
      </div>
    </header>
  );
};
