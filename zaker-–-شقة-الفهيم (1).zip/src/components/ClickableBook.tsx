import React, { useRef, useState } from 'react';
import { FileUp, BookMarked, AlertCircle, Sparkles } from 'lucide-react';
import { soundManager } from '../utils/audioSynth.ts';

interface ClickableBookProps {
  onFileSelected: (file: File) => void;
  maxUploadSizeMB: number;
  onSelectSampleBook: (sampleId: string) => void;
}

export const ClickableBook: React.FC<ClickableBookProps> = ({
  onFileSelected,
  maxUploadSizeMB,
  onSelectSampleBook,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const validateAndHandleFile = (file: File) => {
    setErrorMessage(null);

    // Validate mime type and extension
    const isPdf =
      file.type === 'application/pdf' ||
      file.name.toLowerCase().endsWith('.pdf');

    if (!isPdf) {
      soundManager.playChime(false);
      setErrorMessage('يا بطل، الملف لازم يكون بصيغة PDF فقط!');
      return;
    }

    // Validate size
    const maxBytes = maxUploadSizeMB * 1024 * 1024;
    if (file.size > maxBytes) {
      soundManager.playChime(false);
      const actualSizeMB = (file.size / (1024 * 1024)).toFixed(1);
      setErrorMessage(
        `حجم الملف (${actualSizeMB} ميجا) أكبر من الحد الأقصى المسموح (${maxUploadSizeMB} ميجابايت). حاول تضغط الملف أو اختار نموذج جاهز!`
      );
      return;
    }

    soundManager.playChime(true);
    onFileSelected(file);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      validateAndHandleFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndHandleFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="flex flex-col items-center w-full max-w-lg">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleInputChange}
        accept="application/pdf,.pdf"
        className="hidden"
      />

      {/* The Desk Book Element */}
      <div
        onClick={() => fileInputRef.current?.click()}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            fileInputRef.current?.click();
          }
        }}
        className={`group relative w-full aspect-[16/9] sm:aspect-[2.2/1] rounded-2xl cursor-pointer transition-all duration-300 p-6 flex flex-col justify-between select-none shadow-2xl ${
          isDragging
            ? 'scale-105 bg-[#3B2211] ring-4 ring-[#FDE047] ring-offset-4 ring-offset-[#FAF7F2]'
            : 'bg-gradient-to-br from-[#4A2D17] via-[#5C3A21] to-[#3B2211] hover:scale-[1.02] hover:-translate-y-1'
        } border-4 border-[#7A4B29]`}
      >
        {/* Book Spine Texture Edge */}
        <div className="absolute right-0 top-0 bottom-0 w-6 bg-[#2B170A] rounded-r-xl border-l-2 border-[#54321A] flex flex-col justify-between py-4 items-center">
          <div className="w-1.5 h-6 bg-[#D97706]/70 rounded-full" />
          <div className="w-1.5 h-6 bg-[#D97706]/70 rounded-full" />
          <div className="w-1.5 h-6 bg-[#D97706]/70 rounded-full" />
        </div>

        {/* Bookmark Ribbon hanging off bottom */}
        <div className="absolute -bottom-5 right-12 w-4 h-9 bg-rose-600 rounded-b shadow-md flex items-end justify-center pb-1">
          <div className="w-2 h-2 bg-amber-400 rotate-45" />
        </div>

        {/* Top Header of the Book */}
        <div className="flex items-center justify-between pl-8">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-amber-500/20 text-[#FDE047] flex items-center justify-center border border-amber-500/30">
              <FileUp className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold text-amber-200 tracking-wider">
              رفع وتفكيك المذكرات
            </span>
          </div>
          <span className="text-[11px] font-mono text-stone-300/80 bg-black/30 px-2 py-0.5 rounded border border-white/10">
            PDF فقط · حد أقصى {maxUploadSizeMB} ميجا
          </span>
        </div>

        {/* Center Main Book Callout Label */}
        <div className="my-auto pl-8 text-center sm:text-right">
          <h3 className="text-2xl sm:text-3xl font-black text-[#FAF7F2] font-chalk drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] tracking-wide group-hover:text-[#FDE047] transition-colors">
            « ارمي الكتاب اللي خنقك هنا »
          </h3>
          <p className="mt-1 text-xs sm:text-sm text-stone-300 font-medium">
            دوس هنا لاختيار ملف PDF من جهازك أو اسحب الملف وأفلته مباشرة على الكتاب
          </p>
        </div>

        {/* Bottom Action Footer */}
        <div className="flex items-center justify-between pl-8 pt-2 border-t border-white/10 text-xs text-stone-300">
          <span className="flex items-center gap-1.5 text-stone-400">
            <BookMarked className="w-3.5 h-3.5 text-[#FDE047]" />
            ملف المنهج أو ملخص المحاضرة
          </span>
          <span className="font-bold text-[#FDE047] group-hover:underline">
            اضغط للرفع الآن ←
          </span>
        </div>
      </div>

      {/* Error message banner if validation fails */}
      {errorMessage && (
        <div className="mt-3 w-full bg-rose-50 border border-rose-200 text-rose-900 rounded-xl p-3 text-xs flex items-start gap-2 animate-in fade-in slide-in-from-top-1">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-bold">خطأ في الملف:</p>
            <p className="mt-0.5">{errorMessage}</p>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="text-stone-400 hover:text-stone-700 font-bold px-1"
          >
            ×
          </button>
        </div>
      )}

      {/* Quick Sample Selector for immediate 1-click test without needing a local PDF */}
      <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-xs">
        <span className="text-stone-500 font-semibold flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5 text-[#8B5CF6]" />
          أو جرّب نموذج جاهز فورًا:
        </span>
        <button
          onClick={() => onSelectSampleBook('sample_physics')}
          className="px-2.5 py-1 rounded-md bg-amber-100/70 hover:bg-amber-100 text-amber-900 font-bold border border-amber-200 transition-colors cursor-pointer"
        >
          فيزياء 3 ثانوي ⚡
        </button>
        <button
          onClick={() => onSelectSampleBook('sample_arabic')}
          className="px-2.5 py-1 rounded-md bg-emerald-100/70 hover:bg-emerald-100 text-emerald-900 font-bold border border-emerald-200 transition-colors cursor-pointer"
        >
          عربي ونحو 📜
        </button>
        <button
          onClick={() => onSelectSampleBook('sample_history')}
          className="px-2.5 py-1 rounded-md bg-purple-100/70 hover:bg-purple-100 text-purple-900 font-bold border border-purple-200 transition-colors cursor-pointer"
        >
          تاريخ مصر ⏳
        </button>
      </div>
    </div>
  );
};
