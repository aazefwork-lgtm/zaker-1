import React, { useEffect, useState } from 'react';
import { soundManager } from '../utils/audioSynth.ts';
import { ArrowLeft, Sparkles, Volume2 } from 'lucide-react';

interface IntroScreenProps {
  onComplete: () => void;
  soundEnabled: boolean;
}

export const IntroScreen: React.FC<IntroScreenProps> = ({ onComplete, soundEnabled }) => {
  // Stages:
  // 0: Initial black
  // 1: Writing "ZAKER" (0 - 1.2s)
  // 2: Erasing with eraser swipe (1.2s - 2.1s)
  // 3: Writing "يلا نذاكر؟" (2.1s - 3.4s)
  // 4: Complete ready to transition
  const [stage, setStage] = useState<number>(0);
  const [eraserPos, setEraserPos] = useState<number>(0);

  useEffect(() => {
    soundManager.setEnabled(soundEnabled);

    // Stage 1: write ZAKER
    const timer1 = setTimeout(() => {
      setStage(1);
      soundManager.playChalkScratch();
    }, 200);

    // Stage 2: Erase
    const timer2 = setTimeout(() => {
      setStage(2);
      soundManager.playEraserSwipe();
      setEraserPos(100);
    }, 1300);

    // Stage 3: Write "يلا نذاكر؟"
    const timer3 = setTimeout(() => {
      setStage(3);
      soundManager.playChalkScratch();
    }, 2200);

    // Stage 4: Auto complete
    const timer4 = setTimeout(() => {
      setStage(4);
      soundManager.playChime(true);
    }, 3600);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [soundEnabled]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#13171B] p-4 sm:p-8 select-none">
      {/* Background Chalk Dust Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.03)_0%,transparent_70%)] pointer-events-none" />

      {/* Top Skip Control */}
      <div className="absolute top-6 left-6 z-20">
        <button
          onClick={onComplete}
          className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-[#FAF7F2] text-sm font-semibold tracking-wide backdrop-blur-sm border border-white/15 transition-all flex items-center gap-2 group cursor-pointer"
        >
          <span>تخطي المقدمة</span>
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
        </button>
      </div>

      {/* The Iconic Central Chalkboard */}
      <div className="relative w-full max-w-3xl aspect-[16/10] sm:aspect-[16/9] rounded-2xl chalkboard-surface chalkboard-border flex flex-col items-center justify-center p-8 overflow-hidden shadow-2xl">
        {/* Chalk dust marks on chalkboard corners */}
        <div className="absolute top-3 left-4 text-xs font-handwriting text-white/15 select-none pointer-events-none">
          E = mc² · \int f(x)dx
        </div>
        <div className="absolute bottom-10 right-6 text-xs font-handwriting text-white/15 select-none pointer-events-none">
          ZAKER faheem 2026
        </div>

        {/* Chalk Eraser Visual Animation during stage 2 */}
        {stage === 2 && (
          <div
            className="absolute top-1/2 -translate-y-1/2 z-30 transition-all duration-700 ease-in-out pointer-events-none"
            style={{
              left: `${eraserPos}%`,
              transform: 'translate(-50%, -50%) rotate(-8deg)',
            }}
          >
            <div className="w-24 h-12 rounded bg-[#7A4B29] border-2 border-[#4A2D17] shadow-xl flex items-center justify-center relative">
              <div className="absolute inset-0 bg-[#3B2211] top-3 rounded-b" />
              <span className="text-[10px] text-white/60 font-bold uppercase tracking-wider relative z-10">
                مساحة الفهيم
              </span>
            </div>
            {/* Eraser dust puff */}
            <div className="w-16 h-8 bg-white/20 blur-md rounded-full mt-1" />
          </div>
        )}

        {/* Dynamic Writing Content */}
        <div className="relative z-10 text-center flex flex-col items-center justify-center min-h-[160px]">
          {stage === 1 && (
            <div className="animate-in fade-in zoom-in-95 duration-500">
              <h1 className="font-extrabold text-6xl sm:text-8xl tracking-widest chalk-text-white font-mono uppercase">
                ZAKER
              </h1>
              <p className="mt-3 text-sm text-[#FDE047]/80 font-mono tracking-wider">
                CHALKBOARD LEARNING EXPERIENCE
              </p>
            </div>
          )}

          {stage >= 3 && (
            <div className="animate-in fade-in zoom-in-90 duration-500 flex flex-col items-center">
              <span className="text-sm font-semibold text-[#8B5CF6] tracking-wide mb-2 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#FDE047]" />
                شقة الفهيم ترحب بك
              </span>
              <h2 className="font-black text-6xl sm:text-8xl text-[#FDE047] font-chalk drop-shadow-[0_2px_8px_rgba(253,224,71,0.4)]">
                يلا نذاكر؟
              </h2>
              <p className="mt-4 text-stone-300 text-sm sm:text-base font-medium max-w-md">
                ارمي الكتاب اللي خنقك على المكتب.. والفهيم هيفرتكلك المنهج كبسولة كبسولة!
              </p>

              {/* Ready button */}
              <button
                onClick={onComplete}
                className="mt-6 px-6 py-2.5 rounded-xl bg-[#FDE047] hover:bg-[#FACC15] text-[#1E232A] font-extrabold text-base shadow-lg hover:shadow-yellow-400/20 active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>ادخل الشقة وابدأ</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          )}

          {stage === 0 && (
            <div className="text-white/20 text-sm font-mono animate-pulse">
              جاري تجهيز الطباشير والسبورة...
            </div>
          )}
        </div>

        {/* Chalk Tray at bottom of board */}
        <div className="absolute bottom-0 inset-x-0 h-4 bg-[#4A2D17] border-t border-[#6B4226] flex items-center justify-end px-6 gap-3 shadow-inner">
          {/* Chalk pieces */}
          <div className="w-8 h-2 bg-white rounded-full opacity-90 shadow-sm" />
          <div className="w-6 h-2 bg-[#FDE047] rounded-full opacity-90 shadow-sm" />
          <div className="w-7 h-2 bg-[#67E8F9] rounded-full opacity-80 shadow-sm" />
          <div className="w-9 h-2 bg-[#F472B6] rounded-full opacity-80 shadow-sm" />
          {/* Mini Eraser */}
          <div className="w-12 h-2.5 bg-[#8C5E3B] rounded-sm border border-[#3B2211]" />
        </div>
      </div>
    </div>
  );
};
