import React, { useState, useEffect } from 'react';
import { ExamQuestion, ExamResult, QuestionCategory, TeacherProfile } from '../types/index.ts';
import { soundManager } from '../utils/audioSynth.ts';
import { speechRecognitionManager } from '../utils/speechSynth.ts';
import {
  FileText,
  Mic,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  Sparkles,
  HelpCircle,
  Square,
  Play,
  RotateCcw,
  PenTool,
  Send,
  Loader2,
  Bookmark,
  Check,
  Flame,
  MessageSquare,
} from 'lucide-react';

interface ExamScreenProps {
  questions: ExamQuestion[];
  teacher: TeacherProfile;
  studentName: string;
  onFinishExam: (result: ExamResult) => void;
  onBackToLesson: () => void;
}

export const ExamScreen: React.FC<ExamScreenProps> = ({
  questions,
  teacher,
  studentName,
  onFinishExam,
  onBackToLesson,
}) => {
  // Modes: 'written' or 'oral'
  const [examMode, setExamMode] = useState<'written' | 'oral'>('written');
  const [currentIndex, setCurrentIndex] = useState(0);

  // User answers
  // For mcq: option index (number)
  // For true_false: boolean
  // For short_answer: string
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, any>>({});
  const [shortAnswers, setShortAnswers] = useState<Record<string, string>>({});
  const [scratchpadText, setScratchpadText] = useState('');
  const [showScratchpad, setShowScratchpad] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(480); // 8 minutes

  // Oral Exam Real States
  const [oralInputText, setOralInputText] = useState('');
  const [isListeningMic, setIsListeningMic] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);
  const [evaluatingOral, setEvaluatingOral] = useState(false);
  const [oralEvaluations, setOralEvaluations] = useState<
    Record<
      string,
      {
        score: number;
        isAccurate: boolean;
        feedback: string;
        missingPoints: string[];
        followUpQuestion?: string;
        userAnswer: string;
      }
    >
  >({});
  const [followUpAnswer, setFollowUpAnswer] = useState('');

  // Questions filtered by mode
  // Written: all mcq, true_false, and short_answer questions
  // Oral: oral questions (or if none marked oral, all questions can be answered orally)
  const writtenQuestions = questions.filter((q) => q.type !== 'oral');
  const oralQuestions = questions.some((q) => q.type === 'oral')
    ? questions.filter((q) => q.type === 'oral')
    : questions;

  const activeQuestionList = examMode === 'oral' ? oralQuestions : writtenQuestions;
  const currentQ = activeQuestionList[currentIndex] || activeQuestionList[0] || questions[0];

  // Timer countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setTimerSeconds((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Update oralInputText when switching questions
  useEffect(() => {
    if (examMode === 'oral' && currentQ) {
      const existing = oralEvaluations[currentQ.id];
      if (existing) {
        setOralInputText(existing.userAnswer || '');
      } else {
        setOralInputText('');
      }
      setFollowUpAnswer('');
    }
  }, [currentIndex, examMode, currentQ]);

  // Handle MCQ selection
  const handleSelectMcq = (optIndex: number) => {
    soundManager.playClick();
    setSelectedAnswers((prev) => ({
      ...prev,
      [currentQ.id]: optIndex,
    }));
  };

  // Handle True / False selection
  const handleSelectTrueFalse = (val: boolean) => {
    soundManager.playClick();
    setSelectedAnswers((prev) => ({
      ...prev,
      [currentQ.id]: val,
    }));
  };

  // Handle Short Answer input
  const handleShortAnswerChange = (text: string) => {
    setShortAnswers((prev) => ({
      ...prev,
      [currentQ.id]: text,
    }));
  };

  // Mic Speech Recognition for Oral Exam
  const handleToggleMic = () => {
    setMicError(null);
    if (isListeningMic) {
      speechRecognitionManager.stop();
      setIsListeningMic(false);
      soundManager.playClick();
    } else {
      soundManager.playClick();
      setIsListeningMic(true);
      speechRecognitionManager.start(
        (transcript, _isFinal) => {
          setOralInputText((prev) => (prev ? `${prev} ${transcript}` : transcript));
        },
        (err) => {
          setMicError(err);
          setIsListeningMic(false);
        }
      );
    }
  };

  // Submit Oral Answer to Real Gemini Backend
  const handleSubmitOralAnswer = async () => {
    if (!oralInputText.trim()) {
      setMicError('يرجى التحدث أو كتابة إجابتك الشفوية أولاً.');
      return;
    }

    if (isListeningMic) {
      speechRecognitionManager.stop();
      setIsListeningMic(false);
    }

    setEvaluatingOral(true);
    setMicError(null);
    soundManager.playClick();

    try {
      const response = await fetch('/api/evaluate-oral', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          questionPrompt: currentQ.prompt,
          modelAnswer: currentQ.modelAnswer,
          userAnswerText: oralInputText.trim(),
          teacherId: teacher.id,
          topicTag: currentQ.topicTag,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'تعذر تقييم الإجابة الشفوية.');
      }

      const evalData = data.evaluation;
      setOralEvaluations((prev) => ({
        ...prev,
        [currentQ.id]: {
          ...evalData,
          userAnswer: oralInputText.trim(),
        },
      }));

      soundManager.playChime(evalData.isAccurate);
    } catch (err: any) {
      console.error('Oral eval error:', err);
      setMicError(err?.message || 'حدث خطأ أثناء تقييم الإجابة الشفوية بواسطة الذكاء الاصطناعي.');
    } finally {
      setEvaluatingOral(false);
    }
  };

  // Calculate final exam results
  const calculateFinalResults = (): ExamResult => {
    let correctCount = 0;
    const questionsToGrade = examMode === 'oral' ? oralQuestions : writtenQuestions;

    const details = questionsToGrade.map((q) => {
      let isCorrect = false;
      let userAnsStr = 'لم يتم الحل';
      let correctAnsStr = q.modelAnswer;

      if (examMode === 'oral') {
        const oralRes = oralEvaluations[q.id];
        if (oralRes) {
          isCorrect = oralRes.isAccurate || oralRes.score >= 6;
          userAnsStr = oralRes.userAnswer || 'إجابة شفوية';
        }
      } else {
        if (q.type === 'mcq') {
          const userChoice = selectedAnswers[q.id];
          if (userChoice !== undefined && q.options) {
            userAnsStr = q.options[userChoice] || 'لم يتم الاختيار';
            isCorrect = userChoice === q.correctOptionIndex;
          }
        } else if (q.type === 'true_false') {
          const userChoice = selectedAnswers[q.id];
          if (typeof userChoice === 'boolean') {
            userAnsStr = userChoice ? 'صواب' : 'خطأ';
            isCorrect = userChoice === q.correctBoolean;
          }
        } else {
          // short_answer
          const txt = shortAnswers[q.id] || '';
          userAnsStr = txt.trim() || 'لم يتم الإدخال';
          isCorrect = txt.trim().length > 3; // Basic submission credit
        }
      }

      if (isCorrect) correctCount++;

      return {
        questionId: q.id,
        questionPrompt: q.prompt,
        category: q.category || 'concept',
        difficulty: q.difficulty || 'medium',
        userAnswer: userAnsStr,
        correctAnswer: correctAnsStr,
        isCorrect,
        explanation: q.explanation,
        pageReference: q.pageReference,
        topicTag: q.topicTag,
        sectionIndex: q.sectionIndex || 0,
      };
    });

    const totalQuestions = questionsToGrade.length;
    const percentage = totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0;
    const passed = percentage >= 60;

    let gradeMessage = 'عاش يا بطل! مستواك ممتاز وواضح أنك مركز وفهمت الزتونة صح.';
    if (percentage < 60) {
      gradeMessage = 'معلش يا بطل، الكبوة بتعلم الشاطر! ادخل على جلسة علاج الأخطاء والمراجعة الذكية وهتقفلها.';
    } else if (percentage === 100) {
      gradeMessage = 'درجة نهائية عبقرية! الفهيم فخور بيك يا دكتور.';
    }

    const suggestedTopics = details
      .filter((d) => !d.isCorrect)
      .map((d) => ({
        title: d.topicTag,
        topicTag: d.topicTag,
        sectionIndex: d.sectionIndex,
        reason: 'وقع منك سؤال في هذا المفهوم، ينصح بمراجعة سبورة الفصل مرة أخرى.',
        pageReference: d.pageReference,
      }));

    return {
      id: `result_${Date.now()}`,
      score: correctCount,
      totalQuestions,
      percentage,
      passed,
      gradeMessage,
      difficulty: 'medium',
      details,
      suggestedTopics,
      completedAt: new Date().toISOString(),
    };
  };

  const handleFinish = () => {
    const res = calculateFinalResults();
    soundManager.playChime(res.passed);
    onFinishExam(res);
  };

  const minutes = Math.floor(timerSeconds / 60);
  const seconds = timerSeconds % 60;
  const timerFormatted = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

  const categoryLabels: Record<QuestionCategory, { label: string; color: string }> = {
    concept: { label: 'استيعاب ومفاهيم', color: 'bg-blue-50 text-blue-700 border-blue-200' },
    application: { label: 'تطبيق واستدلال', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
    comparison: { label: 'مقارنات وأسباب', color: 'bg-purple-50 text-purple-700 border-purple-200' },
    error_detection: { label: 'كشف مغالطات', color: 'bg-amber-50 text-amber-700 border-amber-200' },
    synthesis: { label: 'تحليل وتربيط', color: 'bg-rose-50 text-rose-700 border-rose-200' },
  };

  const catBadge = currentQ && currentQ.category && categoryLabels[currentQ.category]
    ? categoryLabels[currentQ.category]
    : categoryLabels.concept;

  return (
    <div className="max-w-5xl mx-auto py-6 px-4 sm:px-6">
      {/* Exam Header */}
      <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-sm mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold text-[#8B5CF6]">
              امتحان شقة الفهيم التفاعلي
            </span>
            <span className="text-xs text-stone-300">·</span>
            <span className="text-xs font-medium text-stone-500">
              طالبنا الغالي: {studentName || 'البطل'}
            </span>
            <span className="text-xs text-stone-300">·</span>
            <span className="text-xs font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
              إشراف المعلم {teacher.name}
            </span>
          </div>
          <h2 className="text-2xl font-black text-[#1E232A] font-chalk">
            {examMode === 'written' ? 'الامتحان التحريري الشامل' : 'الامتحان الشفوي المباشر مع الذكاء الاصطناعي'}
          </h2>
        </div>

        {/* Mode Switcher & Timer */}
        <div className="flex items-center gap-3">
          <div className="flex bg-stone-100 p-1 rounded-xl">
            <button
              onClick={() => {
                soundManager.playClick();
                setExamMode('written');
                setCurrentIndex(0);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                examMode === 'written'
                  ? 'bg-white text-stone-900 shadow-sm'
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>تحريري ({writtenQuestions.length})</span>
            </button>
            <button
              onClick={() => {
                soundManager.playClick();
                setExamMode('oral');
                setCurrentIndex(0);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                examMode === 'oral'
                  ? 'bg-white text-stone-900 shadow-sm'
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              <Mic className="w-3.5 h-3.5 text-purple-600" />
              <span>شفوي بالصوت</span>
            </button>
          </div>

          <div
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-mono font-bold ${
              timerSeconds < 60
                ? 'bg-rose-50 text-rose-700 border-rose-300 animate-pulse'
                : 'bg-amber-50 text-amber-900 border-amber-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>{timerFormatted}</span>
          </div>

          <button
            onClick={() => setShowScratchpad(!showScratchpad)}
            title="فتح مسودة الحسابات والملاحظات"
            className={`p-2 rounded-xl border text-xs font-bold transition-colors cursor-pointer ${
              showScratchpad
                ? 'bg-[#1A1F24] text-[#FDE047] border-[#1A1F24]'
                : 'border-stone-200 hover:bg-stone-100 text-stone-700'
            }`}
          >
            <PenTool className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Exam Canvas Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left / Center: Question Box (8 or 12 cols depending on scratchpad) */}
        <div className={`${showScratchpad ? 'lg:col-span-8' : 'lg:col-span-12'} bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-md`}>
          {/* Question Metadata Header */}
          <div className="flex flex-wrap items-center justify-between gap-2 mb-4 pb-3 border-b border-stone-100">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-stone-500">
                سؤال {currentIndex + 1} من {activeQuestionList.length}
              </span>
              <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-md border ${catBadge.color}`}>
                {catBadge.label}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {currentQ?.pageReference && (
                <span className="text-[11px] font-mono text-stone-500 bg-stone-100 px-2 py-0.5 rounded-md">
                  مرجع بالـ PDF: {currentQ.pageReference}
                </span>
              )}
              <span className="text-xs font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-200">
                موضوع: {currentQ?.topicTag}
              </span>
            </div>
          </div>

          {/* Question Prompt */}
          <h3 className="text-lg sm:text-xl font-bold text-[#1E232A] leading-relaxed mb-6 font-cairo">
            {currentQ?.prompt}
          </h3>

          {/* MODE 1: WRITTEN EXAM */}
          {examMode === 'written' && (
            <div className="mb-6">
              {/* Type A: Multiple Choice (MCQ) */}
              {currentQ?.type === 'mcq' && currentQ.options && (
                <div className="space-y-3">
                  {currentQ.options.map((option, optIdx) => {
                    const isSelected = selectedAnswers[currentQ.id] === optIdx;
                    return (
                      <button
                        key={optIdx}
                        onClick={() => handleSelectMcq(optIdx)}
                        className={`w-full p-4 rounded-2xl border-2 text-right text-sm font-semibold transition-all flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? 'bg-[#1A1F24] text-[#FDE047] border-[#1A1F24] shadow-md ring-2 ring-[#FDE047]/20'
                            : 'bg-stone-50 hover:bg-stone-100 text-stone-800 border-stone-200'
                        }`}
                      >
                        <span className="leading-relaxed">{option}</span>
                        <span
                          className={`w-6 h-6 rounded-full border flex items-center justify-center text-xs shrink-0 font-bold ${
                            isSelected
                              ? 'border-[#FDE047] bg-[#FDE047] text-stone-900'
                              : 'border-stone-400 text-stone-500'
                          }`}
                        >
                          {optIdx + 1}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Type B: True / False */}
              {currentQ?.type === 'true_false' && (
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => handleSelectTrueFalse(true)}
                    className={`p-5 rounded-2xl border-2 text-center text-sm font-extrabold transition-all cursor-pointer ${
                      selectedAnswers[currentQ.id] === true
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-md'
                        : 'bg-stone-50 hover:bg-stone-100 text-stone-800 border-stone-200'
                    }`}
                  >
                    <Check className="w-6 h-6 mx-auto mb-1 stroke-[3]" />
                    <span>صواب (العبارة صحيحة علمياً)</span>
                  </button>
                  <button
                    onClick={() => handleSelectTrueFalse(false)}
                    className={`p-5 rounded-2xl border-2 text-center text-sm font-extrabold transition-all cursor-pointer ${
                      selectedAnswers[currentQ.id] === false
                        ? 'bg-rose-600 text-white border-rose-600 shadow-md'
                        : 'bg-stone-50 hover:bg-stone-100 text-stone-800 border-stone-200'
                    }`}
                  >
                    <XCircle className="w-6 h-6 mx-auto mb-1 stroke-[2]" />
                    <span>خطأ (العبارة خاطئة وغير دقيقة)</span>
                  </button>
                </div>
              )}

              {/* Type C: Short Answer / Problem Solving */}
              {currentQ?.type === 'short_answer' && (
                <div className="space-y-3">
                  <label className="block text-xs font-bold text-stone-700">
                    اكتب إجابتك أو خطوات الحل باختصار:
                  </label>
                  <textarea
                    rows={3}
                    placeholder="اكتب إجابتك هنا..."
                    value={shortAnswers[currentQ.id] || ''}
                    onChange={(e) => handleShortAnswerChange(e.target.value)}
                    className="w-full p-3 rounded-2xl border border-stone-300 text-sm focus:ring-2 focus:ring-[#8B5CF6] focus:outline-none"
                  />
                </div>
              )}
            </div>
          )}

          {/* MODE 2: ORAL EXAM WITH REAL GEMINI EVALUATION */}
          {examMode === 'oral' && (
            <div className="mb-6 p-6 rounded-3xl bg-[#1A1F24] text-white border-2 border-[#5C3A21] flex flex-col">
              <div className="flex items-center justify-between mb-3 border-b border-white/10 pb-2">
                <span className="text-xs font-bold text-[#FDE047] flex items-center gap-1.5">
                  <Mic className="w-4 h-4 text-[#FDE047]" />
                  المناقشة الشفوية المباشرة مع المعلم {teacher.name}
                </span>
                <span className="text-[11px] text-stone-400">
                  تقييم ذكي حقيقي بـ Gemini Flash
                </span>
              </div>

              <p className="text-xs text-stone-300 leading-relaxed mb-4">
                تحدث بحرية كأنك أمام المعلم في امتحان شفوي. المعلم سيميز فهمك الحقيقي حتى لو شرحت بأسلوبك الشعبي!
              </p>

              {/* Speech Input Box (Editable Transcript) */}
              <div className="relative mb-4">
                <textarea
                  rows={3}
                  placeholder={
                    isListeningMic
                      ? 'جاري الاستماع لصوتك باللغة العربية... تحدث الآن'
                      : 'تحدث عبر زر الميكروفون، أو اكتب إجابتك الشفوية هنا مباشرة...'
                  }
                  value={oralInputText}
                  onChange={(e) => setOralInputText(e.target.value)}
                  className="w-full p-4 rounded-2xl bg-black/50 border border-white/20 text-white text-sm focus:ring-2 focus:ring-[#FDE047] focus:outline-none placeholder:text-stone-500 font-cairo"
                />

                {isListeningMic && (
                  <span className="absolute top-3 left-3 flex items-center gap-1 text-[11px] text-rose-400 font-bold animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-rose-500" />
                    الميكروفون يسجل...
                  </span>
                )}
              </div>

              {micError && (
                <div className="mb-4 p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{micError}</span>
                </div>
              )}

              {/* Action Buttons: Toggle Mic & Submit to Gemini */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={handleToggleMic}
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
                    isListeningMic
                      ? 'bg-rose-600 hover:bg-rose-700 text-white animate-pulse'
                      : 'bg-stone-800 hover:bg-stone-700 text-white border border-white/20'
                  }`}
                >
                  <Mic className="w-4 h-4 text-purple-400" />
                  <span>{isListeningMic ? 'إيقاف التسجيل الصوتي' : 'تحدث بالصوت 🎙️'}</span>
                </button>

                <button
                  type="button"
                  disabled={evaluatingOral || !oralInputText.trim()}
                  onClick={handleSubmitOralAnswer}
                  className="px-6 py-2.5 rounded-xl bg-[#FDE047] hover:bg-yellow-400 disabled:opacity-40 text-stone-900 font-extrabold text-xs flex items-center gap-2 shadow-lg cursor-pointer transition-all"
                >
                  {evaluatingOral ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-stone-900" />
                      <span>{teacher.name} يقيّم إجابتك الشفوية...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>إرسال الإجابة للتقييم الشفوي</span>
                    </>
                  )}
                </button>
              </div>

              {/* Real Gemini Evaluation Feedback Display */}
              {oralEvaluations[currentQ.id] && (
                <div className="mt-5 p-4 rounded-2xl bg-white/10 border border-white/20 text-xs animate-in fade-in duration-300">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-extrabold text-sm text-[#FDE047] flex items-center gap-1.5">
                      {oralEvaluations[currentQ.id].isAccurate ? '✓ فهم ممتاز وصحيح' : '⚠️ يحتاج تدقيق علمي'}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-yellow-400/20 text-[#FDE047] font-mono font-bold">
                      الدرجة: {oralEvaluations[currentQ.id].score} / 10
                    </span>
                  </div>

                  {/* Teacher Feedback Script */}
                  <div className="bg-black/40 p-3 rounded-xl border border-white/10 text-stone-200 leading-relaxed italic mb-3">
                    « {oralEvaluations[currentQ.id].feedback} »
                  </div>

                  {/* Missing Points if any */}
                  {oralEvaluations[currentQ.id].missingPoints?.length > 0 && (
                    <div className="mb-2">
                      <span className="text-[#67E8F9] font-bold block mb-1">نقاط ناقصة لإكمال الدرجة:</span>
                      <ul className="list-disc list-inside space-y-0.5 text-stone-300">
                        {oralEvaluations[currentQ.id].missingPoints.map((pt, i) => (
                          <li key={i}>{pt}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Follow-up question */}
                  {oralEvaluations[currentQ.id].followUpQuestion && (
                    <div className="mt-3 pt-3 border-t border-white/10">
                      <span className="text-[#C4B5FD] font-bold flex items-center gap-1 mb-1">
                        <MessageSquare className="w-3.5 h-3.5" />
                        سؤال متابعة ذكي من المعلم:
                      </span>
                      <p className="text-white font-medium mb-2">
                        {oralEvaluations[currentQ.id].followUpQuestion}
                      </p>
                      <input
                        type="text"
                        placeholder="أجب على سؤال المتابعة هنا..."
                        value={followUpAnswer}
                        onChange={(e) => setFollowUpAnswer(e.target.value)}
                        className="w-full px-3 py-1.5 rounded-xl bg-black/40 border border-white/20 text-xs text-white"
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Stepper Navigation Buttons & Finish CTA */}
          <div className="pt-4 border-t border-stone-100 flex items-center justify-between">
            <button
              onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentIndex === 0}
              className="px-4 py-2 rounded-xl border border-stone-200 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-stone-100 text-stone-700 text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <ArrowRight className="w-4 h-4" />
              <span>السؤال السابق</span>
            </button>

            <div className="flex items-center gap-1">
              {activeQuestionList.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentIndex(i)}
                  className={`w-3 h-3 rounded-full transition-all cursor-pointer ${
                    i === currentIndex
                      ? 'w-6 bg-[#8B5CF6]'
                      : selectedAnswers[activeQuestionList[i]?.id] !== undefined || oralEvaluations[activeQuestionList[i]?.id]
                      ? 'bg-emerald-500'
                      : 'bg-stone-200'
                  }`}
                />
              ))}
            </div>

            {currentIndex < activeQuestionList.length - 1 ? (
              <button
                onClick={() => setCurrentIndex((prev) => prev + 1)}
                className="px-4 py-2 rounded-xl bg-[#1A1F24] hover:bg-[#2C333D] text-[#FDE047] text-xs font-bold flex items-center gap-1.5 shadow transition-all cursor-pointer"
              >
                <span>السؤال التالي</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleFinish}
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center gap-1.5 shadow-lg active:scale-95 transition-all cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>تسليم الامتحان والنتيجة</span>
              </button>
            )}
          </div>
        </div>

        {/* Right / Scratchpad Sidebar (Optional Whiteboard for Math & Notes) */}
        {showScratchpad && (
          <div className="lg:col-span-4 bg-stone-50 rounded-3xl border border-stone-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-extrabold text-sm text-[#1E232A] flex items-center gap-1.5 font-chalk">
                <PenTool className="w-4 h-4 text-[#8B5CF6]" />
                مسودة الحسابات والملاحظات
              </h4>
              <button
                onClick={() => setScratchpadText('')}
                className="text-[11px] text-stone-500 hover:text-stone-800"
              >
                مسح المسودة
              </button>
            </div>
            <textarea
              rows={12}
              value={scratchpadText}
              onChange={(e) => setScratchpadText(e.target.value)}
              placeholder="اكتب معادلاتك أو أفكارك أو ملاحظاتك هنا أثناء حل الامتحان..."
              className="w-full p-3 rounded-2xl bg-white border border-stone-200 text-xs font-mono focus:ring-2 focus:ring-[#8B5CF6] focus:outline-none resize-none leading-relaxed"
            />
            <span className="text-[10px] text-stone-400 block text-center">
              المسودة خاصة بك ولا تؤثر على درجتك النهائية
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
