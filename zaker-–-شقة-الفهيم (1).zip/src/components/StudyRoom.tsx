import React from 'react';
import { SwingingLamp } from './SwingingLamp.tsx';
import { TiltedBookshelf } from './TiltedBookshelf.tsx';
import { TeaCup } from './TeaCup.tsx';
import { BrainModel } from './BrainModel.tsx';
import { ClickableBook } from './ClickableBook.tsx';
import { Sparkles, GraduationCap, Clock, Award, HelpCircle } from 'lucide-react';

interface StudyRoomProps {
  lampOn: boolean;
  onToggleLamp: () => void;
  maxUploadSizeMB: number;
  onFileSelected: (file: File) => void;
  onSelectSampleBook: (sampleId: string) => void;
  onOpenSettings: () => void;
}

export const StudyRoom: React.FC<StudyRoomProps> = ({
  lampOn,
  onToggleLamp,
  maxUploadSizeMB,
  onFileSelected,
  onSelectSampleBook,
  onOpenSettings,
}) => {
  return (
    <div className="relative min-h-[calc(100vh-65px)] w-full overflow-hidden bg-[#FAF7F2] chalk-wall-equations flex flex-col justify-between p-4 sm:p-6 lg:p-8">
      {/* Background Chalk Equations & Doodles on the Wall */}
      <div className="absolute inset-0 pointer-events-none select-none overflow-hidden opacity-25">
        <span className="absolute top-12 left-12 text-sm sm:text-base font-handwriting text-stone-700">
          E = mc² · \nabla \times B = \mu_0 J
        </span>
        <span className="absolute top-36 right-20 text-sm font-chalk text-stone-700">
          س + ص = ع · الجذر التكعيبي
        </span>
        <span className="absolute bottom-48 left-1/3 text-xs sm:text-sm font-handwriting text-stone-700">
          \lim_{'{x \\to \\infty}'} \frac{'{1}'}{'{x}'} = 0 · \Delta Q = mc\Delta T
        </span>
        <span className="absolute top-20 left-1/2 -translate-x-1/2 text-xs font-chalk text-purple-800/40">
          « العلم في الراس مش في الكراس »
        </span>
      </div>

      {/* The Hanging Swinging Lamp */}
      <SwingingLamp isOn={lampOn} onToggle={onToggleLamp} />

      {/* Main Study Room Scene (Top Half: Chalkboard & Bookshelf) */}
      <div className="relative z-10 max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Tilted Bookshelf */}
        <div className="lg:col-span-3 flex justify-center lg:justify-start order-2 lg:order-1">
          <TiltedBookshelf onSelectSampleBook={onSelectSampleBook} />
        </div>

        {/* Center / Right Column: Large Central Black Chalkboard */}
        <div className="lg:col-span-9 order-1 lg:order-2 flex flex-col items-center">
          <div className="relative w-full rounded-2xl chalkboard-surface chalkboard-border p-6 sm:p-8 text-center shadow-2xl overflow-hidden">
            {/* Top Chalkboard Pin / Label */}
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-white/10 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                <span className="text-stone-300 font-mono tracking-wider">
                  سبورة الفهيم الذكية v1.0
                </span>
              </div>
              <span className="text-[#FDE047] font-semibold text-[11px] sm:text-xs">
                جاهز لتحويل أي كتاب إلى شرح مبسط 💡
              </span>
            </div>

            {/* Central Chalkboard Welcome Message */}
            <div className="py-2 sm:py-4">
              <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#8B5CF6] bg-purple-950/40 border border-purple-500/30 px-3 py-1 rounded-full mb-3">
                <Sparkles className="w-3.5 h-3.5 text-[#FDE047]" />
                مرحبًا بك في شقة الفهيم التعليمية
              </span>
              <h1 className="text-3xl sm:text-5xl font-black chalk-text-yellow font-chalk leading-tight">
                المذاكرة من غير فزلكة ولا تعقيد
              </h1>
              <p className="mt-3 text-sm sm:text-base text-stone-300 max-w-2xl mx-auto font-medium leading-relaxed">
                ارمي أي كتاب أو ملخص عندك على المكتب تحت، واختار أستاذك المفضل..
                هنفكك المنهج لنقاط مركزة، وسبورة طباشير، وامتحان شفوي وتحريري يخليك تقفل المادة وأنت مروّق!
              </p>
            </div>

            {/* Chalkboard Value Strip */}
            <div className="mt-6 pt-4 border-t border-white/10 grid grid-cols-1 sm:grid-cols-3 gap-3 text-right">
              <div className="bg-white/5 rounded-xl p-3 border border-white/5">
                <span className="text-[#FDE047] font-bold text-sm block mb-1">
                  ١. شرح سبورة تفاعلي
                </span>
                <span className="text-stone-400 text-xs leading-normal">
                  الكلام بيتكتب قدامك خطوة بخطوة مع كبسولة (الزتونة) لكل مفهوم.
                </span>
              </div>
              <div className="bg-white/5 rounded-xl p-3 border border-white/5">
                <span className="text-[#67E8F9] font-bold text-sm block mb-1">
                  ٢. اختيار أسلوب المعلم
                </span>
                <span className="text-stone-400 text-xs leading-normal">
                  سواء الفهيم للعلوم أو مستر صلاح للعربي أو سامح سند لحكايات التاريخ.
                </span>
              </div>
              <div className="bg-white/5 rounded-xl p-3 border border-white/5">
                <span className="text-[#C4B5FD] font-bold text-sm block mb-1">
                  ٣. امتحانات شفوية وتحريرية
                </span>
                <span className="text-stone-400 text-xs leading-normal">
                  اختبار ذكي يقيّم إجاباتك ويحدد نقاط ضعفك بالضبط عشان تراجعها.
                </span>
              </div>
            </div>

            {/* Chalkboard Bottom Tray with Chalks & Eraser */}
            <div className="absolute bottom-0 inset-x-0 h-4 bg-[#4A2D17] border-t border-[#6B4226] flex items-center justify-end px-6 gap-3">
              <div className="w-8 h-2 bg-white rounded-full opacity-90 shadow-sm" />
              <div className="w-6 h-2 bg-[#FDE047] rounded-full opacity-90 shadow-sm" />
              <div className="w-8 h-2 bg-[#67E8F9] rounded-full opacity-80 shadow-sm" />
              <div className="w-7 h-2 bg-[#F472B6] rounded-full opacity-80 shadow-sm" />
              <div className="w-12 h-2.5 bg-[#8C5E3B] rounded-sm border border-[#3B2211]" />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Half: The Cozy Wooden Desk with Book, Brain, and Tea Cup */}
      <div className="relative z-10 max-w-6xl mx-auto w-full mt-8">
        {/* Desk Props Cluster on the Wooden Surface */}
        <div className="relative bg-gradient-to-b from-[#633E22] via-[#54321A] to-[#3B200E] rounded-t-3xl border-t-8 border-[#7C4E2C] p-6 sm:p-8 shadow-[0_-12px_35px_rgba(0,0,0,0.15)] flex flex-col items-center">
          {/* Desk items layout */}
          <div className="w-full flex flex-col md:flex-row items-center justify-between gap-6">
            {/* Desk Item 1: Tea Cup with Steam */}
            <div className="flex flex-col items-center order-2 md:order-1">
              <TeaCup />
              <span className="text-[11px] font-bold text-amber-200 mt-2">
                كوباية شاي الفهيم ☕
              </span>
            </div>

            {/* Desk Item 2 (CENTER): The Clickable Book */}
            <div className="order-1 md:order-2 flex-1 flex justify-center w-full">
              <ClickableBook
                onFileSelected={onFileSelected}
                maxUploadSizeMB={maxUploadSizeMB}
                onSelectSampleBook={onSelectSampleBook}
              />
            </div>

            {/* Desk Item 3: Brain Model */}
            <div className="flex flex-col items-center order-3">
              <BrainModel />
              <span className="text-[11px] font-bold text-purple-200 mt-2">
                مجسم المخ البشري 🧠
              </span>
            </div>
          </div>

          {/* Desk Drawer Handles / Front Facade */}
          <div className="w-full mt-6 pt-4 border-t border-[#7A4B29]/60 flex items-center justify-around">
            <div className="w-20 h-2 bg-[#2D170A] rounded-full shadow-inner" />
            <div className="w-20 h-2 bg-[#2D170A] rounded-full shadow-inner" />
            <div className="w-20 h-2 bg-[#2D170A] rounded-full shadow-inner" />
          </div>
        </div>
      </div>
    </div>
  );
};
