import React from 'react';
import { OutputFormat, OutputSettings, TeacherProfile, VoiceOption } from '../types/index.ts';
import { soundManager } from '../utils/audioSynth.ts';
import {
  Monitor,
  Headphones,
  UserCheck,
  Volume2,
  Mic,
  Sliders,
  ArrowLeft,
  ArrowRight,
  Sparkles,
  Check,
} from 'lucide-react';

interface OutputSettingsScreenProps {
  settings: OutputSettings;
  onChangeSettings: (newSettings: OutputSettings) => void;
  selectedTeacher: TeacherProfile;
  onContinue: () => void;
  onBack: () => void;
}

export const OutputSettingsScreen: React.FC<OutputSettingsScreenProps> = ({
  settings,
  onChangeSettings,
  selectedTeacher,
  onContinue,
  onBack,
}) => {
  const formats: {
    id: OutputFormat;
    title: string;
    subtitle: string;
    description: string;
    icon: typeof Monitor;
    badge: string;
  }[] = [
    {
      id: 'chalkboard',
      title: 'سبورة تفاعلية',
      subtitle: 'Chalkboard Interactive',
      description: 'كتابة وتفكيك القوانين بالطباشير الأبيض والأصفر مع رسومات بيانية على سبورة شقة الفهيم.',
      icon: Monitor,
      badge: 'الأكثر شعبية 🌟',
    },
    {
      id: 'audio',
      title: 'تسجيل صوتي فقط',
      subtitle: 'Audio Cassette',
      description: 'جلسة بودكاست تعليمية هادئة مع مؤثرات ورق وكتابة خفيفة، ممتازة وأنت مروّح في المواصلات.',
      icon: Headphones,
      badge: 'للمواصلات والتركيز 🎧',
    },
    {
      id: 'cartoon',
      title: 'مدرس كرتوني',
      subtitle: 'Animated Avatar',
      description: 'أفاتار كرتوني تفاعلي للمدرس يعبر بحركات الوجه والإيماءات الحماسية لتثبيت الشرح.',
      icon: UserCheck,
      badge: 'تفاعل حركي 🎨',
    },
  ];

  const voices: { id: VoiceOption; title: string; subtitle: string; icon: string }[] = [
    {
      id: 'male',
      title: 'صوت رجالي مصري',
      subtitle: 'نبرة دافئة، واثقة، ومبسطة بالعامية المصرية الودودة',
      icon: '🎙️',
    },
    {
      id: 'female',
      title: 'صوت نسائي مصري',
      subtitle: 'نبرة مشجعة، رصينة، وواضحة المخارج بأسلوب أكاديمي محبب',
      icon: '👩‍🏫',
    },
  ];

  const speedRates = [0.85, 1.0, 1.25, 1.5];

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6">
      {/* Header */}
      <div className="mb-6 text-center sm:text-right">
        <span className="text-xs font-bold text-[#8B5CF6] tracking-wider uppercase block mb-1">
          إعدادات طريقة العرض والصوت
        </span>
        <h2 className="text-3xl font-black text-[#1E232A] font-chalk">
          كيف تحب أن يعرض لك {selectedTeacher.name} الدرس؟
        </h2>
        <p className="text-sm text-stone-500 mt-1">
          خصص بيئة المشاهدة والصوت بما يناسب وقتك وراحتك الذهنية.
        </p>
      </div>

      {/* Format Selection Cards */}
      <div className="mb-8">
        <label className="block text-sm font-bold text-stone-800 mb-3">
          طريقة إخراج الدرس:
        </label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {formats.map((fmt) => {
            const isSelected = settings.format === fmt.id;
            const Icon = fmt.icon;
            return (
              <div
                key={fmt.id}
                onClick={() => {
                  soundManager.playClick();
                  onChangeSettings({ ...settings, format: fmt.id });
                }}
                className={`group relative rounded-2xl p-5 border-2 transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-white border-[#1A1F24] ring-2 ring-[#FDE047] shadow-xl'
                    : 'bg-white/80 hover:bg-white border-stone-200 hover:border-stone-400'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span
                      className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        isSelected
                          ? 'bg-[#1A1F24] text-[#FDE047]'
                          : 'bg-stone-100 text-stone-600'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </span>
                    <span className="text-[11px] font-semibold text-stone-500">
                      {fmt.badge}
                    </span>
                  </div>

                  <h3 className="font-extrabold text-base text-[#1E232A]">
                    {fmt.title}
                  </h3>
                  <span className="text-[10px] text-stone-400 font-mono block mb-2">
                    {fmt.subtitle}
                  </span>
                  <p className="text-xs text-stone-600 leading-relaxed">
                    {fmt.description}
                  </p>
                </div>

                <div className="pt-4 mt-2 border-t border-stone-100 flex items-center justify-end">
                  <span
                    className={`text-xs font-bold ${
                      isSelected ? 'text-[#1A1F24]' : 'text-stone-400'
                    }`}
                  >
                    {isSelected ? 'المحدد ✓' : 'اختيار'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Voice Selection */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm mb-6">
        <label className="block text-sm font-bold text-stone-800 mb-3 flex items-center gap-2">
          <Mic className="w-4 h-4 text-[#8B5CF6]" />
          نبرة الصوت المصاحبة:
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {voices.map((v) => {
            const isSelected = settings.voice === v.id;
            return (
              <div
                key={v.id}
                onClick={() => {
                  soundManager.playClick();
                  onChangeSettings({ ...settings, voice: v.id });
                }}
                className={`p-4 rounded-xl border-2 transition-all cursor-pointer flex items-center gap-3.5 ${
                  isSelected
                    ? 'bg-purple-50/50 border-[#8B5CF6] ring-1 ring-[#8B5CF6]'
                    : 'bg-stone-50 border-stone-200 hover:bg-stone-100'
                }`}
              >
                <span className="text-2xl">{v.icon}</span>
                <div className="flex-1">
                  <span className="font-bold text-sm text-stone-900 block">
                    {v.title}
                  </span>
                  <span className="text-xs text-stone-500 block leading-tight mt-0.5">
                    {v.subtitle}
                  </span>
                </div>
                {isSelected && (
                  <div className="w-5 h-5 rounded-full bg-[#8B5CF6] text-white flex items-center justify-center shrink-0">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Playback Rate & Sound Effects */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm mb-8 grid grid-cols-1 sm:grid-cols-2 gap-6">
        {/* Playback Rate */}
        <div>
          <label className="block text-xs font-bold text-stone-700 mb-2">
            سرعة الإلقاء:
          </label>
          <div className="flex items-center gap-2">
            {speedRates.map((rate) => {
              const isSelected = settings.playbackRate === rate;
              return (
                <button
                  key={rate}
                  type="button"
                  onClick={() => {
                    soundManager.playClick();
                    onChangeSettings({ ...settings, playbackRate: rate });
                  }}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#1A1F24] text-[#FDE047] border-[#1A1F24]'
                      : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                  }`}
                >
                  {rate}x
                </button>
              );
            })}
          </div>
        </div>

        {/* Toggles */}
        <div className="space-y-3">
          <label className="flex items-center justify-between cursor-pointer">
            <span className="text-xs font-bold text-stone-700">
              أصوات الطباشير والورق التفاعلية
            </span>
            <input
              type="checkbox"
              checked={settings.enableSounds}
              onChange={(e) => {
                soundManager.setEnabled(e.target.checked);
                onChangeSettings({ ...settings, enableSounds: e.target.checked });
              }}
              className="w-4 h-4 rounded text-[#8B5CF6] focus:ring-[#8B5CF6]"
            />
          </label>

          <label className="flex items-center justify-between cursor-pointer">
            <span className="text-xs font-bold text-stone-700">
              إظهار مخططات ورسومات توضيحية
            </span>
            <input
              type="checkbox"
              checked={settings.showChalkDiagrams}
              onChange={(e) =>
                onChangeSettings({
                  ...settings,
                  showChalkDiagrams: e.target.checked,
                })
              }
              className="w-4 h-4 rounded text-[#8B5CF6] focus:ring-[#8B5CF6]"
            />
          </label>
        </div>
      </div>

      {/* Navigation Footer */}
      <div className="flex items-center justify-between pt-4 border-t border-stone-200">
        <button
          onClick={onBack}
          className="px-4 py-2 rounded-xl text-stone-600 hover:text-stone-900 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <ArrowRight className="w-4 h-4" />
          <span>تغيير المعلم</span>
        </button>

        <button
          onClick={onContinue}
          className="px-6 py-2.5 rounded-xl bg-[#1A1F24] hover:bg-[#2C333D] text-[#FDE047] font-extrabold text-sm shadow-md active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
        >
          <span>افتح السبورة وابدأ الدرس</span>
          <ArrowLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
