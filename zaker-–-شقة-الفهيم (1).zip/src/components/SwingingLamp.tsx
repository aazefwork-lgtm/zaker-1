import React from 'react';

interface SwingingLampProps {
  isOn: boolean;
  onToggle: () => void;
}

export const SwingingLamp: React.FC<SwingingLampProps> = ({ isOn, onToggle }) => {
  return (
    <div className="absolute top-0 right-1/4 sm:right-1/3 z-20 pointer-events-auto flex flex-col items-center">
      {/* Hanging Cord & Fixture */}
      <div className={`flex flex-col items-center ${isOn ? 'animate-swing-lamp' : ''}`}>
        {/* Wire */}
        <div className="w-[3px] h-16 sm:h-24 bg-[#2D2A26] relative">
          {/* Wire bracket at ceiling */}
          <div className="absolute -top-1 -left-1.5 w-4 h-2 bg-[#1F1D1A] rounded-b-sm" />
        </div>

        {/* Lamp Shade Cap */}
        <div className="w-8 h-3 bg-[#4A3B32] rounded-t-full border border-[#2B221D]" />

        {/* Vintage Industrial Metal Shade */}
        <button
          onClick={onToggle}
          title={isOn ? 'إطفاء المصباح' : 'إضاءة المصباح'}
          className="group relative cursor-pointer focus:outline-none"
        >
          <div className="w-20 sm:w-28 h-10 sm:h-12 bg-gradient-to-b from-[#3D342C] via-[#54483E] to-[#2B231E] rounded-b-[40px] border-b-4 border-[#C88A22] shadow-xl flex items-center justify-center transition-transform group-hover:scale-105">
            {/* Lamp Bulb Underneath */}
            <div
              className={`w-6 h-6 rounded-full transition-all duration-300 ${
                isOn
                  ? 'bg-[#FEF08A] shadow-[0_0_35px_14px_rgba(253,224,71,0.85)]'
                  : 'bg-[#78716C] shadow-inner'
              }`}
            />
          </div>

          {/* Lamp Pull String */}
          <div className="absolute -bottom-7 right-4 w-[1.5px] h-7 bg-amber-800/80 group-hover:h-8 transition-all">
            <div className="w-2 h-2.5 bg-amber-600 rounded-full -bottom-1 -left-[3px] relative shadow" />
          </div>
        </button>

        {/* Warm Volumetric Light Cone on the Room */}
        {isOn && (
          <div
            className="pointer-events-none absolute top-28 -left-48 sm:-left-64 w-[420px] sm:w-[560px] h-[480px] bg-[radial-gradient(ellipse_at_top,rgba(254,240,138,0.25)_0%,rgba(253,224,71,0.08)_45%,transparent_75%)] blur-2xl transition-opacity duration-700"
          />
        )}
      </div>
    </div>
  );
};
