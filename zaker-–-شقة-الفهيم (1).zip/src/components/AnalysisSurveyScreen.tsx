import React, { useState } from 'react';
import { ExamQuestion, LessonData, TeacherProfile, UserPreferences } from '../types/index.ts';
import { GRADE_LEVELS, SPEED_OPTIONS, STUDY_REASONS } from '../config.ts';
import { soundManager } from '../utils/audioSynth.ts';
import {
  Sparkles,
  CheckCircle2,
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  BookOpen,
  User,
  Flame,
  Clock,
  RotateCcw,
  Loader2,
  FileCheck,
  Tag,
} from 'lucide-react';

interface AnalysisSurveyScreenProps {
  pdfBase64: string | null;
  fileName: string;
  fileSizeStr: string;
  initialPreferences: UserPreferences;
  currentTeacher: TeacherProfile;
  onAnalysisSuccess: (lesson: LessonData, questions: ExamQuestion[], preferences: UserPreferences) => void;
  onBackToRoom: () => void;
}

export const AnalysisSurveyScreen: React.FC<AnalysisSurveyScreenProps> = ({
  pdfBase64,
  fileName,
  fileSizeStr,
  initialPreferences,
  currentTeacher,
  onAnalysisSuccess,
  onBackToRoom,
}) => {
  const [preferences, setPreferences] = useState<UserPreferences>(initialPreferences);
  const [status, setStatus] = useState<'idle' | 'analyzing' | 'success' | 'error'>('idle');
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [stepMessage, setStepMessage] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Stored analysis result
  const [analysisResult, setAnalysisResult] = useState<{
    lesson: LessonData;
    questions: ExamQuestion[];
  } | null>(null);

  const startAnalysis = async () => {
    if (!pdfBase64) {
      setStatus('error');
      setErrorMessage('لم يتم العثور على محتوى ملف PDF لتحليله. يرجى الرجوع واختيار ملف صالح.');
      return;
    }

    if (!preferences.name.trim()) {
      setStatus('error');
      setErrorMessage('يرجى كتابة اسمك في الاستمارة حتى نتمكن من تخصيص الشرح لك.');
      return;
    }

    setStatus('analyzing');
    setErrorMessage(null);
    setProgressPercent(15);
    setStepMessage('جاري تشفير وتجهيز ملف المستند...');

    try {
      // Step 1: Pre-flight check
      await new Promise((r) => setTimeout(r, 400));
      setProgressPercent(35);
      setStepMessage(`إرسال المستند إلى خادم المعالجة ونموذج Gemini...`);

      // Real fetch to server-side endpoint
      const response = await fetch('/api/analyze-pdf', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          pdfBase64,
          fileName,
          studentName: preferences.name,
          gradeLevel: preferences.gradeLevel,
          speed: preferences.speed,
          reason: preferences.reason,
          teacherId: currentTeacher.id,
          teacherName: currentTeacher.name,
          teacherSpecialty: currentTeacher.specialty,
          teacherPersona: currentTeacher.catchphrase,
        }),
      });

      setProgressPercent(75);
      setStepMessage('قراءة محتوى الصفحات واستخراج القوانين والمفاهيم العلمية...');

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'فشلت معالجة ملف الـ PDF عبر الخادم.');
      }

      setProgressPercent(95);
      setStepMessage('تنسيق سبورة الشرح، أرقام الصفحات، والامتحان الذكي...');
      await new Promise((r) => setTimeout(r, 400));

      setProgressPercent(100);
      setStepMessage('اكتمل تحليل الكتاب وتجهيز السبورة بنجاح!');
      soundManager.playChime(true);

      setAnalysisResult({
        lesson: data.lesson,
        questions: data.questions,
      });
      setStatus('success');
    } catch (err: any) {
      console.error('Analysis error:', err);
      soundManager.playChime(false);
      setStatus('error');
      setErrorMessage(
        err.message || 'حدث خطأ في الاتصال بالخادم أو أثناء تحليل المستند بواسطة الذكاء الاصطناعي.'
      );
    }
  };

  const handleContinueToTeachers = () => {
    if (analysisResult) {
      onAnalysisSuccess(analysisResult.lesson, analysisResult.questions, preferences);
    }
  };

  const isFormValid = preferences.name.trim().length > 0;

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6">
      {/* Real Gemini Analysis Badge */}
      <div className="mb-6 p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
        <span className="font-bold flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-[#8B5CF6]" />
          تحليل مستندات حقيقي مدعوم بـ Gemini 3.8 Flash
        </span>
        <span className="text-stone-600">
          يتم فحص صفحات الـ PDF واستخراج فصولها بدقة بدون بيانات وهمية.
        </span>
      </div>

      {/* Book Status Banner */}
      <div className="bg-[#1A1F24] rounded-2xl p-6 border-2 border-[#5C3A21] shadow-xl text-white mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-3">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-[#5C3A21] text-[#FDE047] flex items-center justify-center font-bold">
              <BookOpen className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-[#FAF7F2] truncate max-w-md">
                {fileName || 'مستند دراسي'}
              </h2>
              <span className="text-xs text-stone-400 font-mono">
                الحجم: {fileSizeStr || 'ملف PDF'}
              </span>
            </div>
          </div>

          {/* Status Badge */}
          <div>
            {status === 'idle' && (
              <span className="text-xs bg-amber-500/20 text-amber-300 border border-amber-500/40 px-3 py-1 rounded-full font-bold">
                جاهز للتحليل
              </span>
            )}
            {status === 'analyzing' && (
              <span className="text-xs bg-purple-500/20 text-purple-300 border border-purple-500/40 px-3 py-1 rounded-full font-bold flex items-center gap-1.5 animate-pulse">
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                جاري التحليل الفعلي ({progressPercent}%)
              </span>
            )}
            {status === 'success' && (
              <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-3 py-1 rounded-full font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                تم التحليل بنجاح
              </span>
            )}
            {status === 'error' && (
              <span className="text-xs bg-rose-500/20 text-rose-300 border border-rose-500/40 px-3 py-1 rounded-full font-bold flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5" />
                تعذر التحليل
              </span>
            )}
          </div>
        </div>

        {/* Real Progress Bar when analyzing or success */}
        {(status === 'analyzing' || status === 'success') && (
          <div className="mt-4">
            <div className="w-full h-3 bg-stone-800 rounded-full overflow-hidden p-0.5 border border-stone-700">
              <div
                className="h-full bg-gradient-to-r from-amber-500 via-[#8B5CF6] to-[#FDE047] rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <p className="mt-2 text-xs text-stone-300 flex items-center gap-2 font-medium">
              <span className="w-2 h-2 rounded-full bg-[#67E8F9] animate-pulse" />
              {stepMessage}
            </p>
          </div>
        )}
      </div>

      {/* ERROR CARD (Shown honestly if API or document fails) */}
      {status === 'error' && (
        <div className="mb-8 bg-rose-50 border-2 border-rose-300 rounded-2xl p-6 text-rose-950 shadow-md animate-in fade-in slide-in-from-top-2">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-extrabold text-base font-chalk">
                تنبيه: تعذر إكمال تحليل ملف الـ PDF
              </h3>
              <p className="mt-1.5 text-xs sm:text-sm text-rose-900 leading-relaxed font-medium">
                {errorMessage}
              </p>

              <div className="mt-4 pt-3 border-t border-rose-200 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={startAnalysis}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center gap-1.5 shadow transition-all cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>إعادة المحاولة الآن</span>
                </button>

                <button
                  type="button"
                  onClick={onBackToRoom}
                  className="px-4 py-2 rounded-xl bg-white hover:bg-stone-100 border border-stone-300 text-stone-700 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                  <span>الرجوع لشقة الفهيم واختيار ملف آخر</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUCCESS CARD (Real grounded preview of the extracted lesson) */}
      {status === 'success' && analysisResult && (
        <div className="mb-8 bg-emerald-50 border-2 border-emerald-300 rounded-2xl p-6 text-emerald-950 shadow-md animate-in fade-in zoom-in-95">
          <div className="flex items-start gap-3 mb-4">
            <FileCheck className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <span className="text-[11px] font-bold text-emerald-700 tracking-wider uppercase block">
                تم استخراج المحتوى العلمي بنجاح من الـ PDF
              </span>
              <h3 className="font-black text-xl text-emerald-950 font-chalk">
                {analysisResult.lesson.bookTitle}
              </h3>
              <span className="text-xs text-emerald-800 font-semibold block mt-0.5">
                المادة: {analysisResult.lesson.subjectTitle}
              </span>
            </div>
          </div>

          {/* Identified Topics */}
          {analysisResult.lesson.mainTopics && analysisResult.lesson.mainTopics.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mb-4">
              {analysisResult.lesson.mainTopics.map((topic, i) => (
                <span
                  key={i}
                  className="bg-white/80 border border-emerald-200 text-emerald-800 text-[11px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1"
                >
                  <Tag className="w-3 h-3 text-emerald-600" />
                  {topic}
                </span>
              ))}
            </div>
          )}

          {/* Section Summary Pills */}
          <div className="bg-white/90 p-4 rounded-xl border border-emerald-200 text-xs space-y-2 mb-4">
            <span className="font-bold text-stone-800 block">
              فصول الدرس المستخرجة ({analysisResult.lesson.sections.length} فصول):
            </span>
            <ul className="list-disc list-inside space-y-1 text-stone-700">
              {analysisResult.lesson.sections.map((sec, i) => (
                <li key={sec.id} className="font-medium">
                  <span className="font-bold text-stone-900">{sec.title}</span>
                  {sec.pageReferences && (
                    <span className="text-[11px] text-[#8B5CF6] mr-2">
                      ({sec.pageReferences})
                    </span>
                  )}
                </li>
              ))}
            </ul>
          </div>

          {/* Proceed to Teachers Button */}
          <div className="flex items-center justify-between pt-2">
            <span className="text-xs text-emerald-800 font-medium">
              تم تجهيز {analysisResult.questions.length} أسئلة اختبار تحريرية وشفوية
            </span>
            <button
              onClick={handleContinueToTeachers}
              className="px-6 py-2.5 rounded-xl bg-[#1A1F24] hover:bg-[#2C333D] text-[#FDE047] font-extrabold text-sm shadow-md active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>المتابعة لاختيار المعلم وطريقة العرض</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Student Onboarding Survey Form (Only editable before success, or for retry) */}
      {status !== 'success' && (
        <div className="bg-white rounded-2xl border border-[#E6DFD3] shadow-md p-6 sm:p-8">
          <div className="mb-6 border-b border-stone-100 pb-4">
            <span className="text-xs font-bold text-[#8B5CF6] tracking-wider uppercase block mb-1">
              استمارة تجهيز الشرح
            </span>
            <h3 className="text-2xl font-black text-[#1E232A] font-chalk">
              عرفنا بيك يا بطل قبل بدء التحليل
            </h3>
            <p className="text-sm text-stone-500 mt-1">
              إجاباتك ستُرسل إلى Gemini لتخصيص كبسولات الشرح ومستوى الأسئلة لمقاسك بدقة.
            </p>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              startAnalysis();
            }}
            className="space-y-6"
          >
            {/* Question 1: Name */}
            <div>
              <label className="block text-sm font-bold text-stone-800 mb-2 flex items-center gap-1.5">
                <User className="w-4 h-4 text-[#8B5CF6]" />
                اسمك إيه؟ <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                disabled={status === 'analyzing'}
                value={preferences.name}
                onChange={(e) =>
                  setPreferences({ ...preferences, name: e.target.value })
                }
                placeholder="مثال: أحمد، سارة، باشمهندس مصر..."
                className="w-full px-4 py-2.5 rounded-xl border border-stone-300 bg-[#FAF7F2] text-[#1E232A] text-sm focus:outline-none focus:ring-2 focus:ring-[#8B5CF6] focus:border-transparent transition-all disabled:opacity-60"
              />
            </div>

            {/* Question 2: Grade Level */}
            <div>
              <label className="block text-sm font-bold text-stone-800 mb-2">
                السنة الدراسية:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {GRADE_LEVELS.map((grade) => {
                  const isSelected = preferences.gradeLevel === grade.id;
                  return (
                    <button
                      type="button"
                      key={grade.id}
                      disabled={status === 'analyzing'}
                      onClick={() => {
                        soundManager.playClick();
                        setPreferences({ ...preferences, gradeLevel: grade.id });
                      }}
                      className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all text-center cursor-pointer disabled:opacity-60 ${
                        isSelected
                          ? 'bg-[#1A1F24] text-[#FDE047] border-[#1A1F24] shadow-sm'
                          : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                      }`}
                    >
                      {grade.id}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Question 3: Speed */}
            <div>
              <label className="block text-sm font-bold text-stone-800 mb-2 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-amber-600" />
                سرعة الشرح المفضلة:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {SPEED_OPTIONS.map((spd) => {
                  const isSelected = preferences.speed === spd.id;
                  return (
                    <button
                      type="button"
                      key={spd.id}
                      disabled={status === 'analyzing'}
                      onClick={() => {
                        soundManager.playClick();
                        setPreferences({
                          ...preferences,
                          speed: spd.id as any,
                        });
                      }}
                      className={`p-3.5 rounded-xl border text-right transition-all flex items-start gap-3 cursor-pointer disabled:opacity-60 ${
                        isSelected
                          ? 'bg-amber-50 border-amber-300 ring-2 ring-amber-400'
                          : 'bg-stone-50 border-stone-200 hover:bg-stone-100'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full mt-0.5 border flex items-center justify-center shrink-0 ${
                          isSelected
                            ? 'border-amber-600 bg-amber-600'
                            : 'border-stone-400'
                        }`}
                      >
                        {isSelected && (
                          <div className="w-1.5 h-1.5 rounded-full bg-white" />
                        )}
                      </div>
                      <div>
                        <span className="font-bold text-sm text-stone-900 block">
                          {spd.title}
                        </span>
                        <span className="text-xs text-stone-500 mt-0.5 block">
                          {spd.desc}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Question 4: Study Reason */}
            <div>
              <label className="block text-sm font-bold text-stone-800 mb-2 flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-rose-500" />
                سبب المذاكرة دلوقتي:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {STUDY_REASONS.map((rsn) => {
                  const isSelected = preferences.reason === rsn.id;
                  return (
                    <button
                      type="button"
                      key={rsn.id}
                      disabled={status === 'analyzing'}
                      onClick={() => {
                        soundManager.playClick();
                        setPreferences({
                          ...preferences,
                          reason: rsn.id as any,
                        });
                      }}
                      className={`p-3 rounded-xl border text-right transition-all cursor-pointer disabled:opacity-60 ${
                        isSelected
                          ? 'bg-purple-50 border-purple-300 ring-2 ring-purple-400'
                          : 'bg-stone-50 border-stone-200 hover:bg-stone-100'
                      }`}
                    >
                      <span className="font-bold text-xs text-stone-900 block">
                        {rsn.title}
                      </span>
                      <span className="text-[11px] text-stone-500 mt-0.5 block leading-tight">
                        {rsn.desc}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Submit Action */}
            <div className="pt-4 border-t border-stone-100 flex items-center justify-between">
              <button
                type="button"
                onClick={onBackToRoom}
                disabled={status === 'analyzing'}
                className="px-4 py-2 rounded-xl text-stone-600 hover:text-stone-900 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <ArrowRight className="w-4 h-4" />
                <span>الرجوع للمكتب</span>
              </button>

              <button
                type="submit"
                disabled={!isFormValid || status === 'analyzing'}
                className={`px-6 py-2.5 rounded-xl font-bold text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer ${
                  isFormValid && status !== 'analyzing'
                    ? 'bg-[#1A1F24] text-[#FDE047] hover:bg-[#2C333D] active:scale-95'
                    : 'bg-stone-200 text-stone-400 cursor-not-allowed'
                }`}
              >
                {status === 'analyzing' ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>جاري تحليل الـ PDF...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-[#FDE047]" />
                    <span>بدء تحليل الكتاب بواسطة Gemini</span>
                    <ArrowLeft className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
