import React, { useState } from 'react';
import { AppSettings, TeacherProfile } from '../types/index.ts';
import { soundManager } from '../utils/audioSynth.ts';
import {
  X,
  Sliders,
  Palette,
  FileUp,
  ToggleLeft,
  ToggleRight,
  RotateCcw,
  Users,
  Check,
  Sparkles,
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  teachers: TeacherProfile[];
  onDeleteCustomTeacher: (id: string) => void;
  onResetDefaults: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  teachers,
  onDeleteCustomTeacher,
  onResetDefaults,
}) => {
  const [activeTab, setActiveTab] = useState<'limits' | 'colors' | 'teachers' | 'flags'>('limits');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#FAF7F2] rounded-3xl border-2 border-[#5C3A21] max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-[#1A1F24] p-5 text-white flex items-center justify-between border-b border-[#5C3A21]">
          <div className="flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-xl bg-[#5C3A21] text-[#FDE047] flex items-center justify-center">
              <Sliders className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-extrabold text-base text-[#FAF7F2] font-chalk">
                لوحة إعدادات شقة الفهيم (Admin Prototype)
              </h3>
              <span className="text-[11px] text-stone-400">
                تخصيص الألوان، حدود الرفع، والمعلمين وميزات النظام
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white border-b border-stone-200 px-6 flex items-center gap-4 text-xs font-bold overflow-x-auto">
          <button
            onClick={() => setActiveTab('limits')}
            className={`py-3 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'limits'
                ? 'border-[#8B5CF6] text-[#8B5CF6]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            حدود الرفع والملفات
          </button>
          <button
            onClick={() => setActiveTab('colors')}
            className={`py-3 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'colors'
                ? 'border-[#8B5CF6] text-[#8B5CF6]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            ألوان السبورة والجدران
          </button>
          <button
            onClick={() => setActiveTab('teachers')}
            className={`py-3 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'teachers'
                ? 'border-[#8B5CF6] text-[#8B5CF6]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            إدارة المعلمين ({teachers.length})
          </button>
          <button
            onClick={() => setActiveTab('flags')}
            className={`py-3 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'flags'
                ? 'border-[#8B5CF6] text-[#8B5CF6]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            الميزات التجريبية
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-right">
          {/* TAB 1: UPLOAD LIMITS */}
          {activeTab === 'limits' && (
            <div className="space-y-4">
              <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                    <FileUp className="w-4 h-4 text-[#8B5CF6]" />
                    الحد الأقصى لحجم ملف الـ PDF:
                  </label>
                  <span className="font-mono font-bold text-sm text-[#8B5CF6] bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                    {settings.maxUploadSizeMB} ميجابايت
                  </span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="50"
                  step="5"
                  value={settings.maxUploadSizeMB}
                  onChange={(e) =>
                    onUpdateSettings({
                      ...settings,
                      maxUploadSizeMB: Number(e.target.value),
                    })
                  }
                  className="w-full accent-[#8B5CF6] cursor-pointer"
                />
                <p className="text-[11px] text-stone-500 mt-2">
                  يتم التحقق الفوري من حجم ملفات الـ PDF المرفوعة وتنبيه الطالب عند تجاوز هذا الحد.
                </p>
              </div>

              <div className="bg-amber-50 p-4 rounded-xl border border-amber-200 text-xs text-amber-900 leading-relaxed">
                <span className="font-bold block mb-1">💡 نصيحة الفهيم للبيئة:</span>
                المذكرات والكتب الممسوحة ضوئيًا غالبًا ما تتراوح بين 6 إلى 15 ميجابايت. ننصح بالحفاظ على حد الـ 15 ميجا لتوازن سرعة التفكيك والأداء.
              </div>
            </div>
          )}

          {/* TAB 2: COLORS & THEMES */}
          {activeTab === 'colors' && (
            <div className="space-y-4">
              <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
                <label className="block text-xs font-bold text-stone-800 mb-3 flex items-center gap-1.5">
                  <Palette className="w-4 h-4 text-[#8B5CF6]" />
                  درجة لون السبورة المركزية:
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { id: 'charcoal-black', title: 'أسود كلاسيكي', hex: '#1A1F24' },
                    { id: 'deep-slate', title: 'رمادي مدرسي', hex: '#262D35' },
                    { id: 'classic-green', title: 'أخضر سبورة زمان', hex: '#163323' },
                  ].map((c) => (
                    <button
                      key={c.id}
                      onClick={() =>
                        onUpdateSettings({
                          ...settings,
                          chalkboardHue: c.id as any,
                        })
                      }
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                        settings.chalkboardHue === c.id
                          ? 'border-[#8B5CF6] ring-2 ring-[#8B5CF6] bg-purple-50/50'
                          : 'border-stone-200 bg-stone-50 hover:bg-stone-100'
                      }`}
                    >
                      <div
                        className="w-full h-8 rounded-lg mb-2 shadow-inner border border-black/20"
                        style={{ backgroundColor: c.hex }}
                      />
                      <span className="text-xs font-bold text-stone-800 block">
                        {c.title}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
                <label className="block text-xs font-bold text-stone-800 mb-3">
                  دفء جدران الشقة:
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { id: 'warm-cream', title: 'بيج دافئ مصري', hex: '#FAF7F2' },
                    { id: 'aged-paper', title: 'ورق كتب أصفر', hex: '#F3EFE4' },
                    { id: 'clean-white', title: 'أبيض هادئ', hex: '#FFFFFF' },
                  ].map((w) => (
                    <button
                      key={w.id}
                      onClick={() =>
                        onUpdateSettings({
                          ...settings,
                          wallWarmth: w.id as any,
                        })
                      }
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                        settings.wallWarmth === w.id
                          ? 'border-[#8B5CF6] ring-2 ring-[#8B5CF6] bg-purple-50/50'
                          : 'border-stone-200 bg-stone-50 hover:bg-stone-100'
                      }`}
                    >
                      <div
                        className="w-full h-8 rounded-lg mb-2 shadow-xs border border-stone-300"
                        style={{ backgroundColor: w.hex }}
                      />
                      <span className="text-xs font-bold text-stone-800 block">
                        {w.title}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: TEACHERS MANAGEMENT */}
          {activeTab === 'teachers' && (
            <div className="space-y-3">
              <span className="text-xs font-semibold text-stone-500 block mb-2">
                قائمة المعلمين المتاحين في شقة الفهيم:
              </span>
              {teachers.map((t) => (
                <div
                  key={t.id}
                  className="bg-white p-3.5 rounded-xl border border-stone-200 flex items-center justify-between shadow-xs"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{t.avatarEmoji}</span>
                    <div>
                      <h4 className="font-bold text-xs text-stone-900">
                        {t.name}
                      </h4>
                      <span className="text-[11px] text-stone-500">
                        {t.specialty}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {t.isCustom ? (
                      <button
                        onClick={() => onDeleteCustomTeacher(t.id)}
                        className="text-xs text-rose-600 hover:text-rose-800 font-bold px-2.5 py-1 rounded bg-rose-50 hover:bg-rose-100 transition-colors cursor-pointer"
                      >
                        حذف المعلم
                      </button>
                    ) : (
                      <span className="text-[10px] text-stone-400 bg-stone-100 px-2 py-0.5 rounded font-mono">
                        معلم افتراضي
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 4: FEATURE FLAGS */}
          {activeTab === 'flags' && (
            <div className="space-y-4">
              <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
                <label className="flex items-center justify-between cursor-pointer">
                  <div>
                    <span className="text-xs font-bold text-stone-800 block">
                      تفعيل خيار الامتحان الشفوي
                    </span>
                    <span className="text-[11px] text-stone-500">
                      إتاحة تجربة التسجيل الصوتي للمناقشة الشفوية مع المعلم
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.enableOralExam}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        enableOralExam: e.target.checked,
                      })
                    }
                    className="w-4 h-4 rounded text-[#8B5CF6] focus:ring-[#8B5CF6]"
                  />
                </label>

                <div className="border-t border-stone-100 pt-3">
                  <label className="flex items-center justify-between cursor-pointer">
                    <div>
                      <span className="text-xs font-bold text-stone-800 block">
                        المؤثرات الصوتية للطباشير والورق
                      </span>
                      <span className="text-[11px] text-stone-500">
                        توليد أصوات حك الطباشير والمسح التفاعلي عبر المتصفح
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.enableSoundEffects}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          enableSoundEffects: e.target.checked,
                        })
                      }
                      className="w-4 h-4 rounded text-[#8B5CF6] focus:ring-[#8B5CF6]"
                    />
                  </label>
                </div>

                <div className="border-t border-stone-100 pt-3">
                  <label className="block text-xs font-bold text-stone-800 mb-1">
                    سرعة شريط التحليل المحاكي:
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      min="1000"
                      max="4000"
                      step="500"
                      value={settings.simulatedDelayMs}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          simulatedDelayMs: Number(e.target.value),
                        })
                      }
                      className="w-full accent-[#8B5CF6] cursor-pointer"
                    />
                    <span className="font-mono text-xs text-stone-600 shrink-0">
                      {(settings.simulatedDelayMs / 1000).toFixed(1)} ثوانٍ
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-white p-4 border-t border-stone-200 flex items-center justify-between">
          <button
            onClick={() => {
              soundManager.playClick();
              onResetDefaults();
            }}
            className="text-xs font-bold text-stone-500 hover:text-stone-800 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>استعادة الإعدادات الافتراضية</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#1A1F24] hover:bg-[#2C333D] text-[#FDE047] font-bold text-xs shadow transition-all cursor-pointer"
          >
            حفظ وإغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
