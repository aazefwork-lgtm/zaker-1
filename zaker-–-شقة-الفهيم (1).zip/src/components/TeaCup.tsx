import React, { useState } from 'react';
import { soundManager } from '../utils/audioSynth.ts';

export const TeaCup: React.FC = () => {
  const [clickCount, setClickCount] = useState(0);
  const [showTooltip, setShowTooltip] = useState(false);

  const quotes = [
    'كوباية شاي صعيدي بنعناع.. مفتاح التركيز الذهني!',
    'النعناع بيهدي الأعصاب، والشاي بيصحّي الفهيم جواك.',
    'رشفة شاي قبل ما ندخل على مسألة الفيزياء المعقدة.',
    'يا بطل، المذاكرة فن والروقان أساس الاستيعاب!',
  ];

  const handleClick = () => {
    soundManager.playClick();
    setClickCount((prev) => (prev + 1) % quotes.length);
    setShowTooltip(true);
    setTimeout(() => setShowTooltip(false), 3000);
  };

  return (
    <div className="relative inline-block cursor-pointer group" onClick={handleClick}>
      {/* Tooltip on interaction */}
      {showTooltip && (
        <div className="absolute -top-14 right-1/2 translate-x-1/2 z-30 bg-[#1E232A] text-[#FAF7F2] text-xs font-semibold px-3 py-1.5 rounded-lg whitespace-nowrap shadow-xl border border-stone-700 animate-in fade-in slide-in-from-bottom-2 duration-200">
          {quotes[clickCount]}
          <div className="absolute -bottom-1 right-1/2 translate-x-1/2 w-2 h-2 bg-[#1E232A] rotate-45 border-r border-b border-stone-700" />
        </div>
      )}

      {/* Steam Wisps */}
      <div className="absolute -top-7 left-1/2 -translate-x-1/2 pointer-events-none flex gap-1">
        <div className="w-1.5 h-6 bg-stone-300/60 rounded-full blur-[2px] animate-tea-steam-1" />
        <div className="w-1 h-8 bg-stone-200/50 rounded-full blur-[2px] animate-tea-steam-2" />
      </div>

      {/* Glass Tea Cup (Egyptian Chay Bel-Naanaa) */}
      <div className="relative w-12 h-16 bg-gradient-to-b from-white/30 via-white/10 to-white/40 rounded-b-xl border-t border-white/40 border-b-2 border-stone-400 shadow-md backdrop-blur-[1px] flex flex-col justify-end p-1">
        {/* Tea Liquid */}
        <div className="w-full h-11 bg-gradient-to-t from-[#7C2D12] via-[#9A3412] to-[#B45309] rounded-b-lg relative overflow-hidden opacity-95">
          {/* Mint Leaf */}
          <div className="absolute top-1 right-2 w-3 h-2 bg-emerald-600 rounded-tr-full rounded-bl-full rotate-45 shadow-xs" />
          {/* Liquid surface reflection */}
          <div className="absolute top-0 inset-x-0 h-1 bg-amber-400/50" />
        </div>

        {/* Small Glass Saucer */}
        <div className="absolute -bottom-1 -left-2 w-16 h-2 bg-stone-300/80 rounded-full border border-stone-400 shadow-sm" />
      </div>

      <span className="sr-only">كوب الشاي المصري</span>
    </div>
  );
};
