import React, { useState, useEffect } from 'react';
import {
  AppSettings,
  ExamQuestion,
  ExamResult,
  LessonData,
  OutputSettings,
  ScreenType,
  TeacherProfile,
  UserPreferences,
} from './types/index.ts';
import {
  APP_CONFIG,
  DEFAULT_APP_SETTINGS,
  DEFAULT_TEACHERS,
  DEFAULT_USER_PREFERENCES,
  SAMPLE_BOOKS,
} from './config.ts';
import { soundManager } from './utils/audioSynth.ts';

import { HeaderNav } from './components/HeaderNav.tsx';
import { IntroScreen } from './components/IntroScreen.tsx';
import { StudyRoom } from './components/StudyRoom.tsx';
import { AnalysisSurveyScreen } from './components/AnalysisSurveyScreen.tsx';
import { TeacherSelectionScreen } from './components/TeacherSelectionScreen.tsx';
import { OutputSettingsScreen } from './components/OutputSettingsScreen.tsx';
import { LessonScreen } from './components/LessonScreen.tsx';
import { ExamScreen } from './components/ExamScreen.tsx';
import { ResultsScreen } from './components/ResultsScreen.tsx';
import { SettingsModal } from './components/SettingsModal.tsx';
import { BookOpen, Sparkles, AlertCircle } from 'lucide-react';

export default function App() {
  // Navigation State
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('intro');
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // App Settings (Admin / Prototype)
  const [appSettings, setAppSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(`${APP_CONFIG.storageKeyPrefix}settings`);
      return saved ? JSON.parse(saved) : DEFAULT_APP_SETTINGS;
    } catch {
      return DEFAULT_APP_SETTINGS;
    }
  });

  // Sound state
  const [soundEnabled, setSoundEnabled] = useState(appSettings.enableSoundEffects);
  const [lampOn, setLampOn] = useState(appSettings.ambientLampOn);

  // Teachers State
  const [teachers, setTeachers] = useState<TeacherProfile[]>(() => {
    try {
      const saved = localStorage.getItem(`${APP_CONFIG.storageKeyPrefix}teachers`);
      return saved ? JSON.parse(saved) : DEFAULT_TEACHERS;
    } catch {
      return DEFAULT_TEACHERS;
    }
  });
  const [selectedTeacherId, setSelectedTeacherId] = useState<string>('faheem');

  // Real Uploaded / Selected Document State
  const [selectedPdfBase64, setSelectedPdfBase64] = useState<string | null>(null);
  const [loadedBookName, setLoadedBookName] = useState<string>('');
  const [loadedBookSizeStr, setLoadedBookSizeStr] = useState<string>('');

  // Active Real Grounded Lesson & Questions (No hardcoded fallback)
  const [activeLesson, setActiveLesson] = useState<LessonData | null>(null);
  const [activeQuestions, setActiveQuestions] = useState<ExamQuestion[]>([]);

  // User Survey Preferences
  const [userPreferences, setUserPreferences] = useState<UserPreferences>(() => {
    try {
      const saved = localStorage.getItem(`${APP_CONFIG.storageKeyPrefix}user_pref`);
      return saved ? JSON.parse(saved) : DEFAULT_USER_PREFERENCES;
    } catch {
      return DEFAULT_USER_PREFERENCES;
    }
  });

  // Output Format Settings
  const [outputSettings, setOutputSettings] = useState<OutputSettings>({
    format: 'chalkboard',
    voice: 'male',
    playbackRate: 1.0,
    enableSounds: true,
    showChalkDiagrams: true,
    autoSpeak: true,
    highlightWords: true,
  });

  // Exam Result State
  const [examResult, setExamResult] = useState<ExamResult | null>(null);
  const [isRegeneratingTeacher, setIsRegeneratingTeacher] = useState(false);
  const [regenerationError, setRegenerationError] = useState<string | null>(null);

  // Sync sound manager setting
  useEffect(() => {
    soundManager.setEnabled(soundEnabled);
  }, [soundEnabled]);

  // Save settings on change
  useEffect(() => {
    try {
      localStorage.setItem(`${APP_CONFIG.storageKeyPrefix}settings`, JSON.stringify(appSettings));
    } catch {
      // Storage unavailable
    }
  }, [appSettings]);

  useEffect(() => {
    try {
      localStorage.setItem(`${APP_CONFIG.storageKeyPrefix}teachers`, JSON.stringify(teachers));
    } catch {
      // Storage unavailable
    }
  }, [teachers]);

  useEffect(() => {
    try {
      localStorage.setItem(`${APP_CONFIG.storageKeyPrefix}user_pref`, JSON.stringify(userPreferences));
    } catch {
      // Storage unavailable
    }
  }, [userPreferences]);

  // Helpers
  const currentTeacher =
    teachers.find((t) => t.id === selectedTeacherId) || teachers[0];

  // Re-generate lesson when changing teacher personality
  const handleRegenerateWithTeacher = async (newTeacherId: string) => {
    setSelectedTeacherId(newTeacherId);
    if (!selectedPdfBase64) return;

    const teacherToUse = teachers.find((t) => t.id === newTeacherId) || teachers[0];
    setIsRegeneratingTeacher(true);
    setRegenerationError(null);
    soundManager.playClick();

    try {
      const response = await fetch('/api/analyze-pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pdfBase64: selectedPdfBase64,
          fileName: loadedBookName,
          studentName: userPreferences.name || 'البطل',
          gradeLevel: userPreferences.gradeLevel,
          speed: userPreferences.speed,
          reason: userPreferences.reason,
          teacherId: newTeacherId,
          teacherName: teacherToUse.name,
          teacherSpecialty: teacherToUse.specialty,
          teacherPersona: teacherToUse.catchphrase,
          teacherDescription: teacherToUse.description,
          examLength: appSettings.defaultExamLength,
          difficulty: appSettings.defaultDifficulty,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'تعذر إعادة صياغة الدرس مع المعلم المختار.');
      }

      setActiveLesson(data.lesson);
      setActiveQuestions(data.questions);
      setExamResult(null);
      soundManager.playChime(true);
    } catch (err: any) {
      console.error('Failed to regenerate lesson with teacher:', err);
      setRegenerationError(err?.message || 'حدث خطأ أثناء إعادة صياغة الدرس مع المعلم المختار.');
    } finally {
      setIsRegeneratingTeacher(false);
    }
  };

  // Handlers
  const handleSelectSampleBook = async (sampleId: string) => {
    soundManager.playClick();
    const book = SAMPLE_BOOKS.find((b) => b.id === sampleId) || SAMPLE_BOOKS[0];
    setLoadedBookName(book.title);
    setLoadedBookSizeStr(book.size);
    // Invalidate previously generated lesson so new PDF is analyzed
    setActiveLesson(null);
    setActiveQuestions([]);
    setExamResult(null);

    if (book.teacherId) {
      setSelectedTeacherId(book.teacherId);
    }

    try {
      const res = await fetch(`/api/sample-pdf/${sampleId}`);
      if (res.ok) {
        const data = await res.json();
        setSelectedPdfBase64(data.base64);
        setLoadedBookName(data.title || book.title);
        setLoadedBookSizeStr(data.sizeStr || book.size);
      }
    } catch (err) {
      console.error('Failed to fetch sample PDF:', err);
    }

    setCurrentScreen('analysis');
  };

  const handleFileSelected = (file: File) => {
    soundManager.playChime(true);
    setLoadedBookName(file.name);
    setLoadedBookSizeStr(`${(file.size / (1024 * 1024)).toFixed(1)} ميجابايت`);
    // Invalidate previously generated lesson
    setActiveLesson(null);
    setActiveQuestions([]);
    setExamResult(null);

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.includes(',') ? result.split(',')[1] : result;
      setSelectedPdfBase64(base64);
      setCurrentScreen('analysis');
    };
    reader.readAsDataURL(file);
  };

  const handleAnalysisSuccess = (
    lesson: LessonData,
    questions: ExamQuestion[],
    pref: UserPreferences
  ) => {
    setActiveLesson(lesson);
    setActiveQuestions(questions);
    setUserPreferences(pref);
    setCurrentScreen('teachers');
  };

  const handleAddCustomTeacher = (newTeacher: TeacherProfile) => {
    setTeachers((prev) => [...prev, newTeacher]);
  };

  const handleDeleteCustomTeacher = (id: string) => {
    setTeachers((prev) => prev.filter((t) => t.id !== id));
    if (selectedTeacherId === id) {
      setSelectedTeacherId('faheem');
    }
  };

  const handleResetDefaults = () => {
    setAppSettings(DEFAULT_APP_SETTINGS);
    setTeachers(DEFAULT_TEACHERS);
    setSelectedTeacherId('faheem');
    setSoundEnabled(true);
    setLampOn(true);
    soundManager.playChime(true);
  };

  // Render wall style class based on appSettings
  const wallBgClass =
    appSettings.wallWarmth === 'aged-paper'
      ? 'bg-[#F3EFE4]'
      : appSettings.wallWarmth === 'clean-white'
      ? 'bg-white'
      : 'bg-[#FAF7F2]';

  return (
    <div className={`min-h-screen ${wallBgClass} flex flex-col font-cairo selection:bg-[#FDE047] selection:text-[#18181B]`}>
      {/* 3-Second Intro Screen with Skip Option */}
      {currentScreen === 'intro' && (
        <IntroScreen
          soundEnabled={soundEnabled}
          onComplete={() => setCurrentScreen('room')}
        />
      )}

      {/* Persistent Header */}
      {currentScreen !== 'intro' && (
        <HeaderNav
          currentScreen={currentScreen}
          onNavigate={(screen) => setCurrentScreen(screen)}
          onOpenSettings={() => setShowSettingsModal(true)}
          soundEnabled={soundEnabled}
          onToggleSound={() => setSoundEnabled((prev) => !prev)}
          lampOn={lampOn}
          onToggleLamp={() => setLampOn((prev) => !prev)}
          onReplayIntro={() => setCurrentScreen('intro')}
          hasLoadedBook={Boolean(activeLesson)}
        />
      )}

      {/* Screen Views */}
      <main className="flex-1">
        {currentScreen === 'room' && (
          <StudyRoom
            lampOn={lampOn}
            onToggleLamp={() => setLampOn((prev) => !prev)}
            maxUploadSizeMB={appSettings.maxUploadSizeMB}
            onFileSelected={handleFileSelected}
            onSelectSampleBook={handleSelectSampleBook}
            onOpenSettings={() => setShowSettingsModal(true)}
          />
        )}

        {currentScreen === 'analysis' && (
          <AnalysisSurveyScreen
            pdfBase64={selectedPdfBase64}
            fileName={loadedBookName}
            fileSizeStr={loadedBookSizeStr}
            initialPreferences={userPreferences}
            currentTeacher={currentTeacher}
            onAnalysisSuccess={handleAnalysisSuccess}
            onBackToRoom={() => setCurrentScreen('room')}
          />
        )}

        {regenerationError && (
          <div className="max-w-4xl mx-auto my-3 p-3.5 rounded-2xl bg-rose-50 border-2 border-rose-300 text-rose-900 text-xs flex items-center justify-between shadow-sm">
            <span>{regenerationError}</span>
            <button
              onClick={() => setRegenerationError(null)}
              className="font-bold text-rose-800 hover:text-black px-2 py-0.5 rounded text-sm cursor-pointer"
            >
              ×
            </button>
          </div>
        )}

        {currentScreen === 'teachers' && (
          <TeacherSelectionScreen
            teachers={teachers}
            selectedTeacherId={selectedTeacherId}
            onSelectTeacher={(id) => setSelectedTeacherId(id)}
            onAddTeacher={handleAddCustomTeacher}
            onContinue={() => setCurrentScreen('output_settings')}
            onBack={() => setCurrentScreen('analysis')}
            studentName={userPreferences.name}
            hasAnalyzedLesson={Boolean(activeLesson)}
            isRegeneratingTeacher={isRegeneratingTeacher}
            onRegenerateWithTeacher={handleRegenerateWithTeacher}
          />
        )}

        {currentScreen === 'output_settings' && (
          <OutputSettingsScreen
            settings={outputSettings}
            onChangeSettings={(newS) => setOutputSettings(newS)}
            selectedTeacher={currentTeacher}
            onContinue={() => setCurrentScreen('lesson')}
            onBack={() => setCurrentScreen('teachers')}
          />
        )}

        {currentScreen === 'lesson' && (
          activeLesson ? (
            <LessonScreen
              lesson={activeLesson}
              teacher={currentTeacher}
              settings={outputSettings}
              studentName={userPreferences.name}
              onGoToExam={() => setCurrentScreen('exam')}
              onBackToSettings={() => setCurrentScreen('output_settings')}
              onChangeTeacher={(id) => setSelectedTeacherId(id)}
              onRegenerateWithTeacher={handleRegenerateWithTeacher}
              isRegeneratingTeacher={isRegeneratingTeacher}
            />
          ) : (
            <div className="max-w-2xl mx-auto py-16 px-4 text-center">
              <div className="bg-[#1A1F24] chalkboard-border p-8 rounded-2xl text-white shadow-xl">
                <AlertCircle className="w-12 h-12 text-[#FDE047] mx-auto mb-4" />
                <h3 className="text-2xl font-black font-chalk text-[#FDE047] mb-2">
                  لم يتم تحليل أي كتاب بعد!
                </h3>
                <p className="text-sm text-stone-300 mb-6">
                  ارمي كتابك في شقة الفهيم أولاً حتى يقوم نموذج Gemini بتحليله وصياغة درس السبورة.
                </p>
                <button
                  onClick={() => setCurrentScreen('room')}
                  className="px-6 py-2.5 rounded-xl bg-[#FDE047] hover:bg-yellow-400 text-stone-900 font-extrabold text-xs shadow cursor-pointer"
                >
                  العودة لشقة الفهيم واختيار كتاب
                </button>
              </div>
            </div>
          )
        )}

        {currentScreen === 'exam' && (
          activeQuestions.length > 0 ? (
            <ExamScreen
              questions={activeQuestions}
              teacher={currentTeacher}
              studentName={userPreferences.name}
              onFinishExam={(res) => {
                setExamResult(res);
                setCurrentScreen('results');
              }}
              onBackToLesson={() => setCurrentScreen('lesson')}
            />
          ) : (
            <div className="max-w-2xl mx-auto py-16 px-4 text-center">
              <div className="bg-white border border-stone-200 p-8 rounded-2xl shadow-md">
                <AlertCircle className="w-10 h-10 text-amber-500 mx-auto mb-3" />
                <h3 className="text-lg font-bold text-stone-800 mb-1">
                  لا توجد أسئلة امتحان جاهزة
                </h3>
                <p className="text-xs text-stone-500 mb-4">
                  قم بتحليل مستند أولاً لتوليد أسئلة الامتحان التحريري والشفوي.
                </p>
                <button
                  onClick={() => setCurrentScreen('room')}
                  className="px-5 py-2 rounded-xl bg-[#1A1F24] text-[#FDE047] text-xs font-bold"
                >
                  الذهاب لشقة الفهيم
                </button>
              </div>
            </div>
          )
        )}

        {currentScreen === 'results' && examResult && activeLesson && (
          <ResultsScreen
            result={examResult}
            teacher={currentTeacher}
            studentName={userPreferences.name}
            onRetakeExam={() => setCurrentScreen('exam')}
            onJumpToSection={() => {
              setCurrentScreen('lesson');
            }}
            onReturnToRoom={() => setCurrentScreen('room')}
          />
        )}
      </main>

      {/* Admin / Prototype Settings Modal */}
      <SettingsModal
        isOpen={showSettingsModal}
        onClose={() => setShowSettingsModal(false)}
        settings={appSettings}
        onUpdateSettings={(newSettings) => setAppSettings(newSettings)}
        teachers={teachers}
        onDeleteCustomTeacher={handleDeleteCustomTeacher}
        onResetDefaults={handleResetDefaults}
      />
    </div>
  );
}
