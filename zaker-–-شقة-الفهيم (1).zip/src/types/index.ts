export type ScreenType =
  | 'intro'
  | 'room'
  | 'analysis'
  | 'teachers'
  | 'output_settings'
  | 'lesson'
  | 'exam'
  | 'results'
  | 'revision';

export type GradeLevel =
  | '3 ثانوي'
  | '1 كلية'
  | '2 كلية'
  | '3 كلية'
  | '4 كلية'
  | 'ماجستير'
  | 'حاجة تانية';

export type StudySpeed = 'fast' | 'slow';

export type StudyReason = 'tomorrow' | 'understand' | 'fun';

export type OutputFormat = 'chalkboard' | 'audio' | 'cartoon';

export type VoiceOption = 'male' | 'female';

export type ExamDifficulty = 'easy' | 'medium' | 'hard' | 'challenge';

export type QuestionCategory =
  | 'concept'          // 4 understanding & concepts
  | 'application'      // 4 application & reasoning
  | 'comparison'       // 3 comparison / cause-and-effect
  | 'error_detection'  // 2 error detection / misconception
  | 'synthesis';       // 2 challenging synthesis / problem solving

export interface UserPreferences {
  name: string;
  gradeLevel: GradeLevel;
  speed: StudySpeed;
  reason: StudyReason;
}

export interface TeacherProfile {
  id: 'faheem' | 'hakkaway' | 'mokhtasar' | string;
  name: string;
  title: string;
  specialty: string;
  avatarEmoji: string;
  avatarBg: string;
  accentColor: string;
  description: string;
  catchphrase: string;
  audioSampleDescription: string;
  chalkboardStyle: string;
  pacing: 'energetic' | 'narrative_story' | 'concise_structured';
  sampleTransition: string;
  isCustom?: boolean;
}

export interface OutputSettings {
  format: OutputFormat;
  voice: VoiceOption;
  playbackRate: number;
  enableSounds: boolean;
  showChalkDiagrams: boolean;
  autoSpeak: boolean;
  highlightWords: boolean;
}

export type ChalkActionType =
  | 'write_text'
  | 'highlight_keyword'
  | 'draw_box'
  | 'draw_circle'
  | 'draw_arrow'
  | 'draw_diagram'
  | 'comparison_table';

export interface ChalkTimelineStep {
  id: string;
  timeSec?: number;
  narrationChunk: string;
  actionType: ChalkActionType;
  chalkText?: string;
  keyword?: string;
  diagramData?: {
    type: 'analogy' | 'timeline' | 'table' | 'formula_box' | 'cause_effect';
    title: string;
    items?: string[];
    columns?: string[];
    rows?: string[][];
  };
  pageRef?: string;
  isPausePoint?: boolean;
}

export interface LessonSection {
  id: string;
  title: string;
  chalkNotes: string[];
  keyConcept: string;
  egyptianKicker: string;
  diagramSvg?: 'physics_atoms' | 'arabic_syntax' | 'history_timeline' | 'medical_neural' | 'custom';
  audioNarrationText: string;
  pageReferences?: string;
  timelineSteps?: ChalkTimelineStep[];
  recapText?: string;
}

export interface LessonData {
  id: string;
  subjectTitle: string;
  bookTitle: string;
  gradeLevel: string;
  teacherId?: string;
  language?: string;
  mainTopics?: string[];
  sections: LessonSection[];
  summaryCard: {
    title: string;
    points: string[];
  };
}

export interface ExamQuestion {
  id: string;
  type: 'mcq' | 'true_false' | 'short_answer' | 'oral' | 'written';
  category?: QuestionCategory;
  difficulty?: ExamDifficulty;
  prompt: string;
  options?: string[];
  correctOptionIndex?: number;
  correctBoolean?: boolean;
  modelAnswer: string;
  explanation: string;
  pageReference?: string;
  topicTag: string;
  sectionIndex: number;
}

export interface ExamState {
  mode: 'written' | 'oral';
  currentQuestionIndex: number;
  userAnswers: Record<string, string | number | boolean>;
  timeRemaining: number;
  isCompleted: boolean;
}

export interface QuestionDetailResult {
  questionId: string;
  questionPrompt: string;
  category: QuestionCategory;
  difficulty: ExamDifficulty;
  userAnswer: string;
  correctAnswer: string;
  isCorrect: boolean;
  explanation: string;
  pageReference?: string;
  topicTag: string;
  sectionIndex: number;
}

export interface RevisionCard {
  conceptTag: string;
  sectionIndex: number;
  originalQuestionPrompt: string;
  teacherExplanation: string;
  newAnalogyExample: string;
  followUpCheck: {
    prompt: string;
    options: string[];
    correctOptionIndex: number;
    explanation: string;
  };
  isMastered?: boolean;
}

export interface ExamResult {
  id: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  passed: boolean;
  gradeMessage: string;
  difficulty: ExamDifficulty;
  details: QuestionDetailResult[];
  suggestedTopics: {
    title: string;
    topicTag: string;
    sectionIndex: number;
    reason: string;
    pageReference?: string;
  }[];
  revisionCards?: RevisionCard[];
  completedAt: string;
}

export interface AppSettings {
  maxUploadSizeMB: number;
  wallWarmth: 'warm-cream' | 'aged-paper' | 'clean-white';
  chalkboardHue: 'deep-slate' | 'classic-green' | 'charcoal-black';
  enableOralExam: boolean;
  enableSoundEffects: boolean;
  simulatedDelayMs: number;
  ambientLampOn: boolean;
  defaultExamLength: number; // 5, 10, or 15
  defaultDifficulty: ExamDifficulty;
  autoSpeakNarration: boolean;
  audioSpeechRate: number;
}
