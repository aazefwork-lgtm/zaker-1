import { AppSettings, ExamDifficulty, GradeLevel, TeacherProfile, UserPreferences } from './types/index.ts';

export const APP_CONFIG = {
  appName: 'ZAKER – شقة الفهيم',
  subtitle: 'بيئة تعليمية مصرية تفاعلية بأسلوب السبورة الذكية وتحليل المستندات الحقيقي',
  maxUploadSizeMB: 15,
  allowedMimeTypes: ['application/pdf'],
  allowedExtensions: ['.pdf'],
  storageKeyPrefix: 'zaker_faheem_',
  githubUrl: 'https://github.com',
};

export const DEFAULT_USER_PREFERENCES: UserPreferences = {
  name: '',
  gradeLevel: '3 ثانوي',
  speed: 'slow',
  reason: 'tomorrow',
};

export const GRADE_LEVELS: { id: GradeLevel; label: string }[] = [
  { id: '3 ثانوي', label: '3 ثانوي (الشهادة العامة)' },
  { id: '1 كلية', label: '1 كلية (سنة أولى)' },
  { id: '2 كلية', label: '2 كلية' },
  { id: '3 كلية', label: '3 كلية' },
  { id: '4 كلية', label: '4 كلية (التخرج)' },
  { id: 'ماجستير', label: 'ماجستير ودراسات عليا' },
  { id: 'حاجة تانية', label: 'حاجة تانية / مذاكرة حرة' },
];

export const SPEED_OPTIONS = [
  { id: 'fast', title: 'سريع وسريع', desc: 'لخص المفيد بدون لف ودوران، ركز على الزتونة' },
  { id: 'slow', title: 'براحة وبفهم', desc: 'امشي خطوة بخطوة وبالتفصيل مع أمثلة من الواقع' },
];

export const STUDY_REASONS = [
  { id: 'tomorrow', title: 'الامتحان بكرة! 🚨', desc: 'حالة طوارئ قصوى، محتاجين نلم المنهج بسرعة' },
  { id: 'understand', title: 'عايز أفهم بجد 🧠', desc: 'حريص على الأساس العلمي والعمق المعرفي' },
  { id: 'fun', title: 'بتسلى وبجرّب ☕', desc: 'استكشاف ممتع بدون ضغط امتحانات' },
];

export const DIFFICULTY_OPTIONS: { id: ExamDifficulty; title: string; desc: string; badge: string }[] = [
  { id: 'easy', title: 'سهل (تذكر مباشر)', desc: 'استرجاع مباشر للمفاهيم والتعريفات الواردة بالنص', badge: '🟢 مباشر' },
  { id: 'medium', title: 'متوسط (فهم وتطبيق)', desc: 'توازن بين الاستيعاب وتطبيق القوانين والعلاقات', badge: '🟡 قياسي' },
  { id: 'hard', title: 'صعب (ربط وتحليل)', desc: 'أسئلة تتطلب ربط الأسباب بالنتائج واستنتاج التريكات', badge: '🟠 متقدم' },
  { id: 'challenge', title: 'تحدي الفهيم (عمق واستنتاج)', desc: 'مسائل ونقاط مركبة تكشف الفهم المطلق لكل تريكة', badge: '🔴 للعباقرة' },
];

export const EXAM_LENGTH_OPTIONS = [
  { count: 5, label: '5 أسئلة (اختبار سريع)' },
  { count: 10, label: '10 أسئلة (تقييم شامل)' },
  { count: 15, label: '15 سؤالاً (الامتحان القياسي الكامل)' },
];

// The Three Distinct Original Teacher Characters
export const DEFAULT_TEACHERS: TeacherProfile[] = [
  {
    id: 'faheem',
    name: 'الفهيم',
    title: 'حكواتي العلوم والفيزياء والطاقة الإيجابية',
    specialty: 'فيزياء، كيمياء، تفكير استنتاجي وتشبيهات ممتعة',
    avatarEmoji: '⚡',
    avatarBg: 'bg-amber-500/10 text-amber-600 border-amber-300',
    accentColor: '#F59E0B',
    description: 'شرح حماسي، سريع الإيقاع، يربط المفاهيم المعقدة بتشبيهات شعبية مضحكة ومفاجئة تجعل الدرس ملحمة بصرية ممتعة.',
    catchphrase: 'طب استنى.. فيه حاجة مهمة هنا لازم تفهم سرها!',
    audioSampleDescription: 'نبرة سريعة حيوية، تعجبات فكاهية، وقفات مفاجئة وسؤال تفاعلي.',
    chalkboardStyle: 'رسومات تشبيهية ديناميكية، دوائر صفراء حول التريكات، أسهم طاقة وبطاقات زتونة.',
    pacing: 'energetic',
    sampleTransition: 'تخيل معايا المشهد ده.. الإلكترونات واقفة طابور في محطة مصر!',
  },
  {
    id: 'hakkaway',
    name: 'الحكّاي',
    title: 'راوي التاريخ والوقائع والملاحم الإنسانية',
    specialty: 'تاريخ، جغرافيا، دراسات إنسانية، سياق زمني',
    avatarEmoji: '⏳',
    avatarBg: 'bg-purple-500/10 text-purple-600 border-purple-300',
    accentColor: '#8B5CF6',
    description: 'أسلوب سردي مشوق متزن، يبدأ بمشهد درامي يربط الأحداث بالزمان والمكان، ويوضح خيوط الأسباب والنتائج بحبكة قصصية.',
    catchphrase: 'وفي تلك اللحظة بالذات.. بدأت خيوط التاريخ تتشابك!',
    audioSampleDescription: 'نبرة هادئة وقورة، تشويق تدريجي، وتركيز على حركة الأبطال والتواريخ.',
    chalkboardStyle: 'خطوط زمنية (Timelines)، خرائط جغرافية مبسّطة، وتوصيل الأسباب بالنتائج.',
    pacing: 'narrative_story',
    sampleTransition: 'لكن وراء الأبواب المغلقة في ذلك الصباح، كان هناك قرار سيغير مجرى التاريخ...',
  },
  {
    id: 'mokhtasar',
    name: 'المختصر',
    title: 'منظم المنهج والمبسط المباشر بدون لف ودوران',
    specialty: 'مفاهيم مباشرة، جداول مقارنة، ونقاط الامتحانات الحاسمة',
    avatarEmoji: '📐',
    avatarBg: 'bg-emerald-500/10 text-emerald-600 border-emerald-300',
    accentColor: '#10B981',
    description: 'لا مقدمات طويلة ولا تشتيت؛ يدخل فورًا في صلب الموضوع عبر عناوين مرقمة، وجداول مقارنة دقيقة، وخلاصة امتحانية صافية.',
    catchphrase: 'المفيد من الآخر.. افهم القانون ده واقفل درجتك!',
    audioSampleDescription: 'صوت واضح رصين، إيقاع منتظم، تركيز صارم على النقاط والنتائج.',
    chalkboardStyle: 'جداول مقارنة أنيقة، مربعات بيضاء للقوانين، وتعداد نقطي مرتب ومريح للعين.',
    pacing: 'concise_structured',
    sampleTransition: 'الزتونة هنا واضحة في 3 نقاط محددة لا تخرج عنها ورقة المفاهيم:',
  },
];

export const SAMPLE_BOOKS = [
  {
    id: 'sample_physics',
    title: 'فيزياء 3 ثانوي – الفصل الأول: التيار الكهربي وقانون أوم',
    size: '8.4 ميجابايت',
    pages: '28 صفحة',
    category: 'فيزياء',
    teacherId: 'faheem',
  },
  {
    id: 'sample_arabic',
    title: 'لغة عربية – مدرسة الإحياء والبعث والبلاغة وقواعد الإعراب',
    size: '4.2 ميجابايت',
    pages: '16 صفحة',
    category: 'عربي',
    teacherId: 'mokhtasar',
  },
  {
    id: 'sample_history',
    title: 'تاريخ مصر الحديث – الحملة الفرنسية وصدمة الحداثة (1798)',
    size: '6.7 ميجابايت',
    pages: '22 صفحة',
    category: 'تاريخ',
    teacherId: 'hakkaway',
  },
];

export const DEFAULT_APP_SETTINGS: AppSettings = {
  maxUploadSizeMB: 15,
  wallWarmth: 'warm-cream',
  chalkboardHue: 'charcoal-black',
  enableOralExam: true,
  enableSoundEffects: true,
  simulatedDelayMs: 2000,
  ambientLampOn: true,
  defaultExamLength: 15,
  defaultDifficulty: 'medium',
  autoSpeakNarration: true,
  audioSpeechRate: 1.0,
};
