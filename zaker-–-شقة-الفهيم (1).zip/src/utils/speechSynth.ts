// Web Speech API wrapper for Arabic narration and speech recognition
export class SpeechManager {
  private synth: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isSupported: boolean = false;
  private voices: SpeechSynthesisVoice[] = [];
  private fallbackTimer: any = null;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.isSupported = true;
      this.loadVoices();
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.loadVoices();
      }
    }
  }

  private loadVoices() {
    if (!this.synth) return;
    this.voices = this.synth.getVoices();
  }

  public getArabicVoice(gender: 'male' | 'female' = 'male'): SpeechSynthesisVoice | null {
    if (this.voices.length === 0 && this.synth) {
      this.loadVoices();
    }

    // Try finding exact Arabic voices
    const arVoices = this.voices.filter(
      (v) => v.lang.startsWith('ar') || v.lang.includes('EG') || v.lang.includes('SA')
    );

    if (arVoices.length > 0) {
      if (gender === 'female') {
        const femaleVoice = arVoices.find(
          (v) =>
            v.name.toLowerCase().includes('female') ||
            v.name.toLowerCase().includes('salma') ||
            v.name.toLowerCase().includes('laila') ||
            v.name.toLowerCase().includes('mariam') ||
            v.name.toLowerCase().includes('hoda') ||
            v.name.toLowerCase().includes('zeina')
        );
        if (femaleVoice) return femaleVoice;
      } else {
        const maleVoice = arVoices.find(
          (v) =>
            v.name.toLowerCase().includes('male') ||
            v.name.toLowerCase().includes('tarik') ||
            v.name.toLowerCase().includes('maged') ||
            v.name.toLowerCase().includes('shakir') ||
            v.name.toLowerCase().includes('naayf')
        );
        if (maleVoice) return maleVoice;
      }
      return arVoices[0];
    }

    return null;
  }

  public speak(
    text: string,
    options: {
      rate?: number;
      gender?: 'male' | 'female';
      onStart?: () => void;
      onEnd?: () => void;
      onError?: () => void;
    } = {}
  ) {
    this.stop();

    const cleanText = text.replace(/[*_#`[\]()«»]/g, ' ').trim();
    if (!cleanText) {
      options.onEnd?.();
      return;
    }

    const rate = Math.max(0.6, Math.min(options.rate || 1.0, 1.6));
    const gender = options.gender || 'male';
    const pitch = gender === 'female' ? 1.25 : 0.95;

    // Word count calculation for fallback duration
    const words = cleanText.split(/\s+/).length;
    // Average 130 words per minute at 1.0x -> approx ~450ms per word / rate
    const approxDurationMs = Math.max(1200, (words * 420) / rate);

    if (!this.synth || !this.isSupported) {
      // Graceful fallback when TTS is unsupported
      options.onStart?.();
      this.fallbackTimer = setTimeout(() => {
        options.onEnd?.();
      }, approxDurationMs);
      return;
    }

    try {
      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.lang = 'ar-EG';
      utterance.rate = rate;
      utterance.pitch = pitch;

      const voice = this.getArabicVoice(gender);
      if (voice) {
        utterance.voice = voice;
      }

      let hasEnded = false;

      utterance.onstart = () => {
        options.onStart?.();
      };

      utterance.onend = () => {
        if (!hasEnded) {
          hasEnded = true;
          if (this.fallbackTimer) clearTimeout(this.fallbackTimer);
          options.onEnd?.();
        }
      };

      utterance.onerror = (e) => {
        console.warn('SpeechSynthesis error:', e);
        if (!hasEnded) {
          hasEnded = true;
          if (this.fallbackTimer) clearTimeout(this.fallbackTimer);
          options.onEnd?.();
        }
      };

      this.currentUtterance = utterance;

      // Safety timeout: In some environments browser TTS might pause or not fire onend
      this.fallbackTimer = setTimeout(() => {
        if (!hasEnded) {
          hasEnded = true;
          this.synth?.cancel();
          options.onEnd?.();
        }
      }, approxDurationMs + 2000);

      this.synth.speak(utterance);
    } catch (err) {
      console.warn('Speech synthesis call failed, using timer fallback:', err);
      options.onStart?.();
      this.fallbackTimer = setTimeout(() => {
        options.onEnd?.();
      }, approxDurationMs);
    }
  }

  public pause() {
    if (this.fallbackTimer) clearTimeout(this.fallbackTimer);
    if (this.synth && this.synth.speaking) {
      this.synth.pause();
    }
  }

  public resume() {
    if (this.synth && this.synth.paused) {
      this.synth.resume();
    }
  }

  public stop() {
    if (this.fallbackTimer) {
      clearTimeout(this.fallbackTimer);
      this.fallbackTimer = null;
    }
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch {
        // Silent
      }
    }
    this.currentUtterance = null;
  }
}

export const speechManager = new SpeechManager();

// Speech Recognition helper for Oral Exam
export class SpeechRecognitionManager {
  private recognition: any = null;
  private isListening = false;

  constructor() {
    if (typeof window !== 'undefined') {
      const SpeechRec =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRec) {
        this.recognition = new SpeechRec();
        this.recognition.lang = 'ar-EG';
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
      }
    }
  }

  public isAvailable(): boolean {
    return Boolean(this.recognition);
  }

  public start(
    onResult: (text: string, isFinal: boolean) => void,
    onError: (err: string) => void
  ) {
    if (!this.recognition) {
      onError('خاصية التعرف على الصوت غير مدعومة في هذا المتصفح. يمكنك كتابة إجابتك مباشرة.');
      return;
    }

    if (this.isListening) return;

    try {
      this.isListening = true;
      this.recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        const combined = finalTranscript || interimTranscript;
        onResult(combined, Boolean(finalTranscript));
      };

      this.recognition.onerror = (event: any) => {
        console.warn('SpeechRecognition error:', event.error);
        this.isListening = false;
        onError(event.error === 'not-allowed' ? 'تم رفض إذن استخدام الميكروفون.' : 'تعذر التقاط الصوت.');
      };

      this.recognition.onend = () => {
        this.isListening = false;
      };

      this.recognition.start();
    } catch (err: any) {
      this.isListening = false;
      onError(err?.message || 'تعذر تشغيل الميكروفون.');
    }
  }

  public stop() {
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch {
        // Silent
      }
      this.isListening = false;
    }
  }
}

export const speechRecognitionManager = new SpeechRecognitionManager();
