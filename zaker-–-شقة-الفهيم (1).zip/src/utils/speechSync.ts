// Web Speech API manager for synchronized narration and chalkboard action timing

export interface VoiceInfo {
  name: string;
  lang: string;
  isArabic: boolean;
  isEgyptian: boolean;
}

class SpeechSyncManager {
  private synth: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private activeVoices: SpeechSynthesisVoice[] = [];
  private fallbackTimer: NodeJS.Timeout | null = null;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.loadVoices();
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.loadVoices();
      }
    }
  }

  private loadVoices() {
    if (!this.synth) return;
    try {
      this.activeVoices = this.synth.getVoices();
    } catch {
      this.activeVoices = [];
    }
  }

  public getAvailableVoiceInfo(): VoiceInfo {
    if (!this.synth || this.activeVoices.length === 0) {
      this.loadVoices();
    }

    const egVoice = this.activeVoices.find((v) => v.lang.toLowerCase() === 'ar-eg');
    const arVoice = this.activeVoices.find((v) => v.lang.toLowerCase().startsWith('ar'));

    if (egVoice) {
      return {
        name: egVoice.name,
        lang: egVoice.lang,
        isArabic: true,
        isEgyptian: true,
      };
    }

    if (arVoice) {
      return {
        name: arVoice.name,
        lang: arVoice.lang,
        isArabic: true,
        isEgyptian: false,
      };
    }

    return {
      name: 'صوت المتصفح الافتراضي (قراءة نصية آلية)',
      lang: 'ar',
      isArabic: false,
      isEgyptian: false,
    };
  }

  public stop() {
    if (this.fallbackTimer) {
      clearTimeout(this.fallbackTimer);
      this.fallbackTimer = null;
    }
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch {
        // Safe ignore
      }
    }
    this.currentUtterance = null;
  }

  public pause() {
    if (this.synth && this.synth.speaking && !this.synth.paused) {
      try {
        this.synth.pause();
      } catch {
        // Fallback
      }
    }
  }

  public resume() {
    if (this.synth && this.synth.paused) {
      try {
        this.synth.resume();
      } catch {
        // Fallback
      }
    }
  }

  public speakChunk(
    text: string,
    rate: number = 1.0,
    onStart?: () => void,
    onEnd?: () => void,
    onError?: (err: any) => void
  ) {
    this.stop();

    if (!text || text.trim().length === 0) {
      if (onEnd) onEnd();
      return;
    }

    // If SpeechSynthesis is not supported in this browser, use timed fallback
    if (!this.synth || !('SpeechSynthesisUtterance' in window)) {
      if (onStart) onStart();
      const words = text.split(/\s+/).length;
      const durationMs = Math.max(1500, (words / (2.5 * rate)) * 1000);
      this.fallbackTimer = setTimeout(() => {
        if (onEnd) onEnd();
      }, durationMs);
      return;
    }

    try {
      const utterance = new SpeechSynthesisUtterance(text);
      this.currentUtterance = utterance;

      // Select Arabic voice if available
      const voice =
        this.activeVoices.find((v) => v.lang.toLowerCase() === 'ar-eg') ||
        this.activeVoices.find((v) => v.lang.toLowerCase().startsWith('ar'));

      if (voice) {
        utterance.voice = voice;
      }
      utterance.lang = 'ar-SA';
      utterance.rate = Math.min(Math.max(rate, 0.75), 1.5);
      utterance.pitch = 1.0;

      let hasFinished = false;

      utterance.onstart = () => {
        if (onStart) onStart();
      };

      utterance.onend = () => {
        if (!hasFinished) {
          hasFinished = true;
          if (this.fallbackTimer) clearTimeout(this.fallbackTimer);
          if (onEnd) onEnd();
        }
      };

      utterance.onerror = (e) => {
        if (!hasFinished) {
          hasFinished = true;
          if (this.fallbackTimer) clearTimeout(this.fallbackTimer);
          if (onError) onError(e);
          else if (onEnd) onEnd(); // gracefully proceed
        }
      };

      // Failsafe watchdog timer in case speech engine hangs on long chunks
      const words = text.split(/\s+/).length;
      const maxExpectedMs = Math.max(3000, (words / (1.5 * rate)) * 1000 + 4000);
      this.fallbackTimer = setTimeout(() => {
        if (!hasFinished) {
          hasFinished = true;
          this.stop();
          if (onEnd) onEnd();
        }
      }, maxExpectedMs);

      this.synth.speak(utterance);
    } catch (err) {
      console.warn('Speech synthesis failed, falling back to visual timer:', err);
      if (onStart) onStart();
      const words = text.split(/\s+/).length;
      const durationMs = Math.max(1500, (words / (2.5 * rate)) * 1000);
      this.fallbackTimer = setTimeout(() => {
        if (onEnd) onEnd();
      }, durationMs);
    }
  }
}

export const speechSyncManager = new SpeechSyncManager();
