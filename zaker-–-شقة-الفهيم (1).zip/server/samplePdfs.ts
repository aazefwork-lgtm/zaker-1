// Generates valid, standards-compliant PDF 1.4 binary buffers for the built-in sample curriculum
function escapePdf(str: string): string {
  return str.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
}

export function generateEducationalPdf(
  title: string,
  sections: { heading: string; lines: string[]; pageNum: number }[]
): Buffer {
  let streamText = `BT /F1 16 Tf 40 740 Td (${escapePdf(title)}) Tj ET\n`;
  let y = 710;

  for (const sec of sections) {
    streamText += `BT /F1 12 Tf 40 ${y} Td (${escapePdf(`[Page ${sec.pageNum}] ${sec.heading}`)}) Tj ET\n`;
    y -= 18;
    for (const line of sec.lines) {
      streamText += `BT /F1 10 Tf 50 ${y} Td (${escapePdf(line)}) Tj ET\n`;
      y -= 15;
      if (y < 40) {
        y = 720; // wrap if too long
      }
    }
    y -= 10;
  }

  const streamBuf = Buffer.from(streamText, 'binary');

  let body = `%PDF-1.4\n`;
  const offsets: number[] = [];

  // obj 1: Catalog
  offsets.push(Buffer.byteLength(body, 'binary'));
  body += `1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n`;

  // obj 2: Pages
  offsets.push(Buffer.byteLength(body, 'binary'));
  body += `2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n`;

  // obj 3: Page
  offsets.push(Buffer.byteLength(body, 'binary'));
  body += `3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>\nendobj\n`;

  // obj 4: Font
  offsets.push(Buffer.byteLength(body, 'binary'));
  body += `4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n`;

  // obj 5: Contents
  offsets.push(Buffer.byteLength(body, 'binary'));
  body += `5 0 obj\n<< /Length ${streamBuf.length} >>\nstream\n${streamText}\nendstream\nendobj\n`;

  const startxref = Buffer.byteLength(body, 'binary');

  // xref table
  let xref = `xref\n0 6\n0000000000 65535 f \n`;
  for (const off of offsets) {
    xref += off.toString().padStart(10, '0') + ` 00000 n \n`;
  }
  xref += `trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${startxref}\n%%EOF\n`;

  return Buffer.from(body + xref, 'binary');
}

export const SAMPLE_PDF_DEFINITIONS: Record<
  string,
  { title: string; sections: { heading: string; lines: string[]; pageNum: number }[] }
> = {
  sample_physics: {
    title: 'Egyptian High School Physics - Chapter 1: Electric Current & Ohm Law',
    sections: [
      {
        pageNum: 1,
        heading: 'Electric Current and Potential Difference',
        lines: [
          'Electric current is the continuous flow of electric charges through conductors.',
          'Formula: I = Q / t, where I is current intensity in Amperes, Q is quantity of charge in Coulombs, t is time in seconds.',
          'Potential difference V = W / Q, measured in Volts. W is work in Joules.',
          'Conventional current flows from positive to negative terminal outside the electric cell.',
        ],
      },
      {
        pageNum: 3,
        heading: 'Ohms Law and Specific Resistance (Resistivity)',
        lines: [
          'Ohms Law states that at constant temperature, current I is directly proportional to potential difference V: V = I * R.',
          'Resistance formula: R = rho_e * (L / A), where rho_e is specific resistivity, L is length, A is cross-sectional area.',
          'Electrical conductivity sigma = 1 / rho_e. Both resistivity and conductivity depend ONLY on material type and temperature.',
          'Key exam case: If a uniform wire is stretched so that its length doubles, its cross-sectional area halves, and its resistance quadruples (4x).',
        ],
      },
      {
        pageNum: 7,
        heading: 'Series and Parallel Resistor Combinations',
        lines: [
          'Series connection: R_eq = R1 + R2 + R3. Current is constant (I1 = I2 = I3) and total voltage is divided.',
          'Parallel connection: 1/R_eq = 1/R1 + 1/R2 + 1/R3. Potential difference is constant across branches (V1 = V2 = V3).',
          'Household appliances are connected in parallel so each appliance receives full 220V and operates independently.',
          'Electric power P = V^2 / R or P = I^2 * R. In parallel, lower resistance consumes higher power.',
        ],
      },
    ],
  },
  sample_arabic: {
    title: 'Arabic Literature and Syntax - Al-Baroudi, Shawqi, and the Five Objects',
    sections: [
      {
        pageNum: 2,
        heading: 'The Revival and Renaissance School (Madrasat Al-Ihyaa wal Baath)',
        lines: [
          'Mahmoud Sami Al-Baroudi is known as Rab Al-Seif wal Qalam (Master of the Sword and Pen).',
          'Al-Baroudi revived classical Arabic poetry from centuries of Ottoman stagnation and decline.',
          'Famous students by oral tradition include Ahmad Shawqi and Hafiz Ibrahim.',
          'The school balances strict classical meter and rhyme with modern national issues.',
        ],
      },
      {
        pageNum: 5,
        heading: 'Ahmad Shawqi - Prince of Poets (Ameer Al-Shuaraa)',
        lines: [
          'Ahmad Shawqi shifted from royal praise (Madeeh) to historical poetry (Kibar Al-Hawadith fi Wadi Al-Neel).',
          'He pioneered poetic Arabic theater: Masraa Cleopatra, Majnoon Layla, and Qambeez.',
          'Shawqi depicted contemporary inventions such as steamships, airplanes, and modern sciences in classical verse.',
        ],
      },
      {
        pageNum: 9,
        heading: 'Arabic Syntax: The Five Objects (Al-Mafaeel Al-Khamsa)',
        lines: [
          'All five objects in Arabic grammar are consistently in the accusative case (Mansoub).',
          '1. Mafool Bih: receiver of the action.',
          '2. Mafool Mutlaq: verbal noun derived from verb for emphasis or elaboration.',
          '3. Mafool Li-ajlih: explains the reason or cause of the action (e.g., raghbatan, talaban).',
          '4. Mafool Feeh: indicates time or place (Zarf).',
          '5. Mafool Maah: follows the Waw of accompaniment (Waw Al-Maeyyah).',
        ],
      },
    ],
  },
  sample_history: {
    title: 'Modern Egyptian History - The French Expedition (1798-1801)',
    sections: [
      {
        pageNum: 1,
        heading: 'Origins and Strategic Objectives of the French Campaign',
        lines: [
          'In May 1798, Napoleon Bonaparte led an expedition from Toulon to Egypt under strict secrecy.',
          'Primary strategic goal: Sever Great Britains imperial trade route to India.',
          'French consuls reported worsening political decline under Mamluk rule (Murad Bey and Ibrahim Bey).',
          'Napoleons ambition was to establish a French Mediterranean empire centered in Egypt.',
        ],
      },
      {
        pageNum: 4,
        heading: 'Egyptian Popular Resistance in Alexandria, Cairo, and Upper Egypt',
        lines: [
          'Mohamed Karim, governor of Alexandria, refused surrender and was executed by firing squad in September 1798.',
          'The Battle of the Pyramids (Imbaba) exposed Mamluk cavalry vulnerability to modern French artillery.',
          'Upper Egypt resistance held out for 10 months through guerrilla warfare and Nile topography.',
          'The First Cairo Revolt erupted in October 1798, centered at Al-Azhar Mosque.',
        ],
      },
      {
        pageNum: 8,
        heading: 'Scientific and Intellectual Legacy of the Expedition',
        lines: [
          'Napoleon brought 167 scientists, engineers, and scholars founding the Institut d Egypte (Al-Majma Al-Ilmi).',
          'The Rosetta Stone was discovered in July 1799 in Rashid and deciphered by Champollion in 1822.',
          'Scholars compiled Description de l Egypte (Wasf Misr), cataloging Egyptian antiquities, fauna, and geography.',
          'Introduction of representative consultative councils (Al-Dawawin) awakened Egyptian national and political consciousness.',
        ],
      },
    ],
  },
};
